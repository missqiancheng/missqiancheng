<template>
  <router-view></router-view>
</template>


<script setup>
import { ref,reactive,onBeforeMount } from 'vue'
import route from './router'

// 关闭浏览器窗口的时候清空浏览器缓存在localStorage的数据
// window.onbeforeunload = function (e) {
//     let storage = window.localStorage;
//     storage.clear()
// }

</script>

<style scoped>


</style>
