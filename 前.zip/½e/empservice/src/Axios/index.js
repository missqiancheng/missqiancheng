import axios from 'axios'
import Store from '/src/Store'


// // 请求拦截器，在每个请求发送前进行处理
// Axios.interceptors.request.use(config => {
//   // 从 localStorage 获取最新的 token
//   //const token = localStorage.getItem('token');
//   const token='KKRap8dKjIHW79y5ijPvIErvt4ql/SOKr6sfktDhNebxnMIMeHOEhBEqcWhbwoSuYyJKrG6xwW6PVrrF9SdsjnPVAKBXy4mDi53La6BQXdKsJ49EnxT0gQ=='
//   // 更新请求头中的 token
//   if (token) {
//     config.headers['token'] = token;
//   }
//
//   return config;
// }, error => {
//   console.log(1)
//   return Promise.reject(error);
// });


// axios实例
const Axios = axios.create({
    baseURL:'https://10.132.55.9:823/ce/',
    //baseURL:'/API/',
    timeout:10000,
    headers:{
      'Content-Type':'application/x-www-form-urlencoded',
      //'token':localStorage.getItem("token")
    },
})


const Headers={
  "Content-Type": "multipart/form-data",
  //'token':localStorage.getItem("token")
}

//excel导入路径
//const ServerPath='https://10.132.55.9:823/ce/'

const ServerPath='/API/'


//获取tokens
const Token=()=>{
    const Store=useStore()
    Axios({
        url:'api/Login',
        params:{
          empno:Store.empno,
        }
    }).then(
        res=>{
          sessionStorage.setItem('token',res.data)
        }
    ).catch(
        err=>{
          console.log(err)
        }
    )
}

//check有没有过期
const CheckStore=()=>{
  const Datekeys=localStorage.getItem('OverDate')
  if(Date.now()<Datekeys){
    return true
  }else{
    localStorage.clear()
    return false 
  }
}

//下载文件
const DownLoad=(url,filename)=>{
  getBlob(url, (blob) => {
    if (window.navigator.msSaveOrOpenBlob) {
      navigator.msSaveBlob(blob, filename);
    } else {
      let link = document.createElement('a');
      let body = document.querySelector('body');
      link.href = window.URL.createObjectURL(blob);
      link.download = filename;
      link.style.display = 'none';
      body.appendChild(link);
      link.click();
      body.removeChild(link);
      window.URL.revokeObjectURL(link.href);
    };
  });
}   
const getBlob=(url, cb)=>{
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  
  xhr.responseType = 'blob';
  xhr.onload = function () {
    if (xhr.status === 200) {
      cb(xhr.response);
    }
  };
  xhr.send();
}

//下载文件变量中的文件
const DownFile=(fileContent,file_name)=>{
  // 创建一个 Blob 对象
  let blob = new Blob([fileContent], { type: 'text/plain' });

  // 创建一个下载链接
  let downloadLink = document.createElement('a');
  downloadLink.href = URL.createObjectURL(blob);
  downloadLink.download = file_name; // 设置要下载的文件名
  // 模拟点击下载链接
  downloadLink.click();
  
  // 释放 URL 对象
  URL.revokeObjectURL(downloadLink.href);
}


//转换日期格式
const formatDate=(date)=> {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  return `${year}/${month}/${day}`;
}


export {
  Axios,
  Token,
  ServerPath,
  CheckStore,
  DownLoad,
  DownFile,
  formatDate,
  Headers
}

