import XLSX from 'xlsx'
import XLSXS from 'xlsx-style'
import FileSaver from 'file-saver'


const IncentiveExcel=(data,filename)=>{
  for(let i=0;i<data.length;i++){
    for(let j=0;j<data[i].length;j++){
      if(data[i][j]==undefined||data[i][j]==null){
        data[i][j]=''
      }
    }
  }

  // 需要导出的数据
  let excelData = [
    ['獎懲導出表格', null, null, null], // 标题
    [null, null, null, null],
    ['編號', '工號', '姓名', '部門名稱', '資位', '年資', '獎懲等級', '獎懲類型'
    , '獎懲原由', '曠工時段', '生效日期', '結案日期', '當前狀態', '待作業人'
    , '代理人', '職業健康體檢', '體檢出席狀態', '待交接項目'], // 表头
    ...data
  ]
 
  // 导出的excel文件名
  filename += '.xlsx'
 
  // Excel第一个sheet的名称
  const ws_name = 'Sheet1'
  const wb = XLSX.utils.book_new()
  const ws = XLSX.utils.aoa_to_sheet(excelData)
  
 
  // 设置标题行单元格合并
  // s即start, e即end, r即row, c即column
  // 合并从--0行0列开始,到0行3列
  ws['!merges'] = [
    { s: { r: 0, c: 0 }, e: { r: 1, c: 17 } }
  ]
 
  // 设置单元格宽度
  ws['!cols'] = [{
    wpx: 40
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 200
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 200
  }, {
    wpx: 200
  }, {
    wpx: 200
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 80
  }, {
    wpx: 140
  }, {
    wpx: 140
  }, {
    wpx: 130
  }]
 
  // 遍历全部单元格,进行样式设置
  for (let i in ws) {
    if(i ==='A1'){
      ws[i].s={
        font:{//字体
          sz:16,
          name: '新細明體',
          bold: true,
          color: { rgb:'E26B0A' }
        },
        alignment:{//居中
          horizontal: 'center',
          vertical: 'center',
          wrapText: true
        },
      }
    }else if(i!='!ref'&i!='!merges'&i!='!cols'){
      ws[i].s = {
        // 单元格边框
        border: {
          top: {
            style: 'thin'
          },
          bottom: {
            style: 'thin'
          },
          left: {
            style: 'thin'
          },
          right: {
            style: 'thin'
          }
        },
        alignment:{//居中
          horizontal: 'center',
          vertical: 'center',
          wrapText: true
        },
      }
      if(i.includes('3')&&i.length<3){
        Object.assign(ws[i].s,{
          fill: { //背景色
            fgColor: { rgb: 'C5D9F1' }
          },
          font:{
            bold: true,
          }
        });  
        if(i.includes('Q')||i.includes('R')||(ws[i].v==='Y'&&i.includes('P'))){
            ws[i].s.font.color={rgb:'FA0000'}
        }
      }
    }
  }
 
  XLSX.utils.book_append_sheet(wb, ws, ws_name) // 将数据添加到工作薄

  // 导出Excel, 注意这里用到的是XLSXS对象
  let wbout = XLSXS.write(wb, {
    bookType: 'xlsx',
    bookSST: false,
    type: 'binary'
  })
  FileSaver.saveAs(
    new Blob([s2ab(wbout)], {
      type: 'application/octet-stream'
    }),
    filename
  )
}

const AbsenteeismExcle=(data)=>{
    // 需要导出的数据
    let excelData = [
      ['員工違紀處理人員名單 (曠工開除)', null, null, null], // 标题
      ['序號', '工號', '姓名', '法人名稱', '入職日期', '事業處', '資位'
      , '獎懲類別', '曠工日期'], // 表头
      ...data,
      ['公司規定及條款說明',null,
      '依《公司員工違紀處理管理規定》第12條第3項：连续旷工三日或三个月内累计旷工達四日及以上，以上員工开除。'
      ,'','','','','',''],
      ['','','','','','','','',''],
      //middle
      ['人資意見','','依規定開除： *同意  *不同意',null,'',
      '依規定開除： *同意  *不同意','','',''],
      ['','',null,null,'',null,null,'',''],
      ['','',null,null,'',null,null,'',''], 
      ['','',null,null,'',null,null,'',''],
      ['','','核准：','','','審核：','','','承辦：'],
      //laster
      ['工會意見','','依規定開除： *同意  *不同意',null,null,null,null,null,''],
      ['','',null,null,null,null,null,null,''],
      ['','',null,null,null,null,null,null,''],
      ['','',null,null,null,null,null,null,''],
      ['','','工會主席：','','','','','','']
    ]
   
    // 导出的excel文件名
    let filename = '曠工單.xlsx'
   
    // Excel第一个sheet的名称
    const ws_name = 'Sheet1'
    const wb = XLSX.utils.book_new()
    const ws = XLSX.utils.aoa_to_sheet(excelData)
    
   
    // 设置标题行单元格合并
    // s即start, e即end, r即row, c即column
    // 合并从--0行0列开始,到0行3列
    let merges=[
      { s: { r: 0, c: 0 }, e: { r: 0, c: 8 } }
    ]
   
    // 设置单元格宽度
    ws['!cols'] = [{
      wpx: 40
    }, {
      wpx: 70
    }, {
      wpx: 70
    }, {
      wpx: 230
    }, {
      wpx: 80
    }, {
      wpx: 100
    }, {
      wpx: 80
    }, {
      wpx: 100
    }, {
      wpx: 300
    }]
   
    let wsrows = [{ hpx: 60 }];  // 每行固定高度px
    for (let i = 0; i < excelData.length - 12; i++) {   // total  列表条数
      wsrows.push({ hpx: 40 });
    }
    for (let i = excelData.length - 12 ; i < excelData.length - 1; i++) {   // total  列表条数
      wsrows.push({ hpx: 20 });
    }
    ws["!rows"] = wsrows;
    //合并单元格
    ws['!merges'] = merges

    let Laster,First 
    // 遍历全部单元格,进行样式设置
    for (let i in ws) {
      if(i ==='A1'){
        ws[i].s={
          font:{//字体
            sz:18,
            name: '新細明體',
            bold: true,
          },
          alignment:{//居中
            horizontal: 'center',
            vertical: 'center',
            wrapText: true
          },
        }
      }else if(i!='!ref'&i!='!merges'&i!='!cols'&i!='!rows'){
        ws[i].s = {
          // 单元格边框
          border: {
            top: {
              style: 'thin'
            },
            bottom: {
              style: 'thin'
            },
            left: {
              style: 'thin'
            },
            right: {
              style: 'thin'
            }
          },
          font:{
            name: '新細明體',
            sz:10
          },
          alignment:{//居中
            horizontal: 'center',
            vertical: 'center',
            wrapText: true
          },
        }
        if(ws[i].v==='公司規定及條款說明'){
          ws[i].s.font={
            bold: true,
            name: '新細明體',
            sz:12
          }; 
          //行
          const rows=i.substring(1,i.length) - 1
          //列
          const cloumn=i.substring(0,1).charCodeAt() - 65
          merges.push({s: { r: rows, c: cloumn }, 
            e: { r: rows + 1, c: cloumn + 1 } })
        }else if(ws[i].v===excelData[excelData.length-12][2]){
          ws[i].s={
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
            // 单元格边框
            border: {
              top: {
                style: 'thin'
              },
              bottom: {
                style: 'thin'
              },
              left: {
                style: 'thin'
              },
              right: {
                style: 'thin'
              }
            },
            font:{
              name: '新細明體',
              sz:12
            }
          } 
          const rows=i.substring(1,i.length) - 1
          const cloumn=i.substring(0,1).charCodeAt() - 65
          merges.push({s: { r: rows, c: cloumn }, 
            e: { r: rows + 1, c: cloumn + 6 } })
        }else if(ws[i].v===excelData[excelData.length-10][0]){
          Object.assign(ws[i].s,{
            font:{
              bold: true,
              name: '新細明體',
              sz:12
            },
          }); 
          //行
          const rows=i.substring(1,i.length) - 1
          //列
          const cloumn=i.substring(0,1).charCodeAt() - 65
          merges.push({s: { r: rows, c: cloumn }, 
            e: { r: rows + 4, c: cloumn + 1 } })
          merges.push({s: { r: rows, c: cloumn + 2 }, 
            e: { r: rows + 1, c: cloumn + 4 } })
          merges.push({s: { r: rows + 4, c: cloumn + 2 }, 
            e: { r: rows + 4, c: cloumn + 4 } })
          merges.push({s: { r: rows, c: cloumn + 5 }, 
            e: { r: rows + 1, c: cloumn + 7 } })
          merges.push({s: { r: rows + 4, c: cloumn + 5 }, 
            e: { r: rows + 4, c: cloumn + 7 } })
          First=i
        }else if(ws[i].v===excelData[excelData.length-10][2]){
          ws[i].s={
            // 单元格边框
            border: {
              top: {
                style: 'thin'
              }
            },
            font:{
              sz:14,//
              name: 'Wingdings 2',
            },
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
          }
        }else if(ws[i].v===excelData[excelData.length-10][5]){
          ws[i].s={
            // 单元格边框
            border: {
              top: {
                style: 'thin'
              }
            },
            font:{
              sz:14,//
              name: 'Wingdings 2',
            },
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
          }
        }else if(ws[i].v===excelData[excelData.length-6][2]){
          ws[i].s={
            // 单元格边框
            border: {
              bottom: {
                style: 'thin'
              }
            },
            font:{
              bold: true,
              name: '新細明體',
              sz:12
            },
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
          }
        }else if(ws[i].v===excelData[excelData.length-6][5]){
          ws[i].s={
            // 单元格边框
            border: {
              bottom: {
                style: 'thin'
              }
            },
            font:{
              bold: true,
              name: '新細明體',
              sz:12
            },
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
          }
        }else if(ws[i].v===excelData[excelData.length-6][8]){
          ws[i].s={
            // 单元格边框
            border: {
              bottom: {
                style: 'thin'
              },
              right: {
                style: 'thin'
              }
            },
            font:{
              bold: true,
              name: '新細明體',
              sz:12
            },
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
          }
        }else if(ws[i].v===excelData[excelData.length-5][0]){
          Object.assign(ws[i].s,{
            font:{
              bold: true,
              name: '新細明體',
              sz:12
            },
          }); 
          //行
          const rows=i.substring(1,i.length) - 1
          //列
          const cloumn=i.substring(0,1).charCodeAt() - 65
          merges.push({s: { r: rows, c: cloumn }, 
            e: { r: rows + 4, c: cloumn + 1 } })
          merges.push({s: { r: rows, c: cloumn + 2 }, 
            e: { r: rows + 1, c: cloumn + 4 } })
          merges.push({s: { r: rows + 4, c: cloumn + 2 }, 
            e: { r: rows + 4, c: cloumn + 8 } })
          Laster=i
        }else if(ws[i].v===excelData[excelData.length-5][2]){
          ws[i].s={
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
            font:{
              sz:14,//
              name: 'Wingdings 2',
            }
          }
        }else if(ws[i].v===excelData[excelData.length-1][2]){
          ws[i].s={
            font:{
              bold: true,
              name: '新細明體',
              sz:12
            },
            border: {
              bottom: {
                style: 'thin'
              }
            },
            alignment:{//居中
              vertical: 'center',
              wrapText: true
            },
          }
        }
      }else{
        if(i=='!cols'){
          //laster
          //行
          const rows=Number(Laster.substring(1,Laster.length))
          //列
          const cloumn=Laster.substring(0,1).charCodeAt()
          ws[String.fromCharCode(cloumn+8)+rows].s=
          ws[String.fromCharCode(cloumn+8)+(rows+1)].s=
          ws[String.fromCharCode(cloumn+8)+(rows+2)].s=
          ws[String.fromCharCode(cloumn+8)+(rows+3)].s={
            border: {
              right: {
                style: 'thin'
              }
            },
          }
          ws[String.fromCharCode(cloumn+3)+(rows+4)].s=
          ws[String.fromCharCode(cloumn+4)+(rows+4)].s=
          ws[String.fromCharCode(cloumn+5)+(rows+4)].s=
          ws[String.fromCharCode(cloumn+6)+(rows+4)].s=
          ws[String.fromCharCode(cloumn+7)+(rows+4)].s={
            border: {
              bottom: {
                style: 'thin'
              }
            },
          }
          ws[String.fromCharCode(cloumn+8)+(rows+4)].s={
            border: {
              right: {
                style: 'thin'
              },
              bottom: {
                style: 'thin'
              }
            },
          }
          //first
          const frows=Number(First.substring(1,First.length))
          //列
          const fcloumn=First.substring(0,1).charCodeAt()

          ws[String.fromCharCode(fcloumn+4)+(frows+1)].s=
          ws[String.fromCharCode(fcloumn+7)+(frows+1)].s=
          ws[String.fromCharCode(fcloumn+4)+(frows+2)].s=
          ws[String.fromCharCode(fcloumn+4)+(frows+3)].s=
          ws[String.fromCharCode(fcloumn+7)+(frows+2)].s=
          ws[String.fromCharCode(fcloumn+7)+(frows+3)].s=
          ws[String.fromCharCode(fcloumn+8)+frows].s=
          ws[String.fromCharCode(fcloumn+8)+(frows+1)].s=
          ws[String.fromCharCode(fcloumn+8)+(frows+2)].s=
          ws[String.fromCharCode(fcloumn+8)+(frows+3)].s={
            border: {
              right: {
                style: 'thin'
              }
            },
          }


          ws[String.fromCharCode(fcloumn+3)+(frows+4)].s=
          ws[String.fromCharCode(fcloumn+6)+(frows+4)].s={
            border: {
              bottom: {
                style: 'thin'
              }
            },
          }

          ws[String.fromCharCode(fcloumn+4)+(frows+4)].s=
          ws[String.fromCharCode(fcloumn+7)+(frows+4)].s={
            border: {
              bottom: {
                style: 'thin'
              },
              right: {
                style: 'thin'
              }
            },
          }
        }

      }
    }
    
    XLSX.utils.book_append_sheet(wb, ws, ws_name) // 将数据添加到工作薄
  
    // 导出Excel, 注意这里用到的是XLSXS对象
    let wbout = XLSXS.write(wb, {
      bookType: 'xlsx',
      bookSST: false,
      type: 'binary'
    })
    FileSaver.saveAs(
      new Blob([s2ab(wbout)], {
        type: 'application/octet-stream'
      }),
      filename
    )
}


// 字符串转字符流---转化为二进制的数据流
const s2ab=(s)=>{
  if (typeof ArrayBuffer !== "undefined") {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xff;
    return buf;
  } else {
    const buf = new Array(s.length);
    for (let i = 0; i != s.length; ++i) buf[i] = s.charCodeAt(i) & 0xff;
    return buf;
  }
}
  


export { IncentiveExcel,AbsenteeismExcle }