import { defineStore } from 'pinia'

const useStore = defineStore('UserStores', {
  state: () => {
    return {
      empno:localStorage.getItem('empno'),//undefined
      userType:localStorage.getItem('userType'),
      token:localStorage.getItem('token'),
    }
  },

})

export default useStore