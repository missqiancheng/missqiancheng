<template>
    <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      :unique-opened="true"
      :collapse="ASideType"
      >
      <el-menu-item index="1" @click="AccordingDocument()">
        <el-icon><Document /></el-icon>
        <span>工單管理</span>
      </el-menu-item>
      <el-menu-item index="2" @click="RPMApplication()">
        <el-icon><Avatar /></el-icon>
        <span>智慧助手</span>
      </el-menu-item>
      <el-menu-item index="3">
        <el-icon><MessageBox /></el-icon>
        <span>報表中心</span>
      </el-menu-item>
      <el-menu-item index="4">
        <el-icon><Compass /></el-icon>
        <span>常見問題</span>
      </el-menu-item>
    </el-menu>
</template>
<script setup>
import { Document,Compass,Avatar,MessageBox
} from '@element-plus/icons-vue';
import {ref,inject} from 'vue'
import route from '/src/router'

const emit=defineEmits(['addTabs'])

const ASideType=inject('ASideType')

const RPMApplication=()=>{
  //emit("addTabs","獎懲申請","Application")
}

const AccordingDocument=()=>{
  //emit("addTabs","獎懲參考文件","AccordingDocument")
}

</script>

<style scoped>
.el-menu-item.is-active{
background-color: #daf2fe !important;
}
*{
user-select: none;
}
</style>