<template>
    <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      :collapse="ASideType"
    >
      <el-menu-item index="1">
        <el-icon><DocumentChecked /></el-icon>
        <span>終止派遣確認</span>
      </el-menu-item>
      <el-menu-item index="2">
        <el-icon><document /></el-icon>
        <span>終止派遣確認名單</span>
      </el-menu-item>
      <el-menu-item index="3">
        <el-icon><Search /></el-icon>
        <span>終止派遣進度查詢</span>
      </el-menu-item>
      <el-menu-item index="4">
        <el-icon><Aim /></el-icon>
        <span>終止派遣客服設定</span>
      </el-menu-item>
      <el-menu-item index="5">
        <el-icon><DocumentDelete /></el-icon>
        <span>終止派遣取消</span>
      </el-menu-item>
    </el-menu>
</template>

<script setup>
import { Document,DocumentDelete,DocumentChecked,Aim,Search
} from '@element-plus/icons-vue';
import { ref,inject } from 'vue'

const ASideType=inject('ASideType')
</script>

<style scoped>
.el-menu-item.is-active{
  background-color: #daf2fe !important;
}
*{
  user-select: none;
}
</style>