<template>
    <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      :collapse="ASideType"
    >
      <el-menu-item index="1">
        <el-icon><Coordinate /></el-icon>
        <span>宿舍消防演習管理</span>
      </el-menu-item>
      <el-menu-item index="2">
        <el-icon><Search /></el-icon>
        <span>狀態查詢</span>
      </el-menu-item>
      <el-menu-item index="3">
        <el-icon><DocumentChecked /></el-icon>
        <span>異常確認</span>
      </el-menu-item>
      <el-menu-item index="4">
        <el-icon><Files /></el-icon>
        <span>打卡信息維護</span>
      </el-menu-item>
      <el-menu-item index="5">
        <el-icon><Reading /></el-icon>
        <span>相信打卡查詢</span>
      </el-menu-item>
      <el-menu-item index="6">
        <el-icon><Memo /></el-icon>
        <span>分析報表</span>
      </el-menu-item>
    </el-menu>
</template>
<script setup>
import { Document,Coordinate,Search,Memo,Files,DocumentChecked,Reading
} from '@element-plus/icons-vue';
import {ref,inject} from 'vue'

const ASideType=inject('ASideType')
</script>

<style scoped>
.el-menu-item.is-active{
  background-color: #daf2fe !important;
}
*{
  user-select: none;
}
</style>