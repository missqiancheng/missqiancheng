<template>
  <!--添加表格-->
  <div :class="AddTable">
        
    <h2>新增資訊</h2>
  
    <div id="btn">
      <el-button id="seletbtn" @click="ShowAddBox()" type="primary">+新增</el-button>
    </div>
    
    <!--表单-->
    <el-table :data="Data" id="big-width"
              @row-click="OpenBulletin">
      <el-table-column type="selection" min-width="5%" prop="changes" fixed  />
      <el-table-column label="編號" type="index" min-width="8%" />
      <el-table-column label="標題" prop="ARTICLETITLE" min-width="37%" />
      <el-table-column label="申請人" prop="APPLICANT" min-width="10%"/>
      <el-table-column label="申請日期" prop="APPLICATIONTIME" min-width="10%"/>
      <el-table-column label="簽核狀態" prop="STATUS" min-width="10%"/>
      <el-table-column label="操作" min-width="20%">
        <template #default="scope">  
          <el-icon :size="IconSize" @click.stop="Signer(scope.$index, scope.row)">
            <img class="IconImage" :src="Applications" />
          </el-icon>
          <el-icon :size="IconSize">
            <img class="IconImage" :src="Select" />
          </el-icon>
          <el-icon :size="IconSize" @click.stop="DeleteBulletin(scope.$index, scope.row)">
            <img class="IconImage" :src="Update" />
          </el-icon>
          <el-icon :size="IconSize" @click.stop="DeleteBulletin(scope.$index, scope.row)">
            <img class="IconImage" :src="Delete" />
          </el-icon>
        </template>
      </el-table-column>
    </el-table>
    
    <!--分页框-->
    <div class="Pages">
      <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                     :total="DataCount" :background="true"
                     @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
    </div>
    
  </div>

  <!--添加表单-->
  <div :class="AddInput">
    <el-form-item label="标题：">
      <el-input v-model="FromInfo.title" placeholder="标题只能为繁体" />
    </el-form-item>
  
    <el-row>
      <el-col :span="12">
        <el-form-item label="文章來源：">
          <el-input v-model="FromInfo.Source" placeholder="文章來源只能为繁体" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="發佈單位：">
          <el-input class="ws" v-model="FromInfo.Department" placeholder="發佈單位只能为繁体" />
        </el-form-item>
      </el-col>
    </el-row>
  
    <div style="border: 1px solid #ccc;">
      <Toolbar
        style="border-bottom: 1px solid #ccc;"
        :editor="editorRef"
        :defaultConfig="toolbarConfig"
        :mode="mode"
      />
      <Editor
        :style="EditorCss"
        v-model="EditorData"
        :defaultConfig="editorConfig"
        :mode="mode"
        @onCreated="handleCreated"
      />
    </div>
    
    <el-button @click="CheckRequest()" type="primary" style="width: 33.3%;margin:auto;">保存</el-button>
    <el-button @click="Reset()" style="width: 33.3%; margin:auto;">重置</el-button>
    <el-button @click="HiddeAddBox()" style="width: 33.3%; margin:auto;">返回</el-button>
  </div>

    <!--具体公告弹窗-->
    <el-dialog
      v-model="dialogVisible"
      title="公告"
      width="80%"
      :destroy-on-close="true"
      :close-icon="CloseBold"
    >
      <h1 class="BulletinTitle">{{GuilderDiaLog.title}}</h1>
      <div class="Source">
        <span>文章來源：{{ GuilderDiaLog.ArticleSource }}</span>
        <span class="Department">發佈單位：{{ GuilderDiaLog.ApplicationDepartment }}</span>
        <span>發佈日期：{{ GuilderDiaLog.AnnouncedTime }}</span>
      </div>
      <div class="BulletinBody" v-html="GuilderDiaLog.Content"></div>
      <template #footer>
        <span class="dialog-footer"></span>
      </template>
    </el-dialog>

</template>

<script setup>
import { Axios } from '/src/Axios';
import { reactive, ref, watch, shallowRef,onBeforeUnmount  } from 'vue'
import { ElMessage,ElMessageBox,ElLoading } from 'element-plus'
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import '@wangeditor/editor/dist/css/style.css' // 引入 css
import axios from 'axios'
//图片
import Applications from '/public/image/Health/Application.png'
import Delete from '/public/image/Health/Delete.png'
import Select from '/public/image/Health/Select.png'
import Update from '/public/image/Health/Update.png'
import decrease from '/public/image/Health/decrease.png'

// #region 基本数据
//edit数据
const EditorData=ref('')
//标题
const FromInfo=reactive({
  title:'',
  Source:'',
  Department:''
})
//editer组件
const editorRef=shallowRef()
//富文本框默认内容
const editorConfig = {
  placeholder: '请输入内容...',
  //文件上传地址
  MENU_CONF:{
      uploadImage:{
          server: '/api/upload',
          base64LimitSize: 3000 * 1024 // 3000kb
      }
  },
}

//文本框css
const EditorCss='overflow-y: hidden;height: '+(window.innerHeight-338)+"px;"


//记录editor 实例
const handleCreated = (editor) => {
  editorRef.value = editor // 记录 editor 实例，重要！
}

//工具栏配置
const toolbarConfig = reactive({})

//默认配置
const mode='default'

// 组件销毁时，也及时销毁编辑器
onBeforeUnmount(() => {
  const editor = editorRef.value
  if (editor == null) return
  editor.destroy()
})

//图标样式
const IconSize=ref(45)

const tableData=reactive([])
// #endregion

// #region 事件验证
//限制验证
const CheckRequest=()=>{
  if(FromInfo.title==''||editorRef==''){
      ElMessageBox.alert('信息不能为空！','提示',{
        type: 'warning',
        draggable: true
      })
  }else{
      RequestBulletin()
  }
}
//提交公告请求
const RequestBulletin=()=>{
  const formData=new FormData()
  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)',
  })
  formData.append('Content', encodeURI(SettingMaxWidth(EditorData.value)))
  Axios({
      url:'HealthManagement/Application',
      method:'post',
      params:{
          Title:FromInfo.title,
          Source:FromInfo.Source,
          Department:FromInfo.Department
      },
      data:formData
  }).then(
      res=>{
          const data=res.data
          ElMessageBox.alert('提交成功！','提示',{
            type: 'success',
            draggable: true
          })
          loading.close()
          Reset()//重置文本框内容
      }
  ).catch(
      err=>{
          loading.close()
          console.log(err)
      }
  )
}

const SettingMaxWidth=(str)=>{
  // 解析字符串，并查找所有的 style 属性
  let regExp = /(style="[^"]*")/g;
  let matches = str.match(regExp);
  
  if (matches) {
    // 遍历所有的 style 属性字符串
    for (let i = 0; i < matches.length; i++) {
      let styleAttr = matches[i]; // style 属性字符串
  
      // 将字符添加到 style 属性字符串中
      let modifiedStyleAttr = styleAttr.replace(/"$/, 'max-width:100%;"');
  
      // 替换原字符串中的 style 属性
      str = str.replace(styleAttr, modifiedStyleAttr);
    }
  }
  return str
}

//重置按钮
const Reset=()=>{
  FromInfo.title=''
  FromInfo.Source=''
  FromInfo.Department=''
  EditorData.value=''
}

//获取待处理公告
const RequestArticle=()=>{
  Axios({
    url:'HealthManagement/GetAwaitInfo',
    method:'post',
  }).then(
    res=>{
      const data=res.data.Data
      console.log(data)
      for(let i=0;i<data.length;i++){
        tableData[i]=data[i]
      }//
      DataCount.value=data.length
      Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequestArticle()

const AddInput=ref('AddInput')
const AddTable=ref('')
//添加表格
const ShowAddBox=()=>{
  AddTable.value='AddInput'
  AddInput.value=''
}
const HiddeAddBox=()=>{
  AddInput.value='AddInput'
  AddTable.value=''
}

//删除公告
const DeleteBulletin=(index,rows)=>{
  ElMessageBox.confirm('確定要刪除目前公告嗎','提示',{
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      type: 'warning',
  }).then(()=>{
    RequestDelete(index,rows)
  }).catch(()=>{
    ElMessage({
      type: 'info',
      message: '删除取消',
    }) 
  })
}
const RequestDelete=(index,rows)=>{
  Axios({
    url:'HealthManagement/DeleteArticle',
    method:'post',
    params:{
      id:rows.HEALTHNO
    }
  }).then(
    res=>{
      const data=res.data
      ElMessage({
        type: 'success',
        message: '删除成功',
      }) 
      DataCount.value--
      Data.splice(index,1)
      tablesIndex=tableData.map(item=>item.HEALTHNO).indexOf(rows.HEALTHNO)
      tableData.splice(tablesIndex,1)
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//送签
const Signer=(index,rows)=>{
  ElMessageBox.confirm('確定要送簽目前公告嗎','提示',{
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      type: 'warning',
  }).then(()=>{
    RequestSigner(index,rows)
  }).catch(()=>{
    ElMessage({
      type: 'info',
      message: '送簽取消',
    }) 
  })
}
const RequestSigner=(index,rows)=>{
  Axios({
    url:'HealthManagement/SendSigner',
    method:'post',
    params:{
      HealthNo:rows.HEALTHNO,
    }
  }).then(
    res=>{
      rows.STATUS='待签核'
      console.log(res)
      
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion



// #region 查看公告
const dialogVisible=ref(false)
const OpenBulletin=(row)=>{
    GuilderDiaLog.title=row.ARTICLETITLE
    GuilderDiaLog.ArticleSource=row.ARTICLESOURCE
    GuilderDiaLog.ApplicationDepartment=row.APPLICATIONDEPARTMENT
    GuilderDiaLog.AnnouncedTime=row.ANNOUNCEDTIME
    axios({
        url:row.ARTICLECONTENT,
        method:'Get',
    }).then(
        res=>{
            GuilderDiaLog.Content=res.data
        }
    ).catch(
        err=>{
            console.log(err)
        }
    )
    dialogVisible.value=true
}
//弹窗公告数据
const GuilderDiaLog=reactive({
    title:'',
    Content:'',
    ArticleSource:'',
    ApplicationDepartment:'',
    AnnouncedTime:'',
})
// #endregion


// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}

// #endregion

</script>

<style scoped>
.el-input{
  width:80%;
}
.AddInput{
  display: none;
}

#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}

h2{
  font-size:35px;
  text-align: center;
  line-height:80px;
}

.BulletinTitle{
  font-size: 40px;
  text-align: center;
  margin-bottom:20px;
}

.BulletinBody{
  width: 90%;
  margin:auto;
}

.IconImage{
  width:33px;
  height: 33px;
}

.Source{
    text-align: center;
}
.Department{
    margin-left: 70px;
    margin-right: 70px;
}
</style>