<template>
      <el-menu
        :default-active="DefaultChange"
        class="el-menu-vertical-demo"
        :collapse="ASideType"
      >
      <el-sub-menu index="1">
          <template #title>
            <el-icon><KnifeFork /></el-icon>
            <span>健康資訊</span>
          </template>
            <el-menu-item index="AddHealth" @click="AddHealth()">
              <el-icon><DocumentAdd /></el-icon>
              <span>新增資訊</span>
            </el-menu-item>
            <el-menu-item index="IncentiveClosing" @click="IncentiveClosing()">
              <el-icon><Crop /></el-icon>
              <span>資訊審覈</span>
            </el-menu-item>
            <el-menu-item index="CompulsionSign" @click="CompulsionSign()">
              <el-icon><Search /></el-icon>
              <span>資訊查詢</span>
            </el-menu-item>
        </el-sub-menu>
        <el-menu-item index="AccordingDocument" @click="AccordingDocument()">
          <el-icon><Dish /></el-icon>
          <span>藥品管理</span>
        </el-menu-item>
        <el-menu-item index="Application" @click="RPMApplication()">
          <el-icon><Stamp /></el-icon>
          <span>體檢管理</span>
        </el-menu-item>
      </el-menu>
</template>

<script setup>
import { Stamp,Dish,KnifeFork,Crop,Search,DocumentAdd} from '@element-plus/icons-vue';

const emit=defineEmits(['addTabs'])

const AddHealth=()=>{
  const NavigationPath="AddHealth"
  emit("addTabs","新增資訊",NavigationPath)
  
}

</script>

<style>

</style>