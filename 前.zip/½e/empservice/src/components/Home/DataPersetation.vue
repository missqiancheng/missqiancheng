<template>
    <div>
      <div class="BoxTitle"><b>數據看板</b></div>
      <hr style="border-top:1px #0066CC;" />
    </div>
</template>

<script setup>
</script>

<style scoped>

div{
  height:500px;
}


.BoxTitle{
  height:45px;
  font-size:25px;
  padding-left: 20px;
  padding-top: 10px;
}

</style>