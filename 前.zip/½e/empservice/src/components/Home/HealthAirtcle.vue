<template>
    <!--main-->
    <div class="main">
        <div class="BoxTitle"><b>健康資訊</b></div>
        <hr style="border-top:1px #0066CC;" />
        <div class="ActionBox">
            <div class="ActionTitle" v-for="(item,index) in Data" :key="index" 
                 @click="OpenBulletin(item.ARTICLETITLE,item.ARTICLECONTENT,item.ARTICLESOURCE
                 ,item.APPLICATIONDEPARTMENT,item.ANNOUNCEDTIME)">
                <div class="ActionHeader">{{item.ARTICLETITLE}}</div>
                <div class="ActionDate">[{{item.ANNOUNCEDTIME}}]</div>
            </div>
        </div>
    </div>

    <!--分页框-->
    <div class="BulletinPages">
      <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                     :total="DataCount" :background="true" class="pages"
                     @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
    </div>

    <!--具体公告弹窗-->
    <el-dialog
      v-model="dialogVisible"
      title="公告"
      width="80%"
      :destroy-on-close="true"
      :close-icon="CloseBold"
    >
      <h1 class="BulletinTitle">{{GuilderDiaLog.title}}</h1>
      <div class="Source">
        <span>文章來源：{{ GuilderDiaLog.ArticleSource }}</span>
        <span class="Department">發佈單位：{{ GuilderDiaLog.ApplicationDepartment }}</span>
        <span>發佈日期：{{ GuilderDiaLog.AnnouncedTime }}</span>
      </div>
      <div class="BulletinBody" v-html="GuilderDiaLog.Content"></div>
      <template #footer>
        <span class="dialog-footer"></span>
      </template>
    </el-dialog>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { CloseBold } from '@element-plus/icons-vue'
import { Axios } from '/src/Axios'
import axios from 'axios'

//公告数据
const Guide=reactive([])
//请求公告数据
const RequestGuide=()=>{
    return new Promise((resolve,reject)=>{
        Axios({
            url:'HealthManagement/GetHealthArticle',
            method:'post'
        }).then(
            res=>{
                const data=res.data.Data
                for(let i=0;i<data.length;i++){
                    Guide[i]=data[i]
                }
                DataCount.value=data.length
                Data=reactive(JSON.parse(JSON.stringify(Guide)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
                resolve()
            }
        ).catch(
            err=>{
                resolve()
                console.log(err)
            }
        )
    })

}


//查看公告
const dialogVisible=ref(false)
const OpenBulletin=(title,path,Source,Department,Announced)=>{
    GuilderDiaLog.title=title
    GuilderDiaLog.ArticleSource=Source
    GuilderDiaLog.ApplicationDepartment=Department
    GuilderDiaLog.AnnouncedTime=Announced
    GuilderDiaLog.Content=path
    // axios({
    //     url:path,
    //     method:'GET',
    // }).then(
    //     res=>{
    //         GuilderDiaLog.Content=res.data
    //     }
    // ).catch(
    //     err=>{
    //         console.log(err)
    //     }
    // )
    dialogVisible.value=true
}
//弹窗公告数据
const GuilderDiaLog=reactive({
    title:'',
    Content:'',
    ArticleSource:'',
    ApplicationDepartment:'',
    AnnouncedTime:'',
})


// #region 分页功能
//总行数
const DataCount=ref(Guide.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(Guide)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(Guide)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(Guide)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}

// #endregion


defineExpose({RequestGuide})
</script>

<style scoped>
.main{
    user-select: none;
}
.BoxTitle{
  /*边框label移动 */
  height:45px;
  font-size:25px;
  padding-left: 20px;
  padding-top: 10px;
}
.ActionBox{
    width: 95%;
    margin: auto;
    padding-top: 10px;
}
.ActionTitle{
    font-size: 20px;
    margin: 5px;
    display: flex;
}
.ActionTitle:hover{
    color: #4db7e8;
}
.BulletinTitle{
    text-align: center;
    font-size: 30px;
    margin-bottom: 20px;
}
.BulletinPages{
    margin-top: auto; 
    height: 45px;
}
.pages{
    line-height: 45px;
}
.ActionDate{
    color:gray;
    flex:1;
    margin:auto;
}
.ActionHeader{
    flex: 10;
}
.ActionTitle:hover .ActionDate{
    color:#4db7e8;
}
.Source{
    text-align: center;
}
.Department{
    margin-left: 70px;
    margin-right: 70px;
}
</style>