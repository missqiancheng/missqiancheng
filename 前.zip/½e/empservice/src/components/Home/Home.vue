<template>
    <div>
        <div class="ShowIamge">
            <ShowImage ref="Image"></ShowImage>
        </div>
        <div class="GuideBox">
            <!--系统重要公告-->
            <div class="GuideItme"><ActionGuide ref="Guide"></ActionGuide></div>
            <!--健康信息-->
            <div class="GuideItme HealthBox"><HealthAirtcle ref="Health"></HealthAirtcle></div>
        </div>
        <div class="Persetation">
            <DataPersetation></DataPersetation>
        </div>
        <img class="image" src="/image/header.jpeg">
    </div>
</template>

<script setup>
import ShowImage from '/src/components/Home/ShowImage.vue'
import ActionGuide from '/src/components/Home/ActionGuide.vue'
import HealthAirtcle from '/src/components/Home/HealthAirtcle.vue'
import DataPersetation from '/src/components/Home/DataPersetation.vue'
import { onMounted,ref } from 'vue'

const Image=ref()
const Guide=ref()
const Health=ref()

onMounted(()=>{
    Guide.value.RequestGuide()  
    .then(guideResult => {  
        // 处理 guideResult，如果需要的话  
        return Health.value.RequestGuide();  
    })  
    .then(healthResult => {  
        // 处理 healthResult
        return Image.value.RequestImage();  
    })
    .catch(error => {  
        // 处理任何步骤中发生的错误  
        console.error("An error occurred:", error);  
    });
})

</script>

<style scoped>
.image{
    position:fixed;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    animation: imgAni 3s forwards;
    opacity: 0;
}
@keyframes imgAni{
    from {
        opacity: 1;
        visibility: visible;  
    }
    to {
        opacity: 0;
        visibility:hidden;
    }
}

.ShowIamge{
    width:97%;
    background-color: white;
    margin: auto;
    margin-top: 6px;
}

.GuideBox{
    width:97%;
    margin: auto;
    margin-top: 20px;
    display: flex;
}
.GuideItme{
    flex:1;
    background-color: white;
    display: grid;  
    grid-template-rows: auto 1fr; /* 第一行自适应，第二行占据剩余空间 */ 
}
.HealthBox{
    margin-left: 10px;
}

.Persetation{
    width:97%;
    background-color: white;
    margin: auto;
    margin-top: 20px;
    margin-bottom: 8px;
}
</style>