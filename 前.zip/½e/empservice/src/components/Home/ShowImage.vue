<template>
    <div class="TopBox">
      <div class="TopImage">
        <el-card :body-style="{ padding: '0px' }">
          <img
            :src="imgSrc[0].IMAGEPATH"
            class="image"
          />
          <div style="padding: 14px">
            <h2 class="imagetite">{{ imgSrc[0].IMAGENAME }}</h2>
            <div class="bottom">
              {{ imgSrc[0].CONTENT }}
            </div>
          </div>
        </el-card>
      </div>
      <div class="MiddieImage">
        <el-card :body-style="{ padding: '0px' }">
          <img
            :src="imgSrc[1].IMAGEPATH"
            class="image"
          />
          <div style="padding: 14px">
            <h2 class="imagetite">{{ imgSrc[1].IMAGENAME }}</h2>
            <div class="bottom">
              {{ imgSrc[1].CONTENT }}
            </div>
          </div>
        </el-card>
      </div>
      <div class="TopImage">
        <el-card :body-style="{ padding: '0px' }">
          <img
            :src="imgSrc[2].IMAGEPATH"
            class="image"
          />
          <div style="padding: 14px">
            <h2 class="imagetite">{{ imgSrc[2].IMAGENAME }}</h2>
            <div class="bottom">
              {{ imgSrc[2].CONTENT }}
            </div>
          </div>
        </el-card>
      </div>
    </div>
</template>

<script setup>
import { reactive,ref } from "vue"
import { Axios } from "../../Axios";
import { Picture,Document  } from '@element-plus/icons-vue';

const RequestImage=()=>{
  Axios({
    url:'HomePages/GetShowImage',
    method:'post',
  }).then(
    res=>{
      const data=res.data.Data
      //清空内容
      for(let i=0;i<imgSrc.length;i++){
        imgSrc[i].IMAGEPATH=''
        imgSrc[i].IMAGENAME=''
        imgSrc[i].CONTENT=''
      }
      //重新赋值
      for(let i=0;i<data.length;i++){
        imgSrc[data[i].SHOWIDE-1].IMAGEPATH=data[i].IMAGEPATH
        imgSrc[data[i].SHOWIDE-1].IMAGENAME=data[i].IMAGENAME
        imgSrc[data[i].SHOWIDE-1].CONTENT=data[i].IAMGEDETAILS
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

const imgSrc=reactive([
  {
    IMAGEPATH:'',
    IMAGENAME:'',
    CONTENT:''
  },
  {
    IMAGEPATH:'',
    IMAGENAME:'',
    CONTENT:''
  },
  {
    IMAGEPATH:'',
    IMAGENAME:'',
    CONTENT:''
  },
])


defineExpose({RequestImage})


</script>

<style scoped>
.TopBox{
  display: flex;
}
.BottomBox{
  display: flex;
}
.TopImage{
  flex: 1;
  border:1px solid black;
  margin: 5px;
}
.MiddieImage{
  flex: 1;
  border:1px solid black;
  margin: 5px;
}
.img{
  width:100%;
  height:100%;
}                                          
img{
  width:100%;
  height:100%;
}
.image-slot {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  background: var(--el-fill-color-light);
  color: var(--el-text-color-secondary);
  font-size: 30px;
}

.imagetite{
  text-align: center;
}
.bottom{
  margin:auto;
  text-align: center;
}
.image{
  height: 270px;
}
</style>