<template>
  <h2 class="table-title">獎懲參考文件</h2>
  <!--表单-->
  <el-table :data="documents" id="big-width" @cell-click="Download">
    <el-table-column label="序號" type="index" min-width="8%" />
    <el-table-column label="文件名稱" prop="NAME" min-width="20%"/>
    <el-table-column label="文件版本" prop="F_TYPE" min-width="17%" />
    <el-table-column label="生效日期" prop="F_EFFECTDATE" min-width="10%" />
    <el-table-column label="公告日期" prop="LOADTIME" min-width="10%" />
    <el-table-column label="原件" prop="FILE_NAME" min-width="10%">
      <template #default="scope">
        <el-icon @click="Downloadf(scope.row)" size="23" 
                 class="downloads"><Download /></el-icon>
      </template>
    </el-table-column>
  </el-table>
</template>

<script setup>
import {reactive} from 'vue'
import {Axios,Token,DownLoad} from '/src/Axios'
import { Download } from '@element-plus/icons-vue';


//文件数据《请求》
let documents=reactive([])

//请求数据
Axios({
  url:'IncentiveManage/AccordingDocument',//config
  method:"post",
}).then(
  res=>{
    const data=res.data.Data
    for(let i=0;i<data.length;i++){
      documents[i]=data[i]
    }
  }
).catch(
  err=>{
    console.log(err)
  }
)



//下载文件
const Downloadf=(url)=>{
  DownLoad(url.FILE_NAME,url.NAME)
}
</script>

<style scoped>
.bottom{
  margin-top: 13px;
  line-height: 12px;
  justify-content: space-between;
  align-items: center;
  
}

.button {
  padding: 0;
  min-height: auto;
  width:50px;
}

.image {
  width: 100%;
  display: block;
  height: 150px;
}
.el-col-8{
  max-width: 17%;
  margin: 20px;
  min-width:160px;
}

.downloads{
  color: #409eff;
}
.downloads:hover{
  color: orange;
}
</style>