<template>
  <h2 class="table-title">員工獎懲申請</h2>
  <el-form :model="form"  ref="baseForm" width="100%"
           label-width="140px" class="from" :rules="rules">

    <!--职业健康体检信息-->
    <div class="EMPBox" v-if="FindBox">
      <div class="BoxTitle" style="color:red;"><b>職業健康監護資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="empinfo">
        <!--第一行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="監護崗位名稱：">
              {{ FIndTable.Cause_harm }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="預計安排體檢日期：">
              {{ FIndTable.Pre_Me_Date }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="體檢地點：">
              {{ FIndTable.Me_Place }}
            </el-form-item>
          </el-col>
        </el-row>
        
        <!--第二行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="實際體檢時間：">
              {{ FIndTable.Me_Date }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="體檢結果：">
              {{ FIndTable.Me_Result }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="出席狀態：">
              {{ FIndTable.Need_ME }}
            </el-form-item>
          </el-col>
        </el-row>
         
        <!--第三行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="不體檢說明：">
              {{ FIndTable.Quit_Reason }}
            </el-form-item>
          </el-col>
          <el-col :span="8"></el-col>
        </el-row>
      </div>
    </div>

    <!--员工基本信息-->
    <div class="EMPBox">
      <div class="BoxTitle"><b>員工資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="empinfo">
        <!--第一行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="員工工號：" prop='emp_no'>
              <el-input v-model="form.emp_no" ref="empInputRef"
               @keyup.enter="EnterSubmit" @blur="FetchEmp" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="員工姓名：">
              <el-input v-model="form.name" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="目前工作擔當：" prop='duty'>
              <el-input v-model="form.duty" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第二行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="資位：">
              <el-input v-model="forms.f_grand" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="入職日期：">
              <el-input v-model="forms.f_departname" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="部門名稱：">
              <el-input  v-model="forms.f_infactorydate" readonly />
            </el-form-item>
          </el-col>
        </el-row>
    
        <!--第三行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="提報人：" prop='tbr'>
              <el-input v-model="form.tbr" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="提報人聯系方式：" prop='tbr_tel'>
              <el-input v-model="form.tbr_tel" />
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </div>
    
    <!--奖惩信息-->
    <div class="RPMBox">
      <div class="BoxTitle"><b>獎懲資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="RPMinfo">
        <!--第四行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="獎懲發生日期：" prop="f_occurdate">
              <el-config-provider :locale="zhCn">
                <el-date-picker placeholder="請選擇" v-model="form.f_occurdate" type="date" 
                              :disabled-date="disabledDate" @change="CheckOccurDate"
                              :shortcuts="shortcuts"/>
              </el-config-provider>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="獎懲依據：" prop="jc_yj">
              <el-select v-model="form.jc_yj" placeholder="請選擇">
                <el-option v-for="item in literature" :key="item.name" :label="item.name" :value="item.name" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第五行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="獎懲條例：" prop="jc_tl">
              <el-input v-model="form.jc_tl" readonly style="width:218px;" @click="SelectArticle" />
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="emptype">
            <!--申请类型-->
            <el-form-item label="申請類型：" prop="ApplicationType">
              <el-select v-model="form.ApplicationType" placeholder="請選擇">
                <el-option v-for="item in ApplicationType" :key="item.value" :label="item.value" :value="item.value" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第六行-->
        <el-row>
          <el-col :span="17">
            <el-form-item label="條例內容：">
              <el-input v-model="form.f_jcitemcontent" rows="4" readonly  type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第七行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="處理類別：">
              <label>{{form.jc_dj}}</label>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="獎懲類別：">
              <label>{{form.jc_type}}</label>
            </el-form-item>
          </el-col>
        </el-row>
        
        <!--第七行(隐藏)-->
        <el-row v-if="form.jc_dj==='開除'">
          <el-col :span="8">
            <el-form-item label="開除類型：">
              <label>{{form.f_delistype}}</label>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="曠工日期：" v-if="form.f_delistype==='曠工開除'">
              <label>{{form.absenteeismdate}}</label>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第八行-->
        <el-row>
          <el-col :span="17">
            <el-form-item label="獎懲原由：" prop="remark">
              <el-input v-model="form.remark" rows="4" type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第九行-->
        <el-row>
          <el-col :span="24">
            <el-form-item label="佐證材料：">
              <UpLoad ref="load"></UpLoad>
            </el-form-item>
          </el-col>
        </el-row>
        <!--提示-->
        <el-row>
          <div class="LoadPrompt">注意：該欄位只能上傳一個檔案，如果有多餘的檔案請壓縮後上傳。</div>
        </el-row>

        <!--第十行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="是否變更處理類別：">
              <el-switch
                v-model="form.f_changetype"
                class="mt-2"
                style="margin-left: 24px"
                inline-prompt
                :active-icon="Check"
                :inactive-icon="Close"
                :before-change="BeForeAlter"
              />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏一行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="8">
            <el-form-item label="變更等級：" prop="f_jcdj_new">
              <el-select v-model="form.f_jcdj_new" placeholder="請選擇">
                <el-option v-for="item in ChangeHandling" :key="item" :label="item" :value="item" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏二行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="17">
            <el-form-item label="變更類別原由：" prop="f_changereason">
              <el-input v-model="form.f_changereason" rows="4"  type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏三行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="8">
            <el-form-item label="證明材料：">
              <UpLoad ref="loadhidden"></UpLoad>
            </el-form-item>
          </el-col>
        </el-row>
        <!--提示-->
        <el-row v-if="form.f_changetype">
          <div class="LoadPrompt">注意：該欄位只能上傳一個檔案，如果有多餘的檔案請壓縮後上傳。</div>
        </el-row>

        <!--第十一行-->
        <el-row> 
          <el-col :span="8.5">
            <el-form-item label="員工年度獎懲信息：" class="aotoo">
              <el-collapse v-model="activeNames">
                <el-collapse-item title="" name="1">
                  <el-table :data="RPMYear" :row-class-name="tableRowClassName">     
                      <!--序号-->
                      <el-table-column prop="F_OCCURDATE"
                                       label="獎懲時間"
                                       width="110">
                      </el-table-column>
                      <el-table-column prop="JC_DJ"
                                       label="獎懲等級"
                                       width="100">
                      </el-table-column>
                  </el-table>
                </el-collapse-item>
              </el-collapse>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十二行-->
        <el-row>
          <el-col :span="24">
            <el-form-item label="申請流程：">
              <el-steps :active="0" align-center  style="width: 100%;">
                <el-step title="申請" description="申請人提報" :icon="Edit" />
                <el-step title="審核" description="課級主管" :icon="EditPen" />
                <el-step title="審核" description="部級主管" :icon="EditPen" />
                <el-step title="審核" description="人資主管" :icon="EditPen" v-if="form.jc_dj==='開除'" />
                <el-step title="會簽" description="群法務窗口" :icon="EditPen" v-if="form.jc_dj==='開除'" />
                <el-step title="審核" description="處級主管" :icon="EditPen" />
                <el-step title="核准" description="事業處最高主管" :icon="EditPen"
                v-if="form.jc_dj.includes('大過')||form.jc_dj=='開除'||
                form.jc_dj.includes('大功')||form.f_changetype===true" />
                <el-step title="核定" description="人資主管" :icon="EditPen" />
                <el-step title="會簽" description="工會簽核" :icon="EditPen" v-if="form.jc_dj==='開除'"/>
                <el-step title="公告" description="人資公告" :icon="DataLine" />
              </el-steps>
            </el-form-item>
          </el-col>
        </el-row>
  
      </div>
    </div>
     
    <!--提交按钮-->
    <el-form-item label-width="0px">
      <el-button @click="onSubmit(baseForm)" type="primary" class="subtn">提交</el-button>
      <el-button @click="resetForm(baseForm)" type="primary" class="subtn">重置</el-button>
    </el-form-item>
  </el-form>

  <!--奖惩条例查询弹出框-->
  <el-dialog v-model="dialogTableVisible" title="奖惩条例查询" :before-close="handleClose"
             width="80%" draggable>
    <div v-loading="LoadingOrdinace">
      <el-input type="text" v-model="SelectValue" class="empnos" placeholder="請輸入關鍵詞搜索" :suffix-icon="Search">
      </el-input>
      <el-table :data="ArticleSelect"  height="500px" @cell-click="handlesubmit">
        <el-table-column label="操作"  width="70">
          <template #default="scope">
            <el-button type="primary" :icon="Check" @click="handlesubmit(scope.row)" />
          </template>
        </el-table-column>
        <el-table-column type="index" label="序号" width="60" />
        <el-table-column property="f_jcitemtype" label="獎懲依據" width="200" />
        <el-table-column property="f_jctl" label="獎懲條例"  width="100" />
        <el-table-column property="f_jcitmecontent" label="獎懲條例內容"  width="400" />
        <el-table-column property="f_jcdj" label="處理類別" width="100" />
        <el-table-column property="f_jctype" label="獎懲類別" width="120" />
      </el-table>
    </div>
  </el-dialog>


</template>

<script setup>
//配置导入
import { ElNotification,ElMessageBox,ElLoading  } from 'element-plus'
import { onBeforeUnmount,reactive,ref,computed } from 'vue'
import { Check, Close,Edit,Search,EditPen,DataLine  } from '@element-plus/icons-vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
//组件以及自定义js导入
import UpLoad from '/src/pages/UpLoad.vue'
import {Axios,Headers} from '/src/Axios'


// #region 表单固定数据
//表单验证规则
const rules=reactive({

emp_no:[{
  required: true, message: '工號不能為空', trigger: 'blur'
}],


tbr_tel:[{
  required: true, message: '提報人電話不能為空', trigger: 'blur'
}],

f_occurdate:[{
  required: true, message: '獎懲發生日期不能為空', trigger: 'change'
}],

jc_yj:[{
  required: true, message: '獎懲依據不能為空', trigger: 'change'
}],

jc_tl:[{
  required: true, message: '獎懲條例不能為空', trigger: 'change'
}],

remark:[{
  required: true, message: '獎懲原由不能為空', trigger: 'blur'
}],

f_jcdj_new:[{
  required: true, message: '變更等級不能為空', trigger: 'change'
}],

f_changereason:[{
  required: true, message: '變更類別原由不能為空', trigger: 'blur'
}],

})

//提交类型
const ApplicationType=reactive([
  {
    value:'紙檔簽核'
  },
  {
    value:'調前記錄'
  },
  {
    value:'正常申请'
  }
])

//动态显示年度奖惩表格背景
const tableRowClassName=(row,rowIndex)=>{
  if(row.row.Grade==="大过一次"){
    return "TabBg"
  }else if(row.row.Grade==="大过二次"){
    return "TabBg"
  }
}

//时间选择器快捷选择数据
const shortcuts = [
  {
    text: '當天',
    value: new Date(),
  },
  {
    text: '昨天',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24)
      return date
    },
  },
  {
    text: '一周前',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
      return date
    },
  },
]

//禁止选择当前时间之前的日期
const disabledDate = (time) => {
  return time.getTime() > Date.now()
}


//
const activeNames=ref(1)
// #endregion 


// #region 温馨提示
//请求温馨提示
const requestTips=()=>{
  Axios({
    url:'IncentiveManage/GetTips',
    method:"post",
  }).then(
    res=>{
      const data=res.data.Data
      let i=1
      while(data[i]!=undefined){
        const obj={
          content:data[i]
        }
        tableData[i-1]=obj
        i++
      }
      Tips=UpdateTips()
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//温馨提示数据
const tableData=reactive([])

//调用请求函数
requestTips()

//更新温馨提示数据
const UpdateTips=()=>{
  //温馨提示内容
  const TipsContent=()=>{
    let content=""
    for(let i=0;i<tableData.length;i++){
      let index=i+1
      content=content+"<i style='color: red'>"+index+"."+tableData[i].content+"</i>"+'<br>'
    }
    return content
  }
  
  //温馨提示内容赋值
  let content=TipsContent()
  //温馨提示展示
  const Tips=ElNotification({
    title: '温馨提示',
    dangerouslyUseHTMLString: true,
    message: content,
    duration:0,
    offset:45
    
  })
  return Tips
}

//温馨提示框
let Tips

//生命周期卸载前
onBeforeUnmount(()=>{
  Tips.close()//关闭温馨提示框
})

// #endregion


// #region 请求数据

//表单绑定提交数据
const form = reactive({
  //@基本数据@
  //工号
  emp_no:'',
  //姓名
  name: '',
  //工作担当
  duty: '',
  //提报人
  tbr:localStorage.getItem('empno'),
  //提报人联系方式
  tbr_tel: '',
  
  //@奖惩数据@
  //1.奖惩发生日期
  f_occurdate: '',
  //2.奖惩依据单号
  f_jcitemno:'',
  //2.奖惩依据
  jc_yj:'',
  //3.奖惩条例
  jc_tl: '',
  //4.条款内容
  f_jcitemcontent:'',
  //5.处理类别
  jc_dj:'',//開除
  //6.奖惩类别
  jc_type:'',
  //7.奖惩原因
  remark:'',
  //8.相关自述材料
  file_name:'',
  //9.是否变更处理类别
  f_changetype: false,
  //隐藏1.变更类别等级
  f_jcdj_new:'',
  //隐藏2.变更类别理由
  f_changereason:'',
  //隐藏3.证明材料
  hr_file_name:'',
  //特殊提交：旷工日期
  absenteeismdate:'',
  //特殊提交：開除类型
  f_delistype:'',
  
  //人资权限提交：申请类型
  ApplicationType:'正常申请'
})

//表单显示非提交数据
const forms=reactive({
  //职位
  f_grand: '',
  //入职日期
  f_infactorydate: '',
  //部门名称
  f_departname:'',
  //员工类型
  f_emptype_use:''
})

//员工年度奖惩信息
const RPMYear=reactive([])

//通过工号获取员工信息  《请求》
const FetchEmp=()=>{
  FindBox.value=false
  form.f_occurdate=''
  form.jc_yj=''
  form.jc_dj=''
  form.jc_type=''
  form.jc_tl=''
  form.f_delistype=''
  form.absenteeismdate=''
  form.f_jcitemcontent=''
  if(form.emp_no===''){
    return
  }
  Axios({
    url:'IncentiveManage/GetEmpInfo',
    method:'Post',
    params:{
      empno:form.emp_no
    }
  }).then(
    res=>{
      const data=res.data
      if(data.Code==='500'){
        ElMessageBox.alert(data.Message+"!",'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
      }
      const info=data.Data.EmpInfo
      const YearIncentive=data.Data.YearIncentive
      form.name=info[0].F_NAME
      forms.f_grand=info[0].F_GRAND
      forms.f_infactorydate=info[0].F_DEPARTNAME
      forms.f_departname=info[0].F_INFACTORYDATE
      forms.f_emptype_use=info[0].F_EMPTYPE_USE
      for(let i=0;i<YearIncentive.length;i++){
        RPMYear[i]={
          F_OCCURDATE:YearIncentive[i].F_OCCURDATE,
          JC_DJ:YearIncentive[i].JC_DJ,
        }
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}


//rest清空表单
const resetForm = (formEl) => {
  if (!formEl) return
  form.name=''
  forms.f_grand=''
  forms.f_departname=''
  forms.f_infactorydate=''
  form.f_jcitemcontent=''
  formEl.resetFields()
}

//工号文本框  
const empInputRef = ref(null);
//回车触发失去焦点事件
const EnterSubmit=(e)=>{
  empInputRef.value.blur();
}

// #endregion

//
// #region 奖惩依据-条例
//奖惩依据选择数据  《请求》
const literature=reactive([])
//check发生日期
const CheckOccurDate=()=>{
  literature.length=0
  if(form.f_occurdate==''||form.f_occurdate==undefined){
    ElMessageBox.alert('請先選擇獎懲發生日期！','提示',{
      confirmButtonText: '確認',
      type: 'warning',
      draggable: true,
    })
  }else{
    RequestJC_tl()
  }
}
//发送条例请求
const RequestJC_tl=()=>{
  Axios({
    url:'IncentiveManage/IncentiveDocument',
    method:'post',
    params:{
      f_occurdate:form.f_occurdate
    }
  }).then(
    res=>{
      const data=res.data.Data
      for(let i=0;i<data.length;i++){
        literature[i]={
          name:data[i].NAME
        }
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//奖惩条例信息弹出框是否显示
let dialogTableVisible=ref(false)

//奖惩条例数据
const Article = reactive([])
const ArticleSelect=computed(()=>{
  return Article.filter((data)=>!SelectValue.value
  ||data['f_jcitemtype'].includes(SelectValue.value)
  ||data['f_jctl'].includes(SelectValue.value)
  ||data['f_jcitmecontent'].includes(SelectValue.value)
  ||data['f_jcdj'].includes(SelectValue.value)
  ||data['f_jctype'].includes(SelectValue.value))
})

//奖惩条件
let SelectValue=ref()

//加载中
const LoadingOrdinace=ref(true)
//关闭弹窗
const handleClose=(close)=>{
  LoadingOrdinace.value=true
  close()
}

//查询奖惩条例  《请求》
const SelectArticle=async()=>{
  if(form.jc_yj===''){
    ElMessageBox.alert('請先選擇獎懲依據！','提示',{
        confirmButtonText: '確認',
        type: 'warning',
        draggable: true,
      })
  }else{
    await new Promise((reslove,reject)=>{
      dialogTableVisible.value=true
      reslove()
    })
    RequestOrdinace()
  }
}
const RequestOrdinace=()=>{
  Axios({
    url:'IncentiveManage/GetOrdinace',
    method:'post',
    params:{
      jc_yj:form.jc_yj
    }
  }).then(
    res=>{
      Article.length=0
      LoadingOrdinace.value=false
      const data=res.data.Data
      for(let i=0;i<data.length;i++){
        Article[i]={
          f_jcitemno:data[i].F_JCITEMNO,
          f_jcitemtype: data[i].F_JCITEMTYPE,
          f_jctl: data[i].F_JCTL,
          f_jcitmecontent: data[i].F_JCITEMCONTENT,
          f_jcdj: data[i].F_JCDJ,
          f_jctype: data[i].F_JCTYPE,
        }
      }
      
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//验证开关能否打开事件
const BeForeAlter=()=>{
  if(form.jc_tl===''){
    ElMessageBox.alert('請先選擇變更前獎懲條例！','提示',{
      confirmButtonText: '確認',
      type: 'warning',
      draggable: true,
    })
    return false
  }else{
    return true
  }
}


//变更等级多选框数据
let ChangeHandling=reactive([])
//选择奖惩条例  《请求》
const handlesubmit=(row)=>{
  if(form.emp_no==''){
    ElMessageBox.alert("請先填寫工號資訊!",'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
    return
  }
  if(forms.f_emptype_use==='派遣工'&&row.f_jcdj){
    ElMessageBox.alert("派遣工不能提報開除!",'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
    return
  }
  form.jc_type=''
  form.f_delistype=''
  form.f_jcitemno=row.f_jcitemno
  form.jc_tl=row.f_jctl
  form.f_jcitemcontent=row.f_jcitmecontent
  form.jc_dj=row.f_jcdj
  form.jc_type=row.f_jctype
  if(form.jc_dj==='開除'){
    if(form.jc_type.includes('曠工開除')){
      form.f_delistype='曠工開除'
      //请求旷工日期
      RequestAbsent()
    }else{
      form.f_delistype='違紀開除'
    }
    CheckFind()
  }
  if(form.jc_dj==='嘉獎一次'||form.jc_dj==='小功一次'||form.jc_dj==='大功一次'){
    ChangeHandling=reactive(['嘉獎一次','小功一次','大功一次'])
    ChangeHandling.splice(ChangeHandling.indexOf(form.jc_dj),1)
  }else{
    ChangeHandling=reactive(['警告一次','小過一次','大過一次','警告二次','小過二次','大過二次'])
    ChangeHandling.splice(ChangeHandling.indexOf(form.jc_dj),1)
  }
  dialogTableVisible.value=false
  //
}
//请求旷工日期
const RequestAbsent=()=>{
  Axios({
    url:'IncentiveManage/GetAbsenteeism',
    method:'post',
    params:{
      f_empno:form.emp_no
    }
  }).then(
    res=>{
      const data=res.data
      if(data.Code==="500"){
        ElMessageBox.alert('该工号不能提报旷工開除！','提示',{
          confirmButtonText: '確認',
          type: 'warning',
          draggable: true,
        })
      }else{
        form.absenteeismdate=data.Data
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
//是否显示职业健康监控box
const FindBox=ref(false)
//职业健康内容
const FIndTable=reactive({
  Cause_harm:'',//岗位名称
  Pre_Me_Date:'',//預計安排體檢日期
  Me_Place:'',//體檢地點
  Me_Date:'',//實際體檢時間
  Me_Result:'',//體檢結果
  Need_ME:'',//体检状态
  Quit_Reason:'',//不體檢說明
}) 
//判断员工是否为职业健康监控岗位
const CheckFind=()=>{
  const forms=new FormData()
  Axios({
    url:'IncentiveManage/GetEmpFind',
    method:'post',
    params:{
      f_empno:form.emp_no
    }
  }).then(
    res=>{
      if(res.data.Message!=''){
        const data=res.data.Data[0]
        FindBox.value=true
        FIndTable.Cause_harm=res.data.Message
        FIndTable.Pre_Me_Date=data.Pre_ME_date
        FIndTable.Me_Date=data.Me_Date
        FIndTable.Me_Place=data.ME_Place
        FIndTable.Me_Result=data.Me_Result
        FIndTable.Need_ME=(data.Need_ME=='Y')?'出席':'未出席'
        FIndTable.Quit_Reason=data.Quitme_Remark
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
} 
// #endregion


// #region 提交
//获取表单元素
const baseForm=ref(null)
//变更提交附件
const loadhidden=ref()
//提交附件
const load=ref()
//获取文件
const getfile=()=>{
  load.value.submitUpload()
  form.file_name=load.value.getfile()
  if(form.f_changetype){
    loadhidden.value.submitUpload()
    form.hr_file_name=loadhidden.value.getfile()
  }
}

//提交申请  《请求》
const onSubmit=(formEl)=>{
  baseForm.value.validate((valid) => {
    if (valid) {
      getfile()//工号
      if(form.name===''){
        ElMessageBox.alert('請輸入正確的工號！','提示',{
          confirmButtonText: '確認',
          type: 'warning',
           draggable: true,
        })
      }else if(form.f_delistype==='曠工開除'&&form.absenteeismdate===""){
        ElMessageBox.alert('該工號不能提報曠工提名！','提示',{
          confirmButtonText: '確認',
          type: 'warning',
          draggable: true,
        })
      }else{//文件
        if(form.file_name===undefined&&!(form.jc_dj.includes('嘉獎')||form.jc_dj.includes('警告'))){//上传成功删除表单字段获取的文件
          ElMessageBox.alert('小功及以上等級，小過及以上等級必須上傳佐證材料！','提示',{
            confirmButtonText: '確認',
            type: 'warning',
            draggable: true,
          })
        }else if(form.f_changetype&&form.hr_file_name===undefined){
          ElMessageBox.alert('變更獎懲等級需要上傳證明材料！','提示',{
            confirmButtonText: '確認',
            type: 'warning',
            draggable: true,
          })
        }else{//时间
          const djlist=['大功一次','大過二次','大過一次','開除']
          const days=(new Date()-Date.parse(form.f_occurdate))/(1*24*60*60*1000)
          if(djlist.includes(form.jc_dj)&&days>180){
            ElMessageBox.alert('大過類型的獎懲單只能申請獎懲時間未180天以內的！','提示',{
              confirmButtonText: '確認',
              type: 'warning',
              draggable: true,
            })
          }else if(!djlist.includes(form.jc_dj)&&days>60){
            ElMessageBox.alert('小過類型的獎懲單只能申請獎懲時間未180天以內的！','提示',{
              confirmButtonText: '確認',
              type: 'warning',
              draggable: true,
            })
          }else{
            requestSubmit(formEl)
          }
        }
      }
    } else {console.log("未通过")}
  })
}
const requestSubmit=(formEl)=>{
  //锁屏
  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)',
  })
  let fromdata=new FormData()
  if(form.file_name!='') fromdata.append('file_name',form.file_name)
  if(form.hr_file_name!='') fromdata.append('hr_file_name',form.hr_file_name)
  Axios({
    url:'IncentiveManage/ApplicationIncentive',
    method:'post',
    params:{
      emp_no:form.emp_no,
      name:form.name,
      duty:form.duty,
      tbr:form.tbr,
      tbr_tel:form.tbr_tel,
      f_occurdate:form.f_occurdate,
      f_jcitemno:form.f_jcitemno,
      jc_yj:form.jc_yj,
      jc_tl:form.jc_tl,
      f_jcitemcontent:form.f_jcitemcontent,
      jc_dj:form.jc_dj,
      jc_type:form.jc_type,
      remark:form.remark,
      f_changetype:form.f_changetype,
      f_jcdj_new:form.f_jcdj_new,
      f_changereason:form.f_changereason,
      absenteeismdate:form.absenteeismdate,
      f_delistype:form.f_delistype,
      ApplicationType:form.ApplicationType,
      f_isspecialstation:FindBox==true?'Y':'N'
    },
    headers:Headers,
    data:fromdata
  }).then(
    res=>{
      FindBox.value=false
      //关闭锁屏
      loading.close()
      const data=res.data
      if(data.Code==='200'){
        ElMessageBox.alert("提交成功!",'提示',
        {confirmButtonText: '確認',
        type: 'success',draggable: true})
        form.name=''
        forms.f_grand=''
        forms.f_departname=''
        forms.f_infactorydate=''
        form.jc_dj=''
        form.jc_type=''
        form.f_jcitemcontent=''
        form.f_changetype=false
        formEl.resetFields()
        load.value.ClearList()
        if(form.f_changetype) loadhidden.value.ClearList()
      }
    }
  ).catch(
    err=>{
      FindBox.value=false
      //关闭锁屏
      loading.close()
      console.log(err)
    }
  )
}

// #endregion 


//工号权限  《请求》
const userType=localStorage.getItem('userType')
const emptype=ref(userType==='3'||userType==='41')


</script>

<style scoped>

*{
  user-select: auto;
}

.el-input{
  width:auto;
}

/*表单整体样式 */
.from{
  width: 98%;
  margin:auto;
}
.el-textarea{
  width: 89%;
}

/*员工信息边框 */
.empinfo{
  border:0px;
  padding-top:20px;
  width:90%;
  margin:auto;
}

/* RPM边框 */
.RPMinfo{
  margin:auto;
  width:90%;
  padding-top:20px;
}

/*边框label样式 */
.BoxTitle{
  /*边框label移动 */
  width: 500px;
  height:40px;
  font-size:20px;
  padding-left: 20px;
  padding-top: 10px;
}

/*提交按钮样式 */
.subtn{
  margin:auto;
  width:33.3%;
  height:50px;
  margin-top: 15px;
}

/*模板框 */
.EMPBox{
  background: white;
  width:100%;
  height: 260px;
  margin-bottom: 20px;
}
.RPMBox{
  background: white;
  width:100%;
}
.LoadPrompt{
  margin-left: 140px;
  color:red;
}

</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}

</style>