
<template>
  <h2 class="table-title">強制獎懲簽核</h2>
  
  <!--头部查询框-->
  <div id="btn">
  </div>

  <!--表单-->
  <el-table :data="Data" id="big-width" @row-click="RequestHostroy">
    <el-table-column label="序號" type="index" width="80" fixed />
    <el-table-column label="工號" prop="emp_no" width="100" fixed />
    <el-table-column label="姓名" prop="name" width="120" fixed />
    <el-table-column label="獎懲等級" prop="jc_dj" width="100" />
    <el-table-column label="年資" prop="INFACTORY" width="100" />
    <el-table-column label="資位" prop="f_grand" width="120" />
    <el-table-column label="部門名稱" prop="f_departname" width="275" />
    <el-table-column label="提報人" prop="tbr" width="120" />
    <el-table-column label="提報日期" prop="EDITTIME" width="150" />
    <el-table-column label="受理狀態" prop="status" width="120" />
    <el-table-column label="操作" fixed="right" width="160">
      <template #default="scope">
        <el-button size="small" type="primary">詳情</el-button>
        <el-button size="small" type="danger" 
                   @click.stop="OverRule(scope.$index, scope.row)">強制駁回</el-button>
      </template>
    </el-table-column>
  </el-table>
  
  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>
  
  <!--驳回对话框-->
  <el-dialog v-model="OverRuleVisible" title="提示" width="30%" :close-icon="CloseBold" draggable> 
    <template #default>
      <el-form :model="OverRuleFormData" :rules="OverRules" ref="OverRuleForm">
        <el-form-item label="簽核意見：" prop="Reson">
          <el-input v-model="OverRuleFormData.Reson" type="textarea" />
        </el-form-item>
      </el-form>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="OverRuleVisible=false">取消</el-button>
        <el-button type="primary" @click="OverRuleSubmit()">駁回</el-button>
      </div>
    </template>
  </el-dialog>

  <!--单据明细查询框-->
  <el-dialog v-model="HoistoryDialog" title="獎懲單據明細" width="70%" :close-icon="CloseBold" style="background-color: #e8e4e4;">
    <template #default>
      <History ref="HistoryBox"></History>
    </template>
    <template #footer>
    </template>
  </el-dialog>
   

</template>

<script setup>
import {  ref,reactive,nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { Loading, Search, CloseBold } from '@element-plus/icons-vue'
import UpLoad from '/src/pages/UpLoad.vue'
import { Axios,DownLoad } from '/src/Axios'
import History from '/src/pages/Histroy.vue'

//#region 固定数据
//记录组件
//签核记录dialog框
const HoistoryDialog=ref()

//驳回表单check
const OverRules=reactive({
  Reson:[{
    required: true, message: '簽核意見不能為空', trigger: 'blur'
  }]
})

//驳回表单数据
const OverRuleFormData=reactive({
  index:'',
  apply_no:'',
  Reson:'',
  
})

//驳回提示框
const OverRuleVisible=ref(false)

//驳回表单
const OverRuleForm=ref()

//全部数据 《请求》
let tableData = reactive([])
//#endregion


// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
// #endregion


// #region 请求
//获取待签核数据
const RequsetCompuls=()=>{
  Axios({
    url:'IncentiveManage/GetMandatory',
    method:'post',
  }).then(
    res=>{
      const data=res.data
      const Tables=data.Data
      tableData.length=0
      for(let i=0;i<Tables.length;i++){
        tableData[i]={
          apply_no: Tables[i].APPLY_NO,
          emp_no: Tables[i].EMP_NO,
          name: Tables[i].NAME,
          duty: Tables[i].DUTY,
          f_grand: Tables[i].F_GRAND,
          f_departname: Tables[i].F_DEPARTNAME,
          EDITTIME: Tables[i].EDITTIME,
          tbr: Tables[i].TBR,
          tbr_tel: Tables[i].TBR_TEL,
          signtime: Tables[i].SIGNERTIME,
          remark: Tables[i].REMARK,
          file_name: Tables[i].FILE_NAME,
          jc_yj: Tables[i].JC_YJ,
          jc_tl: Tables[i].JC_TL,
          f_jcitemcontent: Tables[i].F_JCITEMCONTENT,
          jc_dj: Tables[i].JC_DJ,
          jc_type: Tables[i].JC_TYPE,
          f_delistype: Tables[i].F_DELISTYPE,
          absenteeismdate: Tables[i].F_ABSENTDATE,
          f_changetype: Tables[i].F_CHANGETYPE,
          f_jcdj_new: Tables[i].F_JCDJ_NEW,
          f_changereason: Tables[i].F_CHANGEREASON,
          hr_file_name: Tables[i].HR_FILE_NAME,
          signer:Tables[i].SIGNER,
          agent:Tables[i].AGENT,
          status:Tables[i].STATUS,
          time_year:Tables[i].TIME_YEAR,
          healthy:Tables[i].F_ISSPECIALSTATION,//体检状态
          INFACTORY:Tables[i].INFACTORY,
          Signers:undefined,//签核记录
          IncentiveYear:undefined,//年度奖惩信息
        }
      }
      DataCount.value=tableData.length
      Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequsetCompuls()

const HistoryBox=ref()
//请求hostroy数据
const RequestHostroy=(rows,type)=>{
  HoistoryDialog.value=true
  nextTick(()=>{
    HistoryBox.value.RequestHostory(rows.apply_no,rows.emp_no,rows.time_year)
  })
}

//驳回
const OverRule=(index,row)=>{
  OverRuleFormData.index=index
  OverRuleFormData.apply_no=row.apply_no
  OverRuleVisible.value=true
}

//驳回《请求》
const OverRuleSubmit=()=>{
  OverRuleForm.value.validate((valid) => {
    if(valid){
      const index=(pages.value-1)*PagesColumn.value+OverRuleFormData.index
      tableData.splice(index,1)
      Data.splice(OverRuleFormData.index,1)
      RequestReject()
      OverRuleVisible.value=false
    }else{}
  })
}
//驳回请求
const RequestReject=()=>{
  Axios({
    url:'IncentiveManage/Reject',
    method:'post',
    params:{
      apply_no:OverRuleFormData.apply_no,
      MEMO:OverRuleFormData.Reson
    }
  }).then(
    res=>{
      const data=res.data
      ElMessage({
        type: 'success',
        message: '已駁回',
      })
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

// #endregion

</script>

<style scoped>
.disbolk {
  background-color: gray;
  border: gray;
  /*禁用按钮*/
  pointer-events: none;
}

.demo-table-expand{
  margin-top:20px;
}

td div{
  text-align:left;
  margin-left:20px;
}
.el-form-item{
  width:100%;
}
</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}
</style>