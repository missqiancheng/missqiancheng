
<template>
  <h2 class="table-title">獎懲結案</h2>
  
  <!--头部查询框-->
  <div id="btn">
    <el-button id="seletbtn" @click="AllPass()" type="primary">批量結案</el-button>
    <el-button id="seletbtn" @click="SelectDialog=true" type="primary">查询</el-button>
    <el-button id="seletbtn" @click="ExportDcoument()" type="primary">導出獎懲單</el-button>
    <el-button id="seletbtn" @click="ExportAbsenteeism()" type="primary">導出曠工單</el-button>
  </div>

  <!--表单-->
  <el-table :data="Data" id="big-width"  @selection-change="changeColumn"
            @row-click="RequestHostroy"  :cell-style="setCellColor">
    <el-table-column type="selection" width="55" prop="changes" fixed  />
    <el-table-column label="序號" type="index" width="80" fixed />
    <el-table-column label="工號" prop="emp_no" width="100" fixed />
    <el-table-column label="姓名" prop="name" width="120" fixed />
    <el-table-column label="獎懲等級" prop="jc_dj" width="100" />
    <el-table-column label="職業健康體檢" prop="healthy" width="110" />
    <el-table-column label="年資" prop="infactory" width="120" />
    <el-table-column label="資位" prop="f_grand" width="120" />
    <el-table-column label="部門名稱" prop="f_departname" width="200" />  
    <el-table-column label="提報人" prop="tbr" width="120" />
    <el-table-column label="提報日期" prop="edittime" width="120" />
    <el-table-column label="受理狀態" prop="status" width="120" />
    <el-table-column label="操作" fixed="right" width="140">
      <template #default="scope">
        <el-button size="small" type="primary">詳情</el-button>
        <el-button size="small" type="primary"
                   @click.stop="Pass(scope.$index, scope.row)">結案</el-button>
      </template>
    </el-table-column>
  </el-table>
  
  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>

    <!--查询框-->
    <el-dialog v-model="SelectDialog" title="選擇查詢條件" width="35%" style="min-width: 700px;"
              :close-icon="CloseBold" :close-on-click-modal="false"  draggable>
      <el-form :model="form" label-width="120px">
        <!--第一行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="員工工號：">
                  <el-input v-model="form.empno" autocomplete="off" placeholder="查詢多個用英文字符，隔開" />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="員工姓名：">
                  <el-input v-model="form.name" autocomplete="off" />
                </el-form-item>
            </el-col>
        </el-row>

        <!--第二行-->
        <el-form-item label="獎懲提報日期：">
          <el-config-provider :locale="zhCn">
            <el-date-picker v-model="form.editdate" type="daterange" range-separator="To"
                            start-placeholder="開始日期" end-placeholder="結束日期" 
                            :shortcuts="shortcuts" size="default" unlink-panels
                            value-format="YYYY-MM-DD"/>
          </el-config-provider>
        </el-form-item>

        <!--第三行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="獎懲類型：">
                    <el-select v-model="form.jc_type" placeholder="請選擇" clearable>
                        <el-option v-for="item in jc_typs" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="獎懲等級：">
                    <el-select v-model="form.jc_dj" placeholder="請選擇" clearable>
                        <el-option v-for="item in jc_djs" :key="item.name" :label="item.name" :value="item.value" />
                    </el-select>
                </el-form-item>
            </el-col>
        </el-row>
        
        <!--第四行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="廠區：">
                    <el-select v-model="form.plant" placeholder="請選擇" clearable>
                        <el-option v-for="item in plants" :key="item.name" :label="item.name" :value="item.value" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="在職狀態：">
                    <el-select v-model="form.f_isleave" placeholder="請選擇" clearable>
                        <el-option label="離職" value="Y" />
                        <el-option label="在職" value="N" />
                    </el-select>
                </el-form-item>
            </el-col>
        </el-row>

        <!--第五行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="開除類型：">
                    <el-select v-model="form.ExpelType" placeholder="請選擇" clearable>
                      <el-option label="違紀開除" value="違紀開除" />
                      <el-option label="曠工開除" value="曠工開除" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="職業健康體檢：">
                    <el-select v-model="form.f_isspecialstation" placeholder="請選擇" clearable>
                      <el-option label="Y" value="Y" />
                      <el-option label="N" value="N" />
                    </el-select>
                </el-form-item>
            </el-col>
        </el-row>
        
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="SelectIncentive()">查询</el-button>
        </span>
      </template>
    </el-dialog>

    <!--单据明细查询框-->
    <el-dialog v-model="HoistoryDialog" title="獎懲單據明細" width="70%" :destroy-on-close="true"
               :close-icon="CloseBold" style="background-color: #e8e4e4;">
      <template #default>
        <History ref="HistoryBox"></History>
      </template>
      <template #footer>
      </template>
    </el-dialog>

  <el-dialog v-model="DetailsDialog" title="綁定獎懲檔" width="50%" :close-icon="CloseBold" draggable> 
    <template #default>
      <el-form>
        <el-form-item label="獎懲自述材料：">
          <UpLoad ref="load"></UpLoad>
        </el-form-item>
      </el-form>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="checkFiles()">綁定</el-button>
        <el-button @click="DetailsDialog=false">取消</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import {  ref,reactive,nextTick } from 'vue'
import { ElMessage,ElMessageBox,ElLoading } from 'element-plus'
import { Loading, Search,CloseBold } from '@element-plus/icons-vue'
import UpLoad from '/src/pages/UpLoad.vue'
import { Axios,DownLoad,Headers } from '/src/Axios'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import History from '/src/pages/Histroy.vue'
import { IncentiveExcel,AbsenteeismExcle } from '/src/ExportExcel' 

// #region 固定数据
//全部数据 《请求》
let tableData = reactive([])

//奖惩记录框
const HistoryBox=ref()

//奖惩记录dialog
const HoistoryDialog=ref(false)

//选中的表格数据
let ChangesData=reactive([])
//获取选中数据
const changeColumn=(value)=>{
  ChangesData=value
}

//查询框
const SelectDialog=ref(true)

//查询框数据
const form=reactive({
  empno:'',//工号
  name:'',//姓名
  editdate:null,//编辑日期
  jc_type:'',//奖惩类型
  jc_dj:'',//奖惩等级
  plant:'',//厂区
  f_isleave:'',//是否离职
  ExpelType:'',//开除类型
  f_isspecialstation:''//是否体检
})
//奖惩类型选项
const jc_typs=[
  {name:'表現優秀',value:'表現優秀'},
  {name:'違反工作紀律',value:'違反工作紀律'},
  {name:'違反生活紀律',value:'違反生活紀律'},
  {name:'品行操守不良',value:'品行操守不良'},
  {name:'違法或犯罪嫌疑',value:'違法或犯罪嫌疑'},
  {name:'違反資訊安全',value:'違反資訊安全'},
  {name:'違反安全事故',value:'違反安全事故'},
  {name:'違反工作紀律(曠工開除)',value:'違反工作紀律(曠工開除)'},
]
//奖惩等级选项
const jc_djs=[
  {name:'嘉獎一次',value:'嘉獎一次'}, 
  {name:'小功一次',value:'小功一次'}, 
  {name:'大功一次',value:'大功一次'}, 
  {name:'警告一次',value:'警告一次'}, 
  {name:'小過一次',value:'小過一次'}, 
  {name:'大過一次',value:'大過一次'}, 
  {name:'開除',value:'開除'}, 
  {name:'警告二次',value:'警告二次'}, 
  {name:'小過二次',value:'小過二次'}, 
  {name:'大過二次',value:'大過二次'}, 
]
//厂区选项
const plants=[
    {name:'龙华',value:'001'},
    {name:'杭州',value:'002'},
    {name:'重庆',value:'005'},
    {name:'南宁',value:'003'}
]

//快捷日期选择
const shortcuts = [
  {
    text: '上個星期',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      return [start, end]
    },
  },
  {
    text: '上個月',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      return [start, end]
    },
  },
  {
    text: '最近 3 個月',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      return [start, end]
    },
  },
]
// #endregion


// #region 请求
//查询结案信息
const SelectIncentive=()=>{
  RequestClosing()
}
//请求待结案数据
const RequestClosing=()=>{
  Axios({
    url:'IncentiveManage/GetClosing',
    method:'post',
    params:{
      empno:form.empno,
      name:form.name,
      jc_type:form.jc_type,
      jc_dj:form.jc_dj,
      plant:form.plant,
      StartTime:(form.editdate!=null)?form.editdate[0]:'',//时间间隔
      EndTime:(form.editdate!=null)?form.editdate[1]:'',//时间间隔
      f_isleave:form.f_isleave,
      ExpelType:form.ExpelType,
      f_isspecialstation:form.f_isspecialstation,
    }
  }).then(
    res=>{
      const data=res.data
      const Tables=data.Data
      tableData.length=0
      for(let i=0;i<Tables.length;i++){
        tableData[i]={
          apply_no: Tables[i].APPLY_NO,
          emp_no: Tables[i].EMP_NO,
          name: Tables[i].NAME,
          duty: Tables[i].DUTY,
          f_grand: Tables[i].F_GRAND,
          f_departname: Tables[i].F_DEPARTNAME,
          infactory: Tables[i].INFACTORY,
          edittime: Tables[i].EDITTIME,
          tbr: Tables[i].TBR,
          tbr_tel: Tables[i].TBR_TEL,
          signtime: Tables[i].SIGNERTIME,
          remark: Tables[i].REMARK,
          file_name: Tables[i].FILE_NAME,
          jc_yj: Tables[i].JC_YJ,
          jc_tl: Tables[i].JC_TL,
          f_jcitemcontent: Tables[i].F_JCITEMCONTENT,
          jc_dj: Tables[i].JC_DJ,
          jc_type: Tables[i].JC_TYPE,
          f_delistype: Tables[i].F_DELISTYPE,
          absenteeismdate: Tables[i].F_ABSENTDATE,
          f_changetype: Tables[i].F_CHANGETYPE,
          f_jcdj_new: Tables[i].F_JCDJ_NEW,
          f_changereason: Tables[i].F_CHANGEREASON,
          hr_file_name: Tables[i].HR_FILE_NAME,
          signer:Tables[i].SIGNER,
          agent:Tables[i].AGENT,
          status:Tables[i].STATUS,
          time_year:Tables[i].TIME_YEAR,
          healthy:Tables[i].F_ISSPECIALSTATION,//体检状态
          Signers:undefined,//签核记录
          IncentiveYear:undefined,//年度奖惩信息
        }
      }
      SelectDialog.value=false
      DataCount.value=tableData.length
      Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  ) 
}

//请求hostroy数据
const RequestHostroy=(rows,type)=>{
  HoistoryDialog.value=true
  nextTick(()=>{
    HistoryBox.value.RequestHostory(rows.apply_no,rows.emp_no,rows.time_year)
  })
}

const load=ref()
const DetailsDialog=ref(false)
const DetailsDat=reactive({
  index:'',
  row:''
})
//通过  《请求》
const Pass = (index,row) => {
  DetailsDialog.value=true
  DetailsDat.index=index
  DetailsDat.row=row
}
const checkFiles=()=>{
  load.value.submitUpload()
  const indexs=(pages.value-1)*PagesColumn.value+DetailsDat.index
  tableData.splice(indexs,1)
  Data.splice(DetailsDat.index,1)
  console.log(load.value.getfile())
  DetailsDialog.value=false
  RequsetClosing(DetailsDat.row.apply_no)
}
//结案请求
const RequsetClosing=(apply_nos)=>{
  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)',
  })
  let fromdata=new FormData()
  if(load.value.getfile()!=undefined){
    fromdata.append('file_name',load.value.getfile())
  }
  Axios({
    url:'IncentiveManage/Closing',
    method:'post',
    params:{
      apply_no:apply_nos
    },
    headers:Headers,
    data:fromdata
  }).then(
    res=>{
      loading.close()
      const data=res.data
      ElMessage({
        type: 'success',
        message: '結案成功',
      })
    }
  ).catch(
    err=>{
      loading.close()
      console.log(err)
    }
  )
}

//批量结案 《请求》
const AllPass=()=>{
  ElMessageBox.confirm('確認結案嗎？','提示',{
    confirmButtonText: '確認',
    cancelButtonText: '取消',
    type: 'warning',
    draggable: true,
  }).then(()=>{
    let applys=[]
    if(ChangesData.length===0){
      ElMessage({
        type: 'info',
        message: '請選擇數據',
      })
      return
    }
    for(let i=0;i<ChangesData.length;i++){
      const index=(pages.value-1)*PagesColumn.value+tableData.map(item=>item.apply_no).indexOf(ChangesData[i].apply_no)
      tableData.splice(index,1)
      const Dataindex=Data.map(item=>item.apply_no).indexOf(ChangesData[i].apply_no)
      Data.splice(Dataindex,1)
      applys.push(ChangesData[i].apply_no)
    }
    RequestManyClosing(applys)
  }).catch(()=>{
    ElMessage({
      type: 'info',
      message: '結案取消',
    })
  })
}
//批量结案请求
const RequestManyClosing=(applys)=>{
  Axios({
    url:'IncentiveManage/ManyClosing',
    method:'post',
    params:{
      apply_nos:JSON.stringify(applys)
    }
  }).then(
    res=>{
      const data=res.data
      console.log(data)
      ElMessage({
        type: 'success',
        message: '結案成功',
      })
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}


//下载参考文件
const DownLoads=(url)=>{
  const filename=url.split("/")
  DownLoad(url,filename[filename.length-1])
}
// #endregion

// #region 导出奖惩单据
const ExportDcoument=()=>{
  if(Data.length==0){
    return
  }
  Axios({
    url:'IncentiveManage/ExportIncentive',
    method:'post',
    params:{
      apply_no: JSON.stringify(Data.map(obj=>obj.apply_no)),
      emp_no:JSON.stringify(Data.map(obj=>obj.emp_no))
    }
  }).then(
    res=>{
      const data=res.data.Data
      let datas=[[]]
      for(let i=0;i<Data.length;i++){
        const cdt=Data[i]
        datas[i]=[i+1,cdt.emp_no,cdt.name,cdt.f_departname
        ,cdt.f_grand,cdt.infactory,cdt.jc_dj,cdt.jc_type,cdt.remark,cdt.absenteeismdate
        ,data.SinerOver,data.CloseDate,cdt.status,cdt.signer,cdt.agent
        ,cdt.healthy,cdt.healthy==='Y'?data.Attendance:'',data.AwaitWork] 
      }
      IncentiveExcel(datas,'獎懲單據')
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

// #region 导出旷工单
const ExportAbsenteeism=()=>{
  if(Data.length==0){
    return
  }
  for(let i=0;i<Data.length;i++){
    if(Data[i]['jc_dj']!='曠工開除'){
      ElMessageBox.alert('有選中員工不為曠工開除！','提示',{
        confirmButtonText: '確認',
        type: 'warning',
        draggable: true,
      })
      return
    }
  }
  Axios({
    url:'IncentiveManage/AbsenteeismDcoument',
    method:'post',
    params:{
      apply_nos: JSON.stringify(ChangesData.map(obj=>obj.emp_no))
    }
  }).then(
    res=>{
      const data=res.data.Data
      let dats=[[]]
      for(let i=0;i<Data.length;i++){
          //法人名稱,入職日期,事業處
          dats[i]=[(i+1),Data[i]['emp_no'],Data[i]['name']
            ,data[i]['f_artificial'],data[i]['f_infactorydate']
            ,data[i]['f_subbu'],Data[i]['f_grand'],Data[i]['jc_type']
            ,Data[i]['absenteeismdate']]
      }
      AbsenteeismExcle(dats)
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
  
}
// #endregion



// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
// #endregion


// #region 动态显示表单字体颜色
const setCellColor=({ row, column, rowIndex, columnIndex })=>{
  let rowBackground = {color:'red'};
  if(columnIndex==6){
    return rowBackground;
  }
  if(columnIndex==5&&row.healthy=='Y'){
    return rowBackground;
  }
}
// #endregion
</script>

<style scoped>

.disbolk {
  background-color: gray;
  border: gray;
  /*禁用按钮*/
  pointer-events: none;
}

.demo-table-expand{
  margin-top:20px;
}

td div{
  text-align:left;
  margin-left:20px;
}
.el-form-item{
  width:100%;
}
/*按钮样式 */
#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}
</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}
</style>