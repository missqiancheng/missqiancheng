
<template>
  <h2 class="table-title">獎懲簽核</h2>
  
  <!--头部查询框-->
  <div id="btn">
    <el-button id="seletbtn" @click="AllPass()" type="primary">批量通過</el-button>
  </div>

  <!--表单-->
  <el-table :data="Data" id="big-width" @selection-change="changeColumn"
            @row-click="ShowHistory" >
    <el-table-column type="selection" width="55" prop="changes" :selectable="MoreSelect" fixed/>
    <el-table-column label="序號" type="index" width="80" fixed />
    <el-table-column label="工號" prop="EMP_NO" width="100" fixed />
    <el-table-column label="姓名" prop="NAME" width="120" fixed />
    <el-table-column label="獎懲等級" prop="JC_DJ" width="100" />
    <el-table-column label="年資" prop="INFACTORY" width="100" />
    <el-table-column label="資位" prop="F_GRAND" width="120" />
    <el-table-column label="部門名稱" prop="F_DEPARTNAME" width="220" />   
    <el-table-column label="提報人" prop="TBR" width="120" />
    <el-table-column label="提報日期" prop="EDITTIME" width="120" />
    <el-table-column label="簽核狀態" prop="STATUS" width="120" />
    <el-table-column label="操作" fixed="right" width="140">
      <template #default="scope">
        <el-button size="small" type="primary">詳情</el-button>
        <el-button size="small" type="primary" 
                   @click.stop="Prints(scope.$index, scope.row)">打印</el-button>
      </template>
    </el-table-column>
  </el-table>
  
  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>

  <!--通过对话框-->
  <el-dialog v-model="outerVisible" title="提示" width="30%" :close-icon="CloseBold" draggable> 
    <template #default>
      <el-form :model="formData" :rules="PassRules" ref="Passform">
        <el-form-item label="是否修改獎懲等級：">
          <el-switch v-model="formData.Incentive" />
        </el-form-item>
        <el-form-item label="獎懲等級：" prop="jc_dj" v-if="formData.Incentive">
          <el-select v-model="formData.jc_dj" placeholder="請選擇">
            <el-option v-for="item in formData.jc_dj_item" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item label="簽核意見：" prop="Reson" v-if="formData.Incentive">
          <el-input v-model="formData.Reson" type="textarea" />
        </el-form-item>
        <el-form-item label="簽核意見：" v-if="!formData.Incentive">
          <el-input v-model="formData.Reson" type="textarea" />
        </el-form-item>
      </el-form>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="outerVisible=false">取消</el-button>
        <el-button type="primary" @click="PassSubmit()">通過</el-button>
      </div>
    </template>
  </el-dialog>

  <!--驳回对话框-->
  <el-dialog v-model="OverRuleVisible" title="提示" width="30%" :close-icon="CloseBold" draggable> 
    <template #default>
      <el-form :model="OverRuleFormData" :rules="OverRules" ref="OverRuleForm">
        <el-form-item label="簽核意見：" prop="Reson">
          <el-input v-model="OverRuleFormData.Reson" type="textarea" />
        </el-form-item>
      </el-form>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="OverRuleVisible=false">取消</el-button>
        <el-button type="primary" @click="OverRuleSubmit()">駁回</el-button>
      </div>
    </template>
  </el-dialog>
 
  <!--驳回状态通过对话框-->
  <el-dialog v-model="OverOffVisible" title="提示" width="30%" :close-icon="CloseBold" draggable> 
    <template #default>
      <el-form :model="OverRejectFormData" :rules="OverRules" ref="RejectRuleForm">
        <el-form-item label="簽核意見：" prop="Reson">
          <el-input v-model="OverRejectFormData.Reson" type="textarea" />
        </el-form-item>
      </el-form>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="OverOffVisible=false">取消</el-button>
        <el-button type="primary" @click="RejectOff()">通过</el-button>
      </div>
    </template>
  </el-dialog>

  <!--驳回状态驳回对话框-->
  <el-dialog v-model="OverRejectVisible" title="提示" width="30%" :close-icon="CloseBold" draggable> 
    <template #default>
      <el-form :model="OverRejectFormData" :rules="OverRules" ref="RejectRuleForm">
        <el-form-item label="簽核意見：" prop="Reson">
          <el-input v-model="OverRejectFormData.Reson" type="textarea" />
        </el-form-item>
      </el-form>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="OverRejectVisible=false">取消</el-button>
        <el-button type="primary" @click="RejectReject()">駁回</el-button>
      </div>
    </template>
  </el-dialog>

  <!--奖惩记录详细信息-->
  <el-dialog v-model="Hoistory" title="獎懲單據明細" width="70%" :close-icon="CloseBold" 
            :destroy-on-close="true" style="background-color: #e8e4e4;">
    <template #default>
      <History ref="HistoryBox">
        <template v-slot:Pass>
          <el-button size="small" type="primary" v-if="DocumentStatus"
                     @click="ShowUpdate()">修改</el-button>
          <el-button size="small" type="primary" v-else
                     @click="Pass()">通過</el-button>
        </template>
        <template v-slot:Cancel>
          <el-button size="small" type="danger"  v-if="DocumentStatus"
                     @click="ConfirmReject()">確認駁回</el-button>
          <el-button size="small" type="danger"  v-else
                     @click="OverRule()">駁回</el-button>
        </template>
      </History>
    </template>
  </el-dialog>
  
  <!--修改奖惩单据信息-->
  <el-dialog v-model="UpdateDialog" title="修改獎懲單據" width="70%" :close-icon="CloseBold" style="background-color: #e8e4e4;">
    <template #default>
      <updatedoucment ref="UpdateBox"></updatedoucment>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button size="small" type="primary"
                   @click="UpdateSubmit()">提交</el-button>
        <el-button size="small" type="danger" 
                   @click="UpdateDialog=false">取消</el-button>
      </div>
    </template>
  </el-dialog>
  
  <template>
    <Incentive ref="Incentivesf"></Incentive>
  </template>
  
  
</template>

<script setup>
import { ref,reactive,nextTick } from 'vue'
import { ElMessage,ElMessageBox,ElLoading } from 'element-plus'
import { Loading, Orange, Search, CloseBold } from '@element-plus/icons-vue'
import UpLoad from '/src/pages/UpLoad.vue'
import Incentive from '/src/components/IncentiveManage/PrintIncentive.vue'
import { Axios,DownLoad } from '/src/Axios'
import History from '/src/pages/Histroy.vue'
import updatedoucment from '/src/components/IncentiveManage/UpdateDocument.vue'


// #region 固定数据
//通过提示框
const outerVisible=ref(false)
//驳回提示框
const OverRuleVisible=ref(false)
//驳回状态通过框
const OverOffVisible=ref(false)
//驳回状态驳回框
const OverRejectVisible=ref(false)

//通过表单
const Passform=ref()
//驳回表单
const OverRuleForm=ref()
//驳回状态表单
const RejectRuleForm=ref()

//通过表单数据
const formData=reactive({
  //是否修改奖惩等级
  Incentive:false,
  //签核意见
  Reson:'',
  jc_dj:'',
  jc_dj_item:[],
  apply_no:'',
  index:'',
  status:''
})
//驳回表单数据
const OverRuleFormData=reactive({
  apply_no:'',
  Reson:'',
  index:'',
})
//驳回状态表单
const OverRejectFormData=reactive({
  apply_no:'',
  Reson:'',
  index:'',
})

//通过表单check
const PassRules=reactive({
  jc_dj:[{
    required: true, message: '請選擇獎懲等級', trigger: 'change'
  }],
  Reson:[{
    required: true, message: '簽核意見不能為空', trigger: 'blur'
  }],
})
//驳回表单check
const OverRules=reactive({
  Reson:[{
    required: true, message: '簽核意見不能為空', trigger: 'blur'
  }],
})


//选中的表格数据
let ChangesData=[]
//获取选中数据
const changeColumn=(value)=>{
  ChangesData=value
}
//全部数据 《请求》
const tableData = reactive([])

//禁止不能多选数据
const MoreSelect=(row,index)=>{
  if(row.STATUS=='待簽核'&&row.F_CHANGETYPE=='否'){
    return true
  }else{
    return false
  }
}
// #endregion


// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
// #endregion


// #region 请求
//获取待签核数据
const RequestSign=()=>{
  Axios({
    url:'IncentiveManage/GetAwaitSinger',
    method:'Post',
  }).then(
    res=>{
      const data=res.data
      const Tables=data.Data
      tableData.length=0
      for(let i=0;i<Tables.length;i++){
        tableData[i]=Tables[i]
        tableData[i].LodeBool=false
      }
      DataCount.value=tableData.length
      Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequestSign()

//弹窗数据
const DialogData=reactive({
  apply_no:'',
  jc_dj:'',
  status:'',
  index:'',
  empno:'',
  time_year:''
})


// #region 通过
//通过 
const Pass = () => {
  if(DialogData.status=="駁回"){
    OverRejectFormData.apply_no=DialogData.apply_no
    OverRejectFormData.index=DialogData.index
    OverOffVisible.value=true
  }else{
    const djlist=['大過二次','大過一次','開除','小過一次','警告一次','警告二次']
    const djlists=['嘉獎一次','小功一次','大功一次']
    if(djlist.includes(DialogData.jc_dj)){
      djlist.splice(djlist.indexOf(DialogData.jc_dj),1)
      formData.jc_dj_item=djlist
    }else{
      djlists.splice(djlists.indexOf(DialogData.jc_dj),1)
      formData.jc_dj_item=djlists
    }
    formData.index=DialogData.index
    formData.apply_no=DialogData.apply_no
    outerVisible.value=true
  }
}
//提交通过签核 《请求》
const PassSubmit=()=>{
  Passform.value.validate((valid) => {
    if(valid){
      const index=(pages.value-1)*PagesColumn.value+formData.index
      tableData.splice(index,1)
      Data.splice(formData.index,1)
      outerVisible.value=false
      Hoistory.value=false
      RequsetPass()
    }else{
      
    }
  })
}
//通过请求
const RequsetPass=()=>{
  Axios({
    url:'IncentiveManage/Signer',
    method:'post',
    params:{
      apply_no:formData.apply_no,
      MEMO:formData.Reson,
      jc_dj:formData.jc_dj
    }
  }).then(
    res=>{
      const data=res.data
      ElMessage({
        type: 'success',
        message: '已通過',
      })
    }
  ).catch(
    err=>{
      console.log(err)
    } 
  )
}
//驳回状态通过请求
const RejectOff=()=>{
  RejectRuleForm.value.validate((valid) => {
    if(valid){
      const index=(pages.value-1)*PagesColumn.value+formData.index
      tableData.splice(index,1)
      Data.splice(formData.index,1)
      OverOffVisible.value=false
      Hoistory.value=false
      RejectReqeust()
    }else{
      
    }
  })
}
//驳回状态通过《请求》
const RejectReqeust=()=>{
  Axios({
    url:'IncentiveManage/Reject',
    method:"post",
    params:{
      apply_no:OverRejectFormData.apply_no,
      MEMO:OverRejectFormData.Reson
    }
  }).then(
    res=>{
      const data=res.data
      ElMessage({
        type: 'success',
        message: '已通过',
      })
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//批量通过 《请求》
const AllPass=()=>{
  ElMessageBox.confirm('確認全部通過嗎？','提示',{
    confirmButtonText: '確認',
    cancelButtonText: '取消',
    type: 'warning',
    draggable: true,
  }).then(()=>{
    let applys=[]
    for(let i=0;i<ChangesData.length;i++){
      const index=tableData.map(item=>item.APPLY_NO).indexOf(ChangesData[i].APPLY_NO)
      const Dataindex=Data.map(item=>item.APPLY_NO).indexOf(ChangesData[i].APPLY_NO)
      tableData.splice(index,1)
      Data.splice(Dataindex,1)
      applys.push(ChangesData[i].APPLY_NO)
    }
    RequestManyPass(applys)
  }).catch(()=>{
    ElMessage({
      type: 'info',
      message: '取消',
    })
  })
}
const RequestManyPass=(applys)=>{
  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)',
  })
  Axios({
    url:'IncentiveManage/ManySigner',
    method:'post',
    params:{
      apply_nos:JSON.stringify(applys)
    }
  }).then(
    res=>{
      const data=res.data
      ElMessageBox.alert('簽核完畢！','提示',{
        type: 'success',
        draggable: true,
      })
      loading.close()
    }
  ).catch(
    err=>{
      console.log(err)
      loading.close()
    }
  )
}
// #endregion


// #region 驳回
//驳回
const OverRule=()=>{
  if(DialogData.status=="駁回"){
    OverRejectFormData.apply_no=DialogData.apply_no
    OverRejectFormData.index=DialogData.index
    OverRejectVisible.value=true
  }else{
    OverRuleFormData.apply_no=DialogData.apply_no
    OverRuleFormData.index=DialogData.index
    OverRuleVisible.value=true
  }
}
//驳回  《请求》
const OverRuleSubmit=()=>{
  OverRuleForm.value.validate((valid) => {
    if(valid){
      const index=(pages.value-1)*PagesColumn.value+OverRuleFormData.index
      tableData.splice(index,1)
      Data.splice(OverRuleFormData.index,1)
      RequestReject()
      OverRuleVisible.value=false
      //更新表单
      Hoistory.value=false
    }else{}
  })
}
//驳回请求
const RequestReject=()=>{
  Axios({
    url:'IncentiveManage/Reject',
    method:"post",
    params:{
      apply_no:OverRuleFormData.apply_no,
      MEMO:OverRuleFormData.Reson
    }
  }).then(
    res=>{
      const data=res.data
      ElMessage({
        type: 'success',
        message: '已駁回',
      })

    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
//驳回状态驳回
const RejectReject=()=>{
  RejectRuleForm.value.validate((valid) => {
    if(valid){
      const index=(pages.value-1)*PagesColumn.value+formData.index
      tableData.splice(index,1)
      Data.splice(formData.index,1)
      OverRejectVisible.value=false
      Hoistory.value=false
      RejectOffRject()
    }else{
      
    }
  })
}
//驳回状态驳回 《请求》
const RejectOffRject=()=>{
  Axios({
    url:'IncentiveManage/Signer',
    method:"post",
    params:{
      apply_no:OverRejectFormData.apply_no,
      MEMO:OverRejectFormData.Reson
    }
  }).then(
    res=>{
      const data=res.data
      ElMessage({
        type: 'success',
        message: '已駁回',
      })
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion


// #region 修改
//确认驳回单据
const ConfirmReject=()=>{
  ElMessageBox.confirm('確認取消申請單嗎？','提示',{
    confirmButtonText: '確認',
    cancelButtonText: '取消',
    type: 'warning',
    draggable: true,
  }).then(()=>{
    const index=(pages.value-1)*PagesColumn.value+DialogData.index
    tableData.splice(index,1)
    Data.splice(DialogData.index,1)
    OverOffVisible.value=false
    Hoistory.value=false
    ReuqestCancel()
  }).catch(()=>{
    // ElMessage({
    //   type:'success',
    //   message: '已駁回',
    // })
  })
}
//确认驳回请求
const ReuqestCancel=()=>{
  Axios({
    url:'IncentiveManage/CancelIcnetive',
    method:'post',
    params:{
      apply_no:DialogData.apply_no,
      MEMO:''
    }
  }).then(
    res=>{
      ElMessage({
        type: 'success',
        message: '已駁回',
      })
      console.log(res)
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
//修改弹窗
const UpdateDialog=ref(false)
//修改表单
const UpdateBox=ref()
//修改弹窗
const ShowUpdate=()=>{
  UpdateDialog.value=true
  nextTick(()=>{
    UpdateBox.value.RequestHostory(DialogData.apply_no,DialogData.empno,DialogData.time_year)
  })
}
const UpdateSubmit=()=>{
  UpdateBox.value.CheckSubmit(Callback)
}
//请求成功执行回调
const Callback=()=>{
  const index=(pages.value-1)*PagesColumn.value+formData.index
  tableData.splice(index,1)
  Data.splice(formData.index,1)
  UpdateDialog.value=false
  Hoistory.value=false
}
// #endregion

//
// #region 单据明细信息
//单据详细信息
const Hoistory=ref(false)
//明细组件
const HistoryBox=ref()
//单据状态
const DocumentStatus=ref()
//显示dialog
const ShowHistory=(rows)=>{
  DocumentStatus.value=(rows.STATUS=='待確認')
  DialogData.apply_no=rows.APPLY_NO
  DialogData.jc_dj=rows.JC_DJ
  DialogData.status=rows.STATUS
  DialogData.empno=rows.EMP_NO
  DialogData.time_year=rows.TIME_YEAR
  DialogData.index=Data.indexOf(rows)
  rows.LodeBool=true
  Hoistory.value=true
  nextTick(()=>{
    HistoryBox.value.RequestHostory(rows.APPLY_NO,rows.EMP_NO,rows.TIME_YEAR)
  })
}
// #endregion 

// #endregion


// #region 打印奖惩单据
//打印弹窗
const PrintDialog=ref(false)
//奖惩单模板
const Incentivesf=ref()
//打印单据数据
const Incentivedata={
  name:'1',
  departname:'2',
  empno:'3',
  Reson:'4',
  jc_yj:'5',
  jc_type:'6',
  jc_content:'7',
  jc_dj:'',
  f_changetype:'',
  sign:{
    signName0:'',
    signDate0:'',
    signName1:'',
    signDate1:'',
    signName2:'',
    signDate2:'',
    signName3:'',
    signDate3:'',
    signName4:'',
    signDate4:'',
    signName5:'',
    signDate5:'',
    signName6:'',
    signDate6:'',
  },

  //岗位
  posts:'',
  //在职时间
  StartTime:'',
  EndTime:'',
  //身份证号
  idNumber:''
}
//显示打印奖惩单据
const Prints=async(index,row)=>{
  PrintDialog.value=true
  Incentivedata.name=row.NAME
  Incentivedata.departname=row.F_DEPARTNAME
  Incentivedata.empno=row.EMP_NO
  Incentivedata.Reson=row.REMARK
  Incentivedata.jc_yj=row.JC_YJ+row.JC_TL
  Incentivedata.jc_type=row.JC_TYPE
  Incentivedata.jc_content=row.F_JCITEMCONTENT
  Incentivedata.f_changetype=row.F_CHANGETYPE
  if(Incentivedata.f_changetype==='否'){
    Incentivedata.jc_dj=row.JC_DJ
  }else{
    Incentivedata.jc_dj=row.F_JCDJ_NEW
  }
  await new Promise((resolve,reject)=>{
    return RequestSigner(row,resolve)
  })
  //给Singers赋值
  if(row.Signers!=undefined){
    for(let i=0;i<row.Signers.length;i++){
      switch(row.Signers[i].SIGNTYPE){
        case "課級主管初審":
          Incentivedata.sign.signName0=row.Signers[i].F_NAME
          Incentivedata.sign.signDate0=row.Signers[i].SIGNTIME
        break;
        case "部級主管審核":
          Incentivedata.sign.signName1=row.Signers[i].F_NAME
          Incentivedata.sign.signDate1=row.Signers[i].SIGNTIME
        break;
        case "處級主管複審":
          Incentivedata.sign.signName2=row.Signers[i].F_NAME
          Incentivedata.sign.signDate2=row.Signers[i].SIGNTIME
        break;
        case "最高主管核准":
          Incentivedata.sign.signName3=row.Signers[i].F_NAME
          Incentivedata.sign.signDate3=row.Signers[i].SIGNTIME
        break;
        case "人資主管審核":
          Incentivedata.sign.signName4=row.Signers[i].F_NAME
          Incentivedata.sign.signDate4=row.Signers[i].SIGNTIME
        break;
        case "工會簽核":
          Incentivedata.sign.signName5=row.Signers[i].F_NAME
          Incentivedata.sign.signDate5=row.Signers[i].SIGNTIME
        break;
      }
  }
  //为開除打印开除通知 《请求》
  if(Incentivedata.jc_dj==='開除'){
    //赋值
    Incentivedata.idNumber=true
  }
  }
  Incentivesf.value.PrintsDocument(Incentivedata)
}

//获取签核记录
const RequestSigner=(row,resolve)=>{
  Axios({
    url:'IncentiveManage/GetHistory',
    method:'post',
    params:{
      applyno:row.APPLY_NO
    }
  }).then(
    res=>{
      const data=res.data.Data
      row.Signers=data
      resolve()
    }
  ).catch(
    err=>{
      resolve()
      console.log(err)
    }
  )
}
// #endregion


</script>

<style scoped>

.disbolk {
  background-color: gray;
  border: gray;
  /*禁用按钮*/
  pointer-events: none;
}

.demo-table-expand{
  margin-top:20px;
}

td div{
  text-align:left;
  margin-left:20px;
}
/*按钮样式 */
#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}
</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}

.historys .el-form-item__label{
  background:#fafafa;
  border:1px solid #eee;
  /* width: 30px; */
  padding-left:20px;
}
.historysOrange .el-form-item__content{
  background:#fdf6ec;
  /* border:1px solid black; */
  /* #f0f9eb */
}
.historysGrenn .el-form-item__content{
  background:#f0f9eb;
  /* border:1px solid black; */
}
</style>