<template>

    <!--头部查询框-->
    <div id="btn">
      <el-button id="seletbtn" @click="SubmitExcel()" type="primary">全部上傳</el-button>
      <el-button id="seletbtn" @click="ChangeSubmit()" type="primary">批量上傳</el-button>
    </div>

    <!--表单-->
    <el-table :data="props.TableData" id="big-width" @selection-change="changeColumn">
      <el-table-column type="selection" width="55" prop="changes" fixed  />
      <el-table-column label="序號" type="index" width="80" fixed/>
      <el-table-column label="員工工號" prop="emp_no" width="100" fixed/>
      <el-table-column label="員工姓名" prop="name" width="100" fixed/>
      <el-table-column label="工作擔當" prop="duty" width="120" />
      <el-table-column label="獎懲發生日期" prop="f_occurdate" width="120" />
      <el-table-column label="獎懲原由" prop="remark" width="280" />
      <el-table-column label="獎懲依據" prop="jc_yj" width="200" />
      <el-table-column label="獎懲條例" prop="jc_tl" width="150" />
      <el-table-column label="獎懲等級" prop="jc_dj" width="140" />
      <el-table-column label="獎懲類別" prop="jc_type" width="140" />
      <el-table-column label="提報人聯繫方式" prop="tbr_tel" width="140" />
      <el-table-column label="是否變更獎懲等級" prop="f_changetype" width="140" />
      <el-table-column label="變更后獎懲等級" prop="f_jcdj_new" width="140" />
      <el-table-column label="變更獎懲原由" prop="f_changereason" width="120" />
      <el-table-column label="類型(人資專屬)" prop="ApplicationType" width="120" />
      <el-table-column label="操作" fixed="right" width="160">
        <template #default="scope">
          <el-icon class="iconMidde" :size="IconSize" :color="IconColor"
                   @click="ShowDetails(scope.$index,scope.row)"><View /></el-icon>
          <el-icon class="iconMidde" :size="IconSize" :color="IconColor" 
                   @click="dialogShow(scope.$index,scope.row)"><Upload /></el-icon>
          <el-icon class="iconMidde" :size="IconSize" color="rgb(255, 83, 97)" 
                   @click="DeleteRows(scope.$index,scope.row)"><Delete /></el-icon>
        </template>
      </el-table-column>
    </el-table>
    
    <!--补全对话框-->
    <el-dialog v-model="OverRuleVisible" title="綁定獎懲檔" width="30%" draggable> 
      <template #default>
        <el-form>
          <el-form-item label="獎懲自述材料：" v-if="FilesShow">
            <UpLoad ref="files"></UpLoad>
          </el-form-item>
          <el-form-item label="變更證明材料：" v-if="UpLoadShow">
            <UpLoad ref="updatefiles"></UpLoad>
          </el-form-item>
        </el-form>
      </template>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="checkFiles()">綁定</el-button>
        </div>
      </template>
    </el-dialog>

    <!--详情-->
    <el-dialog v-model="DetailsDialog" style="background-color: #e8e4e4;"
               title="綁定獎懲檔" width="90%" :destroy-on-close="true"> 
      <template #default>
        <History ref="history"></History>
      </template>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="OneSubmit()">提交</el-button>
          <el-button @click="DetailsDialog=false">取消</el-button>
        </div>
      </template>
    </el-dialog>

</template>

<script setup>
import { reactive,ref,nextTick } from 'vue'
import UpLoad from '/src/pages/UpLoad.vue'
import { ElMessageBox, overlayEmits,ElLoading,ElMessage } from 'element-plus'
import { Axios,Headers } from '../../Axios';
import { View,Delete,Upload } from '@element-plus/icons-vue';
import History from '/src/pages/Histroy.vue'


// #region 表单基本数据
//父组件数据
const props=defineProps({
  TableData:Array//execl数据
})

//iconSize
const IconSize=ref(25)
const IconColor=ref('#409EFC')

//选中数据
let ChangesData=[]
//触发选中
const changeColumn=(value)=>{
  ChangesData=value
}
// #endregion

//
// #region 补充文件
//弹出框
const OverRuleVisible=ref(false)
//是否显示变更上传文件
const UpLoadShow=ref(false)
//上传文件
const FilesShow=ref(false)
//文件控件
const files=ref()
const updatefiles=ref()
//行下标
let indexs;
//显示dialog
const dialogShow=async(index,data)=>{
  if(data.f_changetype==='是'){
    await new Promise((resolve,reject)=>{
      FilesShow.value=false
      UpLoadShow.value=false
      return resolve()
    })
    await new Promise((resolve,reject)=>{
      FilesShow.value=true
      UpLoadShow.value=true
      return resolve()
    })
  }else{
    await new Promise((resolve,reject)=>{
      FilesShow.value=false
      UpLoadShow.value=false
      return resolve()
    })
    await new Promise((resolve,reject)=>{
      FilesShow.value=true
      return resolve()
    })
  }
  indexs=index
  OverRuleVisible.value=true
}
//dialog提交验证
const checkFiles=()=>{
  if(files.value.FileLength()<1){
    ElMessageBox.alert('請上傳檔！','提示',
    {confirmButtonText: '確認',type: 'warning',draggable: true})
  }else if(UpLoadShow.value){
    if(updatefiles.value.FileLength()<1){
      ElMessageBox.alert('請上傳檔！','提示',
      {confirmButtonText: '確認',type: 'warning',draggable: true})
    }else{
      files.value.submitUpload()
      //文件名
      props.TableData[indexs].file_names=files.value.getfile()
      props.TableData[indexs].file_name=files.value.getfile().name
      updatefiles.value.submitUpload()
      //文件名
      props.TableData[indexs].hr_file_names=updatefiles.value.getfile()
      props.TableData[indexs].hr_file_name=updatefiles.value.getfile().name
      OverRuleVisible.value=false
    }
  }else{
    files.value.submitUpload()
    props.TableData[indexs].file_names=files.value.getfile()
    props.TableData[indexs].file_name=files.value.getfile().name
    OverRuleVisible.value=false
  }
}
//
// #endregion


// #region 显示奖惩单明细
const DetailsDialog=ref(false)
const history=ref()
const ShowDetails=(index,row)=>{
  DetailsDialog.value=true
  nextTick(()=>{
    history.value.GiveDetails(row.emp_no,row.name,row.duty,localStorage.getItem('empno')
    ,row.tbr_tel,row.f_occurdate,row.jc_yj,row.jc_tl,row.jc_dj,row.jc_type,row.remark
    ,row.file_names,row.f_changetype,row.f_changereason,row.f_jcdj_new,row.hr_file_names)
  })
  RowsIndex=index
}
// #endregion


// #region 删除行
const DeleteRows=(index,row)=>{
  ElMessageBox.confirm('是否確認刪除?','提示',{
    confirmButtonText: '確認',
    cancelButtonText: '取消',
    type: 'warning',
  }).then(() => {
    props.TableData.splice(index,1)
    ElMessage({
      type: 'success',
      message: '刪除成功',
    })
  }).catch(() => {})
}
// #endregion


// #region 批量提交
const ChangeSubmit=()=>{
  if(ChangesData.length==0){
    ElMessageBox.alert('沒有選取檔案！','提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
  }
  for(let i=0;i<ChangesData.length;i++){
    if(ChangesData[i].f_changetype==='是'){
      if(ChangesData[i].file_name===undefined||ChangesData[i].hr_file_name===undefined){
        ElMessageBox.alert(`請為第${i+1}行綁定文件`,'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
      }
    }else{
      if(ChangesData[i].file_name===undefined&&!CheckDJ.includes(ChangesData[i].jc_dj)){
        ElMessageBox.alert(`請為第${i+1}行綁定文件`,'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
      }
    }
  }
  requsetsumit(ChangesData)
}
// #endregion

// #region 全部提交 
//验证是否要提交文件的奖惩的等级
const CheckDJ=['嘉獎一次','警告一次','警告二次']
//提交数据  《请求》
const SubmitExcel=()=>{
  for(let i=0;i<props.TableData.length;i++){
    if(props.TableData[i].f_changetype==='是'){
      if(props.TableData[i].file_name===undefined||props.TableData[i].hr_file_name===undefined){
        ElMessageBox.alert(`請為第${i+1}行綁定文件`,'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
      }
    }else{
      if(props.TableData[i].file_name===undefined&&
         !CheckDJ.includes(props.TableData[i].jc_dj)){
        ElMessageBox.alert(`請為第${i+1}行綁定文件`,'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return 
      }
    }
  }
  requsetsumit(props.TableData)
}
//提交数据
const requsetsumit=(ImportData)=>{
  //上传锁屏
  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)',
  })

  let formdata=new FormData()
  for(let i=0;i<ImportData.length;i++){
    if(ImportData[i].f_changetype==='是'){
      formdata.append('file_name'+i,ImportData[i].file_names)
      formdata.append('hr_file_name'+i,ImportData[i].hr_file_names)
      ImportData[i].file_names=""
      ImportData[i].hr_file_names=""
    }else{
      formdata.append('file_name'+i,ImportData[i].file_names)
      ImportData[i].file_names=""
    }
  }
  
  Axios({
    url:'IncentiveManage/ImportIncentive',
    method:'post',
    params:{
      JsonData:JSON.stringify(ImportData)
    },
    headers:Headers,
    data:formdata
  }).then(
    res=>{
      //关闭锁屏
      loading.close()
      const data=res.data
      if(data.Message!==""){
        ElMessageBox.alert(data.Message+",请重新申请!",'提示',
          {confirmButtonText: '確認',type: 'warning',draggable: true})
      }else{
        ElMessageBox.alert("提交成功！",'提示',
          {confirmButtonText: '確認',type: 'warning',draggable: true})
      }
    }
  ).catch(
    err=>{
      //关闭锁屏
      loading.close()
      console.log(err)
    }
  )
}
// #endregion

// #region 单条提交
let RowsIndex;
const OneSubmit=()=>{
  if(props.TableData[RowsIndex].f_changetype==='是'){
    if(props.TableData[RowsIndex].file_name===undefined||
       props.TableData[RowsIndex].hr_file_name===undefined){
      ElMessageBox.alert(`請為單據綁定文件`,'提示',
      {confirmButtonText: '確認',type: 'warning',draggable: true})
      return
    }
  }else{
    if(props.TableData[RowsIndex].file_name===undefined&&
       !CheckDJ.includes(props.TableData[RowsIndex].jc_dj)){
      ElMessageBox.alert(`請為單據綁定文件`,'提示',
      {confirmButtonText: '確認',type: 'warning',draggable: true})
      return
    }
  }
  const TableData=[props.TableData[RowsIndex]]
  requsetsumit(TableData)
  DetailsDialog.value=false
}
// #endregion



</script>

<style scoped>
h2{
    font-size:35px;
    text-align: center;
    line-height:80px;
}

.disbolk {
  background-color: gray;
  border: gray;
  /*禁用按钮*/
  pointer-events: none;
}

.demo-table-expand{
  margin-top:20px;
}

td div{
  text-align:left;
  margin-left:20px;
}
/*按钮样式 */
#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}

/*图标居中*/
.iconMidde{
  vertical-align: middle;
  margin-right: 10px;
  margin-left: 10px;
}
.iconMidde:hover{
  color: orange;
  
}
</style>