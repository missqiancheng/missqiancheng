<template>
  <div class="impBox" v-if="TableShow">
    <imports ref="imports" :LoadPath="LoadPath" :Methods="Mthos"
             :download="download" @OnSuccess="OnSuccess()"></imports>
  </div>
  <div v-else>
    <Table :TableData="tableData"></Table>
  </div>
</template>

<script setup>
import Imports from '/src/pages/Import.vue'
import {ref,reactive} from 'vue'
import Table from '/src/components/IncentiveManage/ImportTable.vue'
import XLSX from 'xlsx'
import { ElMessageBox } from 'element-plus'
import { ServerPath } from '/src/Axios'


//import控件
const imports=ref()

//补充文件筐
const TableShow=ref(true)
//提交方式
const Mthos=ref('GET')
//提交路径
const LoadPath=ref(ServerPath+'IncentiveManage/FileTerminal')
//模板文件路径
const download=ref("/Incentive/奖惩单申请导入模板.xlsx")
//提交成功方法
const OnSuccess=async(res)=>{
  //获取文件，转换为ArraryBuffer类型
  const arrayBuffer=await imports.value.getfile().arrayBuffer()
  const JsonData=importExcelFromBuffer(arrayBuffer)
  for(let i=0;i<JsonData.length;i++){
    //验证数据是否为空
    if(CheckExecl(JsonData[i])){
      ElMessageBox.alert(`第${i+1}行數據不完整，請補充完整。`,'提示',
      {confirmButtonText: '確認',type: 'warning',draggable: true})
      return
    }
    tableData[i]={
      emp_no:JsonData[i]["工號"],
      name:JsonData[i]["姓名"],
      duty:JsonData[i]["目前工作擔當"],
      f_occurdate:formatExcelDate(JsonData[i]["獎懲發生日期"]),
      remark:JsonData[i]["獎懲原由"],
      jc_yj:JsonData[i]["獎懲依據"],
      jc_tl:JsonData[i]["獎懲條例"],
      jc_dj:JsonData[i]["獎懲等級"],
      jc_type:JsonData[i]["獎懲類別"],
      tbr_tel:JsonData[i]["提報人聯繫方式"],
      f_changetype:JsonData[i]["是否變更獎懲等級"],
      f_jcdj_new:JsonData[i]["變更后獎懲等級"],
      f_changereason:JsonData[i]["變更獎懲原由"],
      ApplicationType:JsonData[i]["類型(人資專屬)"]
    }
  }
  TableShow.value=!TableShow.value
}

//判断json数据是否合格
const CheckExecl=(JsonData)=>{
  if(JsonData["工號"]===undefined||JsonData["姓名"]===undefined||
     JsonData["目前工作擔當"]===undefined||JsonData["獎懲發生日期"]===undefined||
     JsonData["獎懲原由"]===undefined||JsonData["獎懲依據"]===undefined||
     JsonData["獎懲條例"]===undefined||JsonData["獎懲等級"]===undefined||
     JsonData["獎懲類別"]===undefined||JsonData["提報人聯繫方式"]===undefined||
     JsonData["是否變更獎懲等級"]===undefined)
  {
    return true
  }else if(JsonData["是否變更獎懲等級"]==="是"&&(JsonData["變更后獎懲等級"]===undefined||JsonData["變更獎懲原由"]===undefined)){
    return true
  }else{
    return false
  }
}


//读取execl文件为json数据
const importExcelFromBuffer=(excelRcFileBuffer)=>{
  // 读取表格对象
  const workbook = XLSX.read(excelRcFileBuffer, {type: 'buffer'});
  // 找到第一张表
  const sheetNames = workbook.SheetNames;
  const sheet1 = workbook.Sheets[sheetNames[0]];
  // 读取内容
  return XLSX.utils.sheet_to_json(sheet1);
}

//转换execl时间
const formatExcelDate=(numb, format = '/') =>{
  const time = new Date((numb - 25567) * 24 * 3600000 - 5 * 60 * 1000 - 43 * 1000 - 24 * 3600000 - 8 * 3600000)
  time.setYear(time.getFullYear())
  const year = time.getFullYear() + ''
  const month = time.getMonth() + 1 + ''
  const date = time.getDate() + ''
  if (format && format.length === 1) {
    return year + format + month + format + date
  }
  return year + (month < 10 ? '0' + month : month) + (date < 10 ? '0' + date : date)
}

//全部数据 《请求》
const tableData = reactive([{
  emp_no:''
}])

</script>

<style>
.impBox{
  height: 800px;
}
</style>