<template>
      <el-menu
        :default-active="DefaultChange"
        class="el-menu-vertical-demo"
        :collapse="ASideType"
      >
        <el-menu-item index="AccordingDocument" @click="AccordingDocument()">
          <el-icon><Document /></el-icon>
          <span>參考文件</span>
        </el-menu-item>
        <el-menu-item index="Application" @click="RPMApplication()" v-if="types!='0'">
          <el-icon><Collection /></el-icon>
          <span>獎懲申請</span>
        </el-menu-item>
        <el-menu-item index="IncentiveImport" @click="IncentiveImport()" v-if="types!='0'">
          <el-icon><MessageBox /></el-icon>
          <span>獎懲導入</span>
        </el-menu-item>
        <el-sub-menu index="5" v-if="types==='3'||types==='41'">
          <template #title>
            <el-icon><Edit /></el-icon>
            <span>人資簽核</span>
          </template>
            <el-menu-item index="IncentiveSign" @click="IncentiveSign()">
              <el-icon><EditPen /></el-icon>
              <span>獎懲簽核</span>
            </el-menu-item>
            <el-menu-item index="IncentiveClosing" @click="IncentiveClosing()">
              <el-icon><Crop /></el-icon>
              <span>獎懲結案</span>
            </el-menu-item>
            <el-menu-item index="CompulsionSign" @click="CompulsionSign()">
              <el-icon><Money /></el-icon>
              <span>強制簽核</span>
            </el-menu-item>
        </el-sub-menu>
        <el-menu-item index="IncentiveSign" @click="IncentiveSign()" v-else>
          <el-icon><EditPen /></el-icon>
          <span>獎懲簽核</span>
        </el-menu-item>
        <el-menu-item index="IncentiveProgress" @click="IncentiveProgress()">
          <el-icon><Search /></el-icon>
          <span>獎懲查詢</span>
        </el-menu-item>
        <el-menu-item index="PrintBulletin" @click="PrintBulletin()" v-if="types!='0'">
          <el-icon><Search /></el-icon>
          <span>公告列印</span>
        </el-menu-item>
        <el-sub-menu index="8" v-if="types==='3'||types==='41'">
          <template #title>
            <el-icon><SetUp /></el-icon>
            <span>系統管理</span>
          </template>
            <el-menu-item index="TipsSettings" @click="TipsSettings()">
              <el-icon><Message /></el-icon>
              <span>溫馨提示設定</span>
            </el-menu-item>
            <el-sub-menu index="8-2">
              <template #title>
                <el-icon><Coin /></el-icon>
                <span>獎懲依據設定</span>
              </template>
              <el-menu-item index="SetAccordingDocument" @click="SetAccordingDocument()">
                <el-icon><MessageBox /></el-icon>
                <span>參考文件設定</span>
              </el-menu-item>
              <el-sub-menu index="8-2-2">
                <template #title>
                  <el-icon><Coin /></el-icon>
                  <span>獎懲條例添加</span>
                </template>
                <el-menu-item index="OrdinanceInput" @click="OrdinanceInput()">
                  <el-icon><DocumentAdd /></el-icon>
                  <span>單條添加</span>
                </el-menu-item>
                <el-menu-item index="OrdinanceImport" @click="OrdinanceImport()">
                  <el-icon><MessageBox /></el-icon>
                  <span>批量導入</span>
                </el-menu-item>
              </el-sub-menu>
              <el-menu-item index="OrdinanceEnquiry" @click="OrdinanceEnquiry()">
                <el-icon><Search /></el-icon>
                <span>獎懲條例查詢</span>
              </el-menu-item>
            </el-sub-menu>
            <el-menu-item index="PaperSetting" @click="PaperSetting()">
              <el-icon><List /></el-icon>
              <span>紙檔簽核設定</span>
            </el-menu-item>
        </el-sub-menu> 
      </el-menu>
</template>
<script setup>
import { Document,Collection,Edit,MessageBox,SetUp,EditPen,Crop,Money,Message,Coin,Search,DocumentAdd,List
 } from '@element-plus/icons-vue';
import { ref,inject } from 'vue'
import route from '/src/router'

const emit=defineEmits(['addTabs'])

const ASideType=inject('ASideType')

const DefaultChange=inject('DefaultChange')


const types=localStorage.getItem('userType')

//参考文件
const AccordingDocument=()=>{
  const NavigationPath="AccordingDocument"
  emit("addTabs","獎懲參考文件",NavigationPath)
}

//奖惩申请
const RPMApplication=()=>{
  const NavigationPath="Application"
  emit("addTabs","獎懲申請",NavigationPath)
}

//奖惩导入
const IncentiveImport=()=>{
  const NavigationPath="IncentiveImport"
  emit("addTabs","獎懲導入",NavigationPath)
}

//奖惩签核
const IncentiveSign=()=>{
  const NavigationPath="IncentiveSign"
  emit("addTabs","獎懲簽核",NavigationPath)
}

//奖惩结案
const IncentiveClosing=()=>{
  const NavigationPath="IncentiveClosing"
  emit("addTabs","獎懲結案",NavigationPath)
}

//强制签核
const CompulsionSign=()=>{
  const NavigationPath="CompulsionSign"
  emit("addTabs","強制簽核",NavigationPath)
}

//奖惩进度查询
const IncentiveProgress=()=>{
  const NavigationPath="IncentiveProgress"
  emit("addTabs","獎懲查詢",NavigationPath)
}

//温馨提示设定
const TipsSettings=()=>{
  const NavigationPath="TipsSettings"
  emit("addTabs","溫馨提示設定",NavigationPath)
}

//打印公告单
const PrintBulletin=()=>{
  const NavigationPath="PrintBulletin"
  emit("addTabs","公告列印",NavigationPath)
}

//参考文件设定
const SetAccordingDocument=()=>{
  const NavigationPath="SetAccordingDocument"
  emit("addTabs","參考文件設定",NavigationPath)
}

//单条奖惩条例添加 
const OrdinanceInput=()=>{
  const NavigationPath="OrdinanceInput"
  emit("addTabs","单条奖惩条例",NavigationPath)
}

//奖惩条例导入 
const OrdinanceImport=()=>{
  const NavigationPath="OrdinanceImport"
  emit("addTabs","奖惩条例导入",NavigationPath)
}

//奖惩条例查询
const OrdinanceEnquiry=()=>{
  const NavigationPath="OrdinanceEnquiry"
  emit("addTabs","獎懲條例查詢",NavigationPath)
}

//纸档签核设定
const PaperSetting=()=>{
  const NavigationPath="PaperSetting"
  emit("addTabs","纸档签核设定",NavigationPath)
}

</script>

<style scoped>
.el-menu-item.is-active{
  background-color: #daf2fe !important;
}
*{
  user-select: none;
}
</style>