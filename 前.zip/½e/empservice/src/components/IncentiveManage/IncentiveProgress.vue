<template>
  <h2 class="table-title">獎懲進度查詢</h2>

  <!--头部查询框-->
  <div id="btn">
    <el-button id="seletbtn" @click="SelectDialog=true" type="primary">查询</el-button>
    <el-button id="seletbtn" @click="ExportDcoument()" type="primary">導出獎懲單</el-button>
    <el-button id="seletbtn" @click="ExportAbsenteeism()" type="primary">導出曠工單</el-button>
  </div>
  
  <!--表单-->
  <el-table :data="Data" id="big-width" @row-click="RequestHostroy" @selection-change="changeColumn">
    <el-table-column type="selection" width="55" prop="changes" fixed  />
    <el-table-column label="序號" type="index" width="80" fixed />
    <el-table-column label="工號" prop="emp_no" width="100" fixed />
    <el-table-column label="姓名" prop="name" width="120" fixed />
    <el-table-column label="獎懲等級" prop="jc_dj" width="100" />
    <el-table-column label="年資" prop="INFACTORY" width="130"/>
    <el-table-column label="資位" prop="f_grand" width="120" />
    <el-table-column label="部門名稱" prop="f_departname" width="220" />
    <el-table-column label="提報人" prop="tbr" width="120" />
    <el-table-column label="提報日期" prop="edittime" width="100" />
    <el-table-column label="簽核狀態" prop="status" width="100" />
    <el-table-column label="簽核主管" prop="signer" width="100" />
    <el-table-column label="代理人" prop="agent" width="100" />
    <el-table-column label="生效日期" prop="overDate" width="100" />
    <el-table-column label="職業健康體檢" prop="healthy" width="120" />
    <el-table-column label="待交接项目" prop="awaits" width="120" />
    <el-table-column label="操作" fixed="right" width="200">
      <template #default="scope">
        <el-button size="small" type="primary">詳情</el-button>
        <el-button size="small" type="primary" 
                   @click.stop="Prints(scope.$index, scope.row)">打印</el-button>
        <el-button size="small" type="danger" 
                   @click.stop="ShowCancel(scope.$index, scope.row)">取消</el-button>
      </template>
    </el-table-column>
  </el-table>

  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>

    <!--查询框-->
    <el-dialog v-model="SelectDialog" 
               title="選擇查詢條件" 
               width="35%" 
               style="min-width: 700px;"
               :close-on-click-modal="false" 
               draggable
               :close-icon="CloseBold">
      <el-form :model="form" label-width="120px">
        <!--第一行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="員工工號：">
                  <el-input v-model="form.empno" autocomplete="off" />
                </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="員工姓名：">
                  <el-input v-model="form.Name" autocomplete="off" />
                </el-form-item>
            </el-col>
        </el-row>

        <!--第二行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="提報人工號：">
                    <el-input v-model="form.ReporterEmpno" autocomplete="off" />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="提報人姓名：">
                    <el-input v-model="form.ReporterName" autocomplete="off" />
                </el-form-item>
            </el-col>
        </el-row>

        <!--第三行-->
        <el-form-item label="提報日期：">
            <el-config-provider :locale="zhCn">
              <el-date-picker v-model="form.f_occurdate" type="daterange" range-separator="To"
                            start-placeholder="開始日期" end-placeholder="結束日期" 
                            :shortcuts="shortcuts" size="default" unlink-panels
                            value-format="YYYY-MM-DD"/>
            </el-config-provider>
        </el-form-item>

        <!--第四行-->
        <el-form-item label="結案日期：">
            <el-config-provider :locale="zhCn">
              <el-date-picker v-model="form.Closedate" type="daterange" range-separator="To"
                            start-placeholder="開始日期" end-placeholder="結束日期" 
                            :shortcuts="shortcuts" size="default" unlink-panels
                            value-format="YYYY-MM-DD"/>
            </el-config-provider>
        </el-form-item>

        <!--第五行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="獎懲類別：">
                    <el-select v-model="form.jc_type" placeholder="請選擇" clearable>
                        <el-option v-for="item in jc_type" :key="item" :label="item" :value="item" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="獎懲等級：">
                    <el-select v-model="form.jc_dj" placeholder="請選擇" clearable>
                        <el-option v-for="item in jc_dj" :key="item" :label="item" :value="item" />
                    </el-select>
                </el-form-item>
            </el-col>
        </el-row>

        <!--第六行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="當前狀態：">
                    <el-select v-model="form.status" placeholder="請選擇" clearable>
                        <el-option v-for="item in status" :key="item" :label="item" :value="item" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="廠區：">
                  <span>{{form.plantName}}</span>
                </el-form-item>
            </el-col>
        </el-row>

        <!--第七行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="職業健康體檢：">
                    <el-select v-model="form.healthy" placeholder="請選擇" clearable>
                        <el-option label="Y" value="Y" />  
                        <el-option label="N" value="N" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="申請類型：">
                    <el-select v-model="form.ApplicationType" placeholder="請選擇" clearable>
                        <el-option label="正常申請" value="正常申請" />  
                        <el-option label="紙檔簽核" value="紙檔簽核" /> 
                        <el-option label="調前記錄" value="調前記錄" /> 
                    </el-select>
                </el-form-item>
            </el-col>
        </el-row>

        <!--第八行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="在職狀態：">
                    <el-select v-model="form.f_isleave" placeholder="請選擇" clearable>
                        <el-option label="在職" value="N" />  
                        <el-option label="離職" value="Y" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="部門名稱：">
                    <el-select v-model="form.f_departname" placeholder="請選擇" clearable>
                        <el-option v-for="item in organization" :key="item.lable" 
                          :label="item.lable" :value="item.values" />
                    </el-select>
                </el-form-item>
            </el-col>
        </el-row>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="SelectIncentive()">查询</el-button>
        </span>
      </template>
    </el-dialog>
    
    <!--取消框-->
    <el-dialog v-model="CancelDialog" 
               title="取消" 
               width="35%" 
               :close-on-click-modal="false"
               :close-icon="CloseBold"  
               draggable>
      <el-form :model="CancelForm" label-width="120px" ref="CancelForms" :rules="OverRules">
        <el-form-item label="簽核意見：" prop="MEMO">
          <el-input v-model="CancelForm.MEMO" type="textarea" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="Cancel()">确认</el-button>
          <el-button @click="CancelDialog=false">取消</el-button>
        </span>
      </template>
    </el-dialog>
     
    <!--单据明细查询框-->
    <el-dialog v-model="HoistoryDialog" 
               title="獎懲單據明細" 
               width="70%" 
               style="background-color: #e8e4e4;"
               :close-icon="CloseBold"
               :destroy-on-close="true">
      <template #default>
        <History ref="HistoryBox"></History>
      </template>
      <template #footer>
      </template>
    </el-dialog>

    <template>
      <Incentive ref="Incentives"></Incentive>
    </template>
</template>

<script setup>
import { Axios,Token,DownLoad } from '/src/Axios'
import {reactive, ref, nextTick} from 'vue'
import { ElMessage,ElMessageBox } from 'element-plus'
import { CloseBold } from '@element-plus/icons-vue'
import Incentive from '/src/components/IncentiveManage/PrintIncentive.vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import route from '/src/router'
import History from '/src/pages/Histroy.vue'
import { IncentiveExcel,AbsenteeismExcle } from '/src/ExportExcel' 


// #region 绑定数据
//对话框
const SelectDialog=ref(true)
//明细框
const HoistoryDialog=ref(false)
const plants={
    '001':'龍華',
    '002':'杭州',
    '005':'重慶',
    '003':'南寧',
}
//表单数据
const form=reactive({
    plant:localStorage.getItem('userType'),
    plantName:plants[localStorage.getItem('plant')],
    empno:'',
    ReporterEmpno:'',
    ReporterName:'',
    jc_type:'',
    jc_dj:'',
    f_departname:'',
    status:'',
    f_occurdate:null,
    healthy:'',
    Closedate:null,
    ApplicationType:'',
    f_isleave:'',
    Name:''
})



//快捷日期选择
const shortcuts = [
  {
    text: '上個星期',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      return [start, end]
    },
  },
  {
    text: '上個月',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      return [start, end]
    },
  },
  {
    text: '最近 3 個月',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      return [start, end]
    },
  },
]


//奖惩类别数据
const jc_type=ref(['表現優秀','違反工作紀律','違反生活紀律','品行操守不良','違法或犯罪嫌疑','違反資訊安全','違反安全事故','違反工作紀律(曠工開除)'])

//奖惩等级数据
const jc_dj=ref(['嘉獎一次' ,'小功一次','大功一次','警告一次','小過一次','大過一次','開除','警告二次','小過二次','大過二次'])

//当前状态数据  
const status=ref(['待確認','待簽核','待結案','已結案','已公告','已取消','駁回'])

//部门数据
const organization=reactive([])


// #endregion

//表格数据
const tableData = reactive([])


// #region 查询
//获取部门数据
const RequstOrganization=()=>{
  Axios({
    url:'IncentiveManage/GetOrganization',
    method:'post',
  }).then(
    res=>{
      const data=res.data
      for(let i=0;i<data.Data.length;i++){
        organization[i]={
          lable:data.Data[i].F_ORGANNAME,
          values:data.Data[i].F_ORGANNO,
        }
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequstOrganization()

//dialog框查询《请求》
const SelectIncentive=()=>{
  Axios({
    url:'IncentiveManage/GetIncentiveProgress',
    method:'post',
    params:{
      empno:form.empno,//工号
      plant:form.plant,//厂区
      ReporterEmpno:form.ReporterEmpno,//提报人工号
      ReporterName:form.ReporterName,//提报人姓名
      jc_type:form.jc_type,//类型
      jc_dj:form.jc_dj,//等级
      f_departname:form.f_departname,//部门名称
      status:form.status,//表格状态
      stratTime: (form.f_occurdate!=null)?form.f_occurdate[0]:'',//时间间隔
      endTime:(form.f_occurdate!=null)?form.f_occurdate[1]:'',//时间间隔
      healthy:form.healthy,//体检状态
      f_isleave:form.f_isleave,
      ApplicationType:form.ApplicationType,
      Closestrat:(form.Closedate!=null)?form.Closedate[0]:'',//时间间隔
      CloseEnd:(form.Closedate!=null)?form.Closedate[1]:'',//时间间隔
      Name:form.Name
    }
  }).then(
    res=>{
      const data=res.data
      const Tables=data.Data
      tableData.length=0
      for(let i=0;i<Tables.length;i++){
        tableData[i]={
          apply_no: Tables[i].APPLY_NO,
          emp_no: Tables[i].EMP_NO,
          name: Tables[i].NAME,
          duty: Tables[i].DUTY,
          f_grand: Tables[i].F_GRAND,
          f_departname: Tables[i].F_DEPARTNAME,
          f_infactorydate: Tables[i].F_INFACTORYDATE,
          tbr: Tables[i].TBR,
          tbr_tel: Tables[i].TBR_TEL,
          signtime: Tables[i].SIGNERTIME,
          remark: Tables[i].REMARK,
          file_name: Tables[i].FILE_NAME,
          jc_yj: Tables[i].JC_YJ,
          jc_tl: Tables[i].JC_TL,
          f_jcitemcontent: Tables[i].F_JCITEMCONTENT,
          jc_dj: Tables[i].JC_DJ,
          jc_type: Tables[i].JC_TYPE,
          f_delistype: Tables[i].F_DELISTYPE,
          absenteeismdate: Tables[i].F_ABSENTDATE,
          f_changetype: Tables[i].F_CHANGETYPE,
          f_jcdj_new: Tables[i].F_JCDJ_NEW,
          f_changereason: Tables[i].F_CHANGEREASON,
          hr_file_name: Tables[i].HR_FILE_NAME,
          signer:Tables[i].SIGNER,
          agent:Tables[i].AGENT,
          status:Tables[i].STATUS,
          time_year:Tables[i].TIME_YEAR,
          edittime:Tables[i].EDITTIME,
          healthy:Tables[i].F_ISSPECIALSTATION,//体检状态
          Signers:undefined,//签核记录
          IncentiveYear:undefined,//年度奖惩信息
          awaits:Tables[i].AWAITS,
          INFACTORY:Tables[i].INFACTORY,
          overDate:Tables[i].OVERDATE
        }
      } 
      DataCount.value=tableData.length
      Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
  SelectDialog.value = false
}

const HistoryBox=ref()
//
//请求hostroy数据
const RequestHostroy=(rows,type)=>{
  HoistoryDialog.value=true
  nextTick(()=>{
    HistoryBox.value.RequestHostory(rows.apply_no,rows.emp_no,rows.time_year)
  })
}
// #endregion

// #region 取消单据
const CancelDialog=ref(false)
//表单
const CancelForms=ref()
//表单数据
const CancelForm=reactive({
  apply_no:'',
  MEMO:'',
  index:'',
})
//签核意见表单check
const OverRules=reactive({
  MEMO:[{
    required: true, message: '簽核意見不能為空', trigger: 'blur'
  }],
})
//显示签核意见弹窗
const ShowCancel=(index,row)=>{
  if(row.status=='已取消'&&row.status=='紙檔簽核'&&row.status=='已公告'
     &&row.status=='調前記錄'&&row.status=='已結案'){
    ElMessage({
      type: 'info',
      message: '當前單據狀態不能取消！',
    })
    return
  }
  CancelDialog.value=true
  CancelForm.index=index
  CancelForm.apply_no=row.apply_no
}
//取消当前单据
const Cancel=()=>{
  CancelForms.value.validate((valid) => {
    if(valid){
      CancelRequest()
    }else{}
  })
}
//取消单据请求
const CancelRequest=()=>{
  Axios({
    url:'IncentiveManage/CancelIcnetive',
    method:'post',
    params:{
      apply_no:CancelForm.apply_no,
      MEMO:CancelForm.MEMO
    }
  }).then(
    res=>{
      CancelDialog.value=false
      Data[CancelForm.index].status='已取消'
      ElMessage({
        type: 'success',
        message: '已取消',
      })
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

// #region 打印奖惩单据
//奖惩单模板
const Incentives=ref()
//打印单据数据
const Incentivedata={
  name:'1',
  departname:'2',
  empno:'3',
  Reson:'4',
  jc_yj:'5',
  jc_type:'6',
  jc_content:'7',
  jc_dj:'',
  f_changetype:'',
  sign:{
    signName0:'',
    signDate0:'',
    signName1:'',
    signDate1:'',
    signName2:'',
    signDate2:'',
    signName3:'',
    signDate3:'',
    signName4:'',
    signDate4:'',
    signName5:'',
    signDate5:'',
    signName6:'',
    signDate6:'',
  },

  //岗位
  posts:'',
  //在职时间
  StartTime:'',
  EndTime:'',
  //身份证号
  idNumber:''
}
//打印奖惩单
const Prints=async(index,row)=>{
  Incentivedata.name=row.name
  Incentivedata.departname=row.f_departname
  Incentivedata.empno=row.emp_no
  Incentivedata.Reson=row.remark
  Incentivedata.jc_yj=row.jc_yj+row.jc_tl
  Incentivedata.jc_type=row.jc_type
  Incentivedata.jc_content=row.f_jcitemcontent
  Incentivedata.f_changetype=row.f_changetype
  if(Incentivedata.f_changetype==='否'){
    Incentivedata.jc_dj=row.jc_dj
  }else{
    Incentivedata.jc_dj=row.f_jcdj_new
  }//
  await new Promise((resolve,reject)=>{
    return RequestSigner(row,resolve)
  }).then(()=>{
    Incentivedata.sign={
      signName0:'',
      signDate0:'',
      signName1:'',
      signDate1:'',
      signName2:'',
      signDate2:'',
      signName3:'',
      signDate3:'',
      signName4:'',
      signDate4:'',
      signName5:'',
      signDate5:'',
      signName6:'',
      signDate6:'',
    }
    //给Singers赋值
    if(row.Signers!=undefined){
      for(let i=0;i<row.Signers.length;i++){
        switch(row.Signers[i].SIGNTYPE){
          case "課級主管初審":
            Incentivedata.sign.signName0=row.Signers[i].F_NAME
            Incentivedata.sign.signDate0=row.Signers[i].SIGNTIME
          break;
          case "部級主管審核":
            Incentivedata.sign.signName1=row.Signers[i].F_NAME
            Incentivedata.sign.signDate1=row.Signers[i].SIGNTIME
          break;
          case "處級主管複審":
            Incentivedata.sign.signName2=row.Signers[i].F_NAME
            Incentivedata.sign.signDate2=row.Signers[i].SIGNTIME
          break;
          case "最高主管核准":
            Incentivedata.sign.signName3=row.Signers[i].F_NAME
            Incentivedata.sign.signDate3=row.Signers[i].SIGNTIME
          break;
          case "人資主管審核":
            Incentivedata.sign.signName4=row.Signers[i].F_NAME
            Incentivedata.sign.signDate4=row.Signers[i].SIGNTIME
          break;
          case "工會簽核":
            Incentivedata.sign.signName5=row.Signers[i].F_NAME
            Incentivedata.sign.signDate5=row.Signers[i].SIGNTIME
          break;
          }
    }
    //为開除打印开除通知 《请求》
    if(Incentivedata.jc_dj==='開除'){
      //赋值
      Incentivedata.idNumber
    }
    }
    Incentives.value.PrintsDocument(Incentivedata)
  })
}//
//获取签核记录
const RequestSigner=(row,resolve)=>{
  Axios({
    url:'IncentiveManage/GetHistory',
    method:'post',
    params:{
      applyno:row.apply_no
    }
  }).then(
    res=>{
      const data=res.data.Data
      row.Signers=data
      resolve()
    }
  ).catch(
    err=>{
      resolve()
      console.log(err)
    }
  )
}
// #endregion

//
//选中的表格数据
let ChangesData=reactive([])
//获取选中数据
const changeColumn=(value)=>{
  ChangesData=value
}
// #region 导出奖惩单据
const ExportDcoument=()=>{
  if(Data.length==0){
    return
  }
  Axios({
    url:'IncentiveManage/ExportIncentive',
    method:'post',
    params:{
      apply_no: JSON.stringify(Data.map(obj=>obj.apply_no)),
      emp_no:JSON.stringify(Data.map(obj=>obj.emp_no))
    }
  }).then(
    res=>{
      const data=res.data.Data
      let datas=[[]]
      for(let i=0;i<Data.length;i++){
        const cdt=Data[i]
        datas[i]=[i+1,cdt.emp_no,cdt.name,cdt.f_departname
        ,cdt.f_grand,cdt.INFACTORY,cdt.jc_dj,cdt.jc_type,cdt.remark,cdt.absenteeismdate
        ,data.SinerOver,data.CloseDate,cdt.status,cdt.signer,cdt.agent
        ,cdt.healthy,cdt.healthy==='Y'?data.Attendance:'',data.AwaitWork] 
      }
      IncentiveExcel(datas,'獎懲單據')
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

// #region 导出旷工单
const ExportAbsenteeism=()=>{
  if(Data.length==0){
    return
  }
  for(let i=0;i<Data.length;i++){
    if(Data[i]['jc_dj']!='曠工開除'){
      ElMessageBox.alert('有選中員工不為曠工開除！','提示',{
        confirmButtonText: '確認',
        type: 'warning',
        draggable: true,
      })
      return
    }
  }
  Axios({
    url:'IncentiveManage/AbsenteeismDcoument',
    method:'post',
    params:{
      apply_nos: JSON.stringify(Data.map(obj=>obj.emp_no))
    }
  }).then(
    res=>{
      const data=res.data.Data
      let dats=[[]]
      for(let i=0;i<Data.length;i++){
          //法人名稱,入職日期,事業處
          dats[i]=[(i+1),Data[i]['emp_no'],Data[i]['name']
            ,data[i]['f_artificial'],data[i]['f_infactorydate']
            ,data[i]['f_subbu'],Data[i]['f_grand'],Data[i]['jc_type']
            ,Data[i]['absenteeismdate']]
      }
      AbsenteeismExcle(dats)
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
  
}
// #endregion

// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
// #endregion

</script>

<style scoped>
.el-input{
  width:auto;
}
.disbolk {
  background-color: gray;
  border: gray;
  /*禁用按钮*/
  pointer-events: none;
}

.demo-table-expand{
  margin-top:20px;
}

td div{
  text-align:left;
  margin-left:20px;
}
.el-form-item{
  width:100%;
}

#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}
</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}
</style>