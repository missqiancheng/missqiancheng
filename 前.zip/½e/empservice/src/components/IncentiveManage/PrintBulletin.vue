<template>
  <h2 class="table-title">列印公告單</h2>

  <!--头部查询框-->
  <div id="btn">
    <el-button id="seletbtn" @click="Punishs()" type="primary">列印公告單</el-button>
    <el-button id="seletbtn" @click="SelectDialog=true" type="primary">查询</el-button>
  </div>
  
  <!--表单-->
  <el-table :data="Data" id="big-width" @selection-change="changeColumn">
    <el-table-column type="selection" width="55" prop="changes" fixed  />
    <el-table-column label="序號" type="index" width="80" fixed />
    <el-table-column label="工號" prop="EMP_NO" width="100" fixed />
    <el-table-column label="姓名" prop="NAME" width="120" fixed />
    <el-table-column label="獎懲等級" prop="JC_DJ" width="100" />
    <el-table-column label="年資" prop="INFACTORY" width="140" />
    <el-table-column label="資位" prop="F_GRAND" width="120" />
    <el-table-column label="部門名稱" prop="F_DEPARTNAME" width="220" />
    <el-table-column label="提報人" prop="TBR" width="120" />
    <el-table-column label="提報日期" prop="EDITTIME" width="120" />
    <el-table-column label="簽核狀態" prop="STATUS" width="100" />
    <el-table-column label="簽核主管" prop="SIGNER" width="100" />
    <el-table-column label="代理人" prop="AGENT" width="100" />
    <el-table-column label="生效日期" prop="OVERDATE" width="100" />
    <el-table-column label="職業健康體檢" prop="F_ISSPECIALSTATION" width="120" />
    <el-table-column label="待交接項目" prop="AWAITS" width="120" />
  </el-table>

  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>
  
    <!--查询框-->
    <el-dialog v-model="SelectDialog" title="選擇查詢條件" width="35%" 
               style="min-width: 700px;" :close-on-click-modal="false"  draggable>
      <el-form :model="form" label-width="120px">
        <!--第一行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="員工工號：">
                  <el-input v-model="form.empno" autocomplete="off" />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="部門名稱：">
                    <el-select v-model="form.f_departname" placeholder="請選擇" clearable>
                        <el-option v-for="item in organization" :key="item.lable" 
                          :label="item.lable" :value="item.lable"  />
                    </el-select>
                </el-form-item>
            </el-col>
        </el-row>

        <!--第二行-->
        <el-form-item label="发生日期：">
            <el-config-provider :locale="zhCn">
              <el-date-picker v-model="form.dates" type="daterange" range-separator="To"
                            start-placeholder="開始日期" end-placeholder="結束日期" 
                            :shortcuts="shortcuts" size="default" clearable
                            value-format="YYYY-MM-DD"/>
            </el-config-provider>
        </el-form-item>

        <!--第三行-->
        <el-row>
            <el-col :span="12">
                <el-form-item label="公告類別：">
                    <el-select v-model="form.BUlletintype" placeholder="請選擇" clearable>
                        <el-option v-for="item in BUlletintype" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="12">
            </el-col>
        </el-row>

      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="SelectIncentive()">查询</el-button>
        </span>
      </template>
    </el-dialog>
    
  <template>
    <PrintReward ref="Reward"></PrintReward>
  </template>
  <template>
    <PrintPunish ref="Punish"></PrintPunish>  
  </template>

</template>

<script setup>
import {reactive, ref} from 'vue'
import { ElMessage,ElMessageBox } from 'element-plus'
import PrintReward from '/src/components/IncentiveManage/PrintReward.vue'
import PrintPunish from '/src/components/IncentiveManage/PrintPunish.vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import { Axios } from '../../Axios'



// #region 绑定数据
//对话框
const SelectDialog=ref(true)

//快捷日期选择
const shortcuts = [
  {
    text: '上個星期',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      return [start, end]
    },
  },
  {
    text: '上個月',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      return [start, end]
    },
  },
  {
    text: '最近 3 個月',
    value: () => {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      return [start, end]
    },
  },
]

//表单数据
const form=reactive({
    plant:'',
    empno:'',
    BUlletintype:'',
    f_departname:'',
    dates:null,
})

//公告单类别数据
const BUlletintype=ref([
  {
    name:'嘉獎令',
    value:'J'
  },
  {
    name:'懲戒令',
    value:'C'
  }
])

//厂区数据
const plant=reactive([
    {name:'龙华',value:'001'},
    {name:'杭州',value:'002'},
    {name:'重庆',value:'005'},
    {name:'南宁',value:'003'}
])

//部门数据
const organization=reactive([])

// #endregion

// #region 打印公告单
//选中的表格数据
let ChangesData=[]
//获取选中数据
const changeColumn=(value)=>{
  ChangesData=value
}
//打印公告单
const Reward=ref()
const Punish=ref()
//惩戒单
const Punishs=()=>{
  if(ChangesData.length<1){
    return
  }
  if(ChangesData>4){
    ElMessageBox.alert('一次最多列印四條','提示',{
      confirmButtonText: '確認',
      type: 'warning',
      draggable: true,
    })
    return
  }
  //check奖惩单类型
  for(let i=0;i<ChangesData.length;i++){
    if(ChangesData[0].JC_DJ_TYPE!==ChangesData[i].JC_DJ_TYPE){
      ElMessageBox.alert('選中的資料獎懲類型不一致！','提示',{
        confirmButtonText: '確認',
        type: 'warning',
        draggable: true,
      })
      return
    }
    if(ChangesData[0].F_PLANT_NO!==ChangesData[i].F_PLANT_NO){
      ElMessageBox.alert('當前選中的資料廠區不一致！','提示',{
        confirmButtonText: '確認',
        type: 'warning',
        draggable: true,
      })
      return
    }
    if(ChangesData[0].TIME_YEAR!==ChangesData[i].TIME_YEAR){
      ElMessageBox.alert('當前選中的資料申請年份不一致！','提示',{
        confirmButtonText: '確認',
        type: 'warning',
        draggable: true,
      })
      return
    }
  }
  for(let i=0;i<ChangesData.length;i++){
    tableData.splice(tableData.findIndex(item => item.APPLY_NO===ChangesData[i].APPLY_NO),1)
    Data.splice(Data.findIndex(item => item.APPLY_NO===ChangesData[i].APPLY_NO),1)
  }
  if(ChangesData[0].JC_DJ_TYPE=='C'){
    Punish.value.Punish(ChangesData)
  }else{
    Reward.value.Reward(ChangesData)
  }
}
// #endregion

// #region 请求
//dialog框查询  《请求》
const SelectIncentive=()=>{
  Axios({
    url:'IncentiveManage/GetPrintBulletin',
    method:'post',
    params:{
      empno:form.empno,
      departname:form.f_departname,
      starttime:(form.dates!=null)?form.dates[0]:'',//时间间隔
      endtime:(form.dates!=null)?form.dates[1]:'',//时间间隔
      bulletintype:form.BUlletintype,
      plant:form.plant,
    }
  }).then(
    res=>{
      const data=res.data.Data
      tableData.length=0
      for(let i=0;i<data.length;i++){
        tableData[i]=data[i]
      } 
      DataCount.value=tableData.length
      Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
  SelectDialog.value = false
}

//表格数据  《请求》
const tableData = reactive([])

//获取部门数据
const RequstOrganization=()=>{
  Axios({
    url:'IncentiveManage/GetOrganization',
    method:'post',
  }).then(
    res=>{
      const data=res.data
      for(let i=0;i<data.Data.length;i++){
        organization[i]={
          lable:data.Data[i].F_ORGANNAME,
          values:data.Data[i].F_ORGANNO,
        }
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequstOrganization()
// #endregion

// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}

//动态显示年度奖惩表格背景
const tableRowClassName=(row,rowIndex)=>{
  if(row.row.jc_dj==="大过一次"){
    return "TabBg"
  }else if(row.row.jc_dj==="大过二次"){
    return "TabBg"
  }
}
// #endregion

</script>

<style scoped>
.el-input{
  width:auto;
}
.disbolk {
  background-color: gray;
  border: gray;
  /*禁用按钮*/
  pointer-events: none;
}

.demo-table-expand{
  margin-top:20px;
}

td div{
  text-align:left;
  margin-left:20px;
}
.el-form-item{
  width:100%;
}
#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}
</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}
</style>