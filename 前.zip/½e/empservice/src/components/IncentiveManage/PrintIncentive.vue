<template>
  <div></div>
  <div class="Document" :id="Rod">
    <h1 class="Document-header">員工獎懲單</h1>

    <table class="IncentiveTable">
      <!--基本信息-->
      <tr>
        <td class="BRightBorder Centers Font-height GddName"><b>姓名</b></td>
        <td class="BRightBorder Centers OneName">{{DcoumentDome.name}}</td>
        <td class="BRightBorder Centers GddName"><b>單位</b></td>
        <td class="BRightBorder Centers" colspan="3">{{DcoumentDome.departname}}</td>
        <td class="BRightBorder Centers GddName"><b>工號</b></td>
        <td class="bottomBorder Centers TwoEmp" colspan="2">{{DcoumentDome.empno}}</td>
      </tr>
      <!--奖惩原由-->
      <tr>
        <td rowspan="3" class="BRightBorder Centers Content-height"><b>獎懲原由</b></td>
        <td class="IncentiveRemrk" colspan="9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{DcoumentDome.Reson}}</td>
      </tr>
      <tr>
        <td class="empsign" colspan="9">
          獎（懲）人簽名：<div class="Sign-line"></div>
        </td>
      </tr>
      <tr>
        <td class="bottomBorder empsign" colspan="9">
          日&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;期：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;年&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;月&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;日
        </td>
      </tr>
      <!--奖惩依据-->
      <tr>
        <td class="BRightBorder Centers Font-height"><b>獎懲依據</b></td>
        <td class="bottomBorder PDRIGTH" colspan="9">{{DcoumentDome.jc_yj}}</td>
      </tr>
      <!--奖惩类型-->
      <tr>
        <td class="BRightBorder Centers Font-height"><b>處理類別</b></td>
        <td class="bottomBorder PDRIGTH" colspan="9">{{DcoumentDome.jc_dj}}</td>
      </tr>
      <!--奖惩条例-->
      <tr>
        <td class="BRightBorder Centers Font-height singMax"><b>獎懲內容</b></td>
        <td class="bottomBorder PDRIGTH singMax" colspan="9">
          {{ DcoumentDome.jc_content }}
        </td>
      </tr>
    </table>
    <!--签核类型-->
    <table class="IncentiveTable IncentiveBotton Centers">
      <tr>
        <td class="BRightBorder Centers Signtype-height tit-width"
            rowspan="2" colspan="2"><b>獎懲等級</b></td>
        <td colspan="2" class="BRightBorder Font-height">簽核許可權</td>
        <td colspan="5" class="bottomBorder">○簽核&nbsp;&nbsp;●核准&nbsp;&nbsp;▲會簽</td>
      </tr>
      <tr>
        <td class="BRightBorder One-width">課級主管</td>
        <td class="BRightBorder One-width">部級主管</td>
        <td class="BRightBorder One-width">處級主管</td>
        <td class="BRightBorder tow-width">事業處最高主管</td>
        <td class="BRightBorder tree-width">法務</td>
        <td class="BRightBorder One-width">人資主管</td>
        <td class="BRightBorder tree-width">工會</td>
      </tr>
      <tr>
        <td colspan="2" class="BRightBorder Centers Font-height"><b>{{ DcoumentDome.jc_dj1 }}</b></td>
        <td class="BRightBorder One-width">○</td>
        <td class="BRightBorder One-width">○</td>
        <td class="BRightBorder One-width">○</td>
        <td class="BRightBorder tow-width">
          <span v-if="DcoumentDome.jc_dj.includes('開除')||DcoumentDome.jc_dj=='大過'||DcoumentDome.jc_dj=='大功'||DcoumentDome.f_changetype==true">●</span>
        </td>
        <td class="BRightBorder tree-width">
          <span v-if="DcoumentDome.jc_dj.includes('開除')">▲</span>
        </td>
        <td class="BRightBorder One-width">
          <span>▲</span>
        </td>
        <td class="BRightBorder tree-width">
          <span v-if="DcoumentDome.jc_dj.includes('開除')">▲</span>
        </td>
      </tr>
    </table>

    <!--主管签名-->
    <table class="signsNames">
      <tr>
        <td class="cloumn">
          <div class="signsNames"><b class="titlesName">{{DcoumentDome.sign.signName0}}</b>&nbsp;{{DcoumentDome.sign.signDate0}}</div>
          <div class="lines"><hr size="2" color="black"></div>
          <div class="linetitle">課級主管&nbsp;&nbsp;<b v-if="DcoumentDome.sign.signName0!==''">同意</b></div>
        </td>
        <td class="cloumn">
          <div class="signsNames"><b class="titlesName">{{DcoumentDome.sign.signName1}}</b>&nbsp;{{DcoumentDome.sign.signDate1}}</div>
          <div class="lines"><hr size="2" color="black"></div>
          <div class="linetitle">部級主管&nbsp;&nbsp;<b v-if="DcoumentDome.sign.signName1!==''">同意</b></div>
        </td>
        <td class="cloumn">
          <div class="signsNames"><b class="titlesName">{{DcoumentDome.sign.signName2}}</b>&nbsp;{{DcoumentDome.sign.signDate2}}</div>
          <div class="lines"><hr size="2" color="black"></div>
          <div class="linetitle">處級主管&nbsp;&nbsp;<b v-if="DcoumentDome.sign.signName2!==''">同意</b></div>
        </td>
      </tr>
      <tr>
        <td class="cloumn" v-if="DcoumentDome.jc_dj.indexOf('開除')||DcoumentDome.jc_dj==='大過'||DcoumentDome.jc_dj==='大功'||DcoumentDome.f_changetype===true">
          <div class="signsNames"><b class="titlesName">{{DcoumentDome.sign.signName3}}</b>&nbsp;{{DcoumentDome.sign.signDate3}}</div>
          <div class="lines"><hr size="2" color="black"></div>
          <div class="linetitle">事業處最高主管&nbsp;&nbsp;<b v-if="DcoumentDome.sign.signName3!==''">同意</b></div>
        </td>
        <td class="cloumn">
          <div class="signsNames"><b class="titlesName">{{DcoumentDome.sign.signName4}}</b>&nbsp;{{DcoumentDome.sign.signDate4}}</div>
          <div class="lines"><hr size="2" color="black"></div>
          <div class="linetitle">人資主管&nbsp;&nbsp;<b v-if="DcoumentDome.sign.signName4!==''">同意</b></div>
        </td>
        <td class="cloumn" v-if="DcoumentDome.f_changetype===true||DcoumentDome.jc_dj.indexOf('開除')">
          <div class="signsNames"><b class="titlesName">{{DcoumentDome.sign.signName5}}</b>&nbsp;{{DcoumentDome.sign.signDate5}}</div>
          <div class="lines"><hr size="2" color="black"></div>
          <div class="linetitle">工會&nbsp;&nbsp;<b v-if="DcoumentDome.sign.signName5!==''">同意</b></div>
        </td>
      </tr>
    </table>
    
    <table class="IncentiveTable" v-if="DcoumentDome.jc_dj.indexOf('開除')">
      <tr>
        <td rowspan="3" class="Centers BRightBorder"><b>人資意見</b></td>
        <td class="Font-height PDRIGTH Sign-Offs">依規定開除：同意&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;不同意</td>
        <td class="Font-height mids-hie"><div class="Sign-lines"></div></td>
        <td class="Font-height"></td>
      </tr>
      <tr>
        <td class="Font-height"></td>
        <td class="Font-height"></td>
        <td class="Font-height"></td>
      </tr>
      <tr>
        <td class="Font-height bottomBorder PDRIGTH Sign-Offs">人資主管簽名：</td>
        <td class="Font-height bottomBorder"></td>
        <td class="Font-height bottomBorder"></td>
      </tr>
      <tr>
        <td rowspan="3" class="Centers BRightBorder"><b>工會意見</b></td>
        <td class="Font-height PDRIGTH Sign-Offs">依規定開除：同意&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;不同意</td>
        <td class="Font-height mids-hie"><div class="Sign-lines"></div></td>
        <td class="Font-height"></td>
      </tr>
      <tr>
        <td class="Font-height"></td>
        <td class="Font-height"></td>
        <td class="Font-height"></td>
      </tr>
      <tr>
        <td class="Font-height PDRIGTH Sign-Offs">工會簽名：</td>
        <td class="Font-height"></td>
        <td class="Font-height WIds"></td>
      </tr>
    </table>
    <div class="SignBoxs" v-else></div>

    <!--解除劳动合同证明-->
    <div id="notice" v-if="DcoumentDome.jc_dj.includes('開除')">
      <div class="notice-Tis">{{DcoumentDome.f_artificial}}</div>
      <div class="notice-No">编号：{{ dateNo() }}</div>
      <div class="notice-line"></div>
      <h1 class="notice-header">解除劳动合同证明</h1>
      <div class="notice-content">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;兹有我公司员工
        <span class="underlines">{{FormatString(DcoumentDome.name)}}</span>，工号<span class="underlines">{{DcoumentDome.empno}}</span>，身份证号
        <span class="underlines">{{DcoumentDome.idNumber}}</span>，在职时间从<span class="underlines">{{formatDate(DcoumentDome.StartTime)}}</span>至
        <span class="underlines">{{formatDate(DcoumentDome.EndTime)}}</span>，工作岗位为：<span class="underlines">{{ FormatString(DcoumentDome.posts) }}</span>，于
        <span class="underlines">{{formatDate(DcoumentDome.EndTime)}}</span>双方解除劳动合同，终止劳动关系。</div>
      <div class="notice-show PDRIGTHS">特此证明！</div>
      <div class="notice-firm">{{DcoumentDome.f_artificial}}</div>
      <div class="notice-firm">证明开具日期:{{DatE}}</div>
      <div class="notice-sign">本人已收到解除劳动合同证明正本</div>
      <div class="notice-signs">领取人签名：</div>
      <div class="notice-dates">领取日期：</div>
      
      <div>&nbsp;</div>
      <div class="notice-remark">【备注：此证明请妥善保管，如有遗失， 不予补开，以上内容最终解释权归本公司所有。】</div>
      <div class="notice-line"></div>
      <div class="notice-footer">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;鉴于您已与公司签订《知识产权暨保密协议书》及/或其他保密协议/约定，公司再次提醒：您仍需根据双方约定对任职期间所知悉、接触、持有、使用之公司商业秘密继续承担严格的保密义务，不得为任何非法泄露及/或使用。</div>
      <div class="notice-csf">&nbsp;</div>
      <div class="signs-name">
        <div class="notice-foott">{{ DcoumentDome.Address }}</div>
        <div class="notice-foott notice-cent">{{ DcoumentDome.PhoneNo }}</div>
        <div class="notice-foot notice-rigs">{{ DcoumentDome.EmailNo }}</div>
      </div>
    </div>

    <!--解除劳动合同证明-->
    <div id="notice" v-if="DcoumentDome.jc_dj.includes('開除')">
      <div class="notice-Tis">{{DcoumentDome.f_artificial}}</div>
      <div class="notice-No">编号：{{ dateNo() }}</div>
      <div class="notice-line"></div>
      <h1 class="notice-header">解除劳动合同证明</h1>
      <div class="notice-content">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;兹有我公司员工
        <span class="underlines">{{FormatString(DcoumentDome.name)}}</span>，工号<span class="underlines">{{DcoumentDome.empno}}</span>，身份证号
        <span class="underlines">{{DcoumentDome.idNumber}}</span>，在职时间从<span class="underlines">{{formatDate(DcoumentDome.StartTime)}}</span>至
        <span class="underlines">{{formatDate(DcoumentDome.EndTime)}}</span>，工作岗位为：<span class="underlines">{{ FormatString(DcoumentDome.posts) }}</span>，于
        <span class="underlines">{{formatDate(DcoumentDome.EndTime)}}</span>双方解除劳动合同，终止劳动关系。</div>
      <div class="notice-show PDRIGTHS">特此证明！</div>
      <div class="notice-firm">{{DcoumentDome.f_artificial}}</div>
      <div class="notice-firm">证明开具日期:{{DatE}}</div>
      <div class="notice-sign">&nbsp;</div>
      <div class="notice-signs">&nbsp;</div>
      <div class="notice-dates">&nbsp;</div>

      <div>&nbsp;</div>
      <div class="notice-remark">【备注：此证明请妥善保管，如有遗失， 不予补开，以上内容最终解释权归本公司所有。】</div>
      <div class="notice-line"></div>
      <div class="notice-footer">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;鉴于您已与公司签订《知识产权暨保密协议书》及/或其他保密协议/约定，公司再次提醒：您仍需根据双方约定对任职期间所知悉、接触、持有、使用之公司商业秘密继续承担严格的保密义务，不得为任何非法泄露及/或使用。</div>
      <div class="notice-csf">&nbsp;</div>
      <div class="signs-name">
        <div class="notice-foott">{{ DcoumentDome.Address }}</div>
        <div class="notice-foott notice-cent">{{ DcoumentDome.PhoneNo }}</div>
        <div class="notice-foot notice-rigs">{{ DcoumentDome.EmailNo }}</div>
      </div>
    </div>
    
  </div>

</template>

<script setup>
import '/style/PrintSign.css'
import  print from 'print-js'
import {reactive} from 'vue'
import { syncRef } from '@vueuse/shared';
import { Axios } from '/src/Axios';
import * as OpenCC from 'opencc-js';

const DcoumentDome=reactive({
  name:'1',
  departname:'2',
  empno:'3',
  Reson:'4',
  jc_yj:'5',
  jc_type:'6',
  jc_content:'7',
  jc_dj:'',
  jc_dj1:'',
  //是否变更
  f_changetype:'',
  sign:{
    signName0:'',
    signDate0:'',
    signName1:'',
    signDate1:'',
    signName2:'',
    signDate2:'',
    signName3:'',
    signDate3:'',
    signName4:'',
    signDate4:'',
    signName5:'',
    signDate5:'',
  },

  //岗位
  posts:'',
  //在职时间
  StartTime:'',
  EndTime:'',
  //身份证号
  idNumber:'',
  f_artificial:'',//法人

  //开除单
  Address:'',//厂区地址
  PhoneNo:'',//电话号码
  EmailNo:''//邮箱地址
})

const PrintsDocument=async(data)=>{
  await new Promise((resolver,reject)=>{
    DcoumentDome.name=data.name
    DcoumentDome.departname=data.departname
    DcoumentDome.empno=data.empno
    DcoumentDome.Reson=data.Reson
    DcoumentDome.jc_yj=data.jc_yj
    DcoumentDome.jc_type=data.jc_type
    DcoumentDome.jc_content=data.jc_content
    DcoumentDome.f_changetype=(data.f_changetype==='是')
    DcoumentDome.jc_dj=DcoumentDome.f_changetype?data.jc_dj+'（已變更等級）':data.jc_dj
    DcoumentDome.jc_dj1=DcoumentDome.f_changetype?'等級變更':data.jc_dj
    DcoumentDome.sign=data.sign
    if(DcoumentDome.jc_dj.includes('開除')){
      Axios({
        url:'IncentiveManage/GetExpel',
        method:'post',
        params:{
          emp_no:data.empno
        }
      }).then(
        res=>{
          const dats=res.data.Data[0]
          DcoumentDome.posts=dats.F_POSITION
          DcoumentDome.idNumber=dats.F_IDCARD
          DcoumentDome.StartTime=dats.F_INFACTORYDATE
          DcoumentDome.EndTime=dats.F_LEAVEDATE
          DcoumentDome.f_artificial=FormatString(dats.F_ARTIFICIAL)
          let Foots=dats.F_VALUE.split(',')
          console.log(Foots)
          DcoumentDome.Address=FormatString(Foots[0])
          DcoumentDome.PhoneNo=FormatString(Foots[1])
          DcoumentDome.EmailNo=FormatString(Foots[2])
          resolver()
        }
      ).catch(
        err=>{
          resolver()
          console.log(err)
        }
      )
    }else{
      resolver()
    }
  }).then(()=>{
    print({
      documentTitle:'&nbsp;',
      type:'html',
      printable:Rod,
      scanStyles:true,
      css:'/style/PrintSign.css',
    })
  })
}

//转换日期格式
const formatDate=(dateString)=>{  
    // 解析日期字符串为日期对象  
    var date = new Date(dateString);  
  
    // 获取年份  
    var year = date.getFullYear();  
  
    // 获取月份，注意JavaScript中的月份是从0开始的，所以需要加1  
    var month = date.getMonth() + 1;  
  
    // 获取日期  
    var day = date.getDate();  

    return year + "年" + month + "月" + day + "日";  
}

//转换简体
const FormatString=(data)=>{
  const converter = OpenCC.Converter({ from: 'hk', to: 'cn' });
  return converter(data)
}

const now=new Date()
const dateNo=()=>{
  let TiTleNo=now.getFullYear().toString() 
  
  // 为了保证格式统一，当值小于10时前面补0  
  let month = (now.getMonth() + 1 < 10 ? "0" : "") + (now.getMonth() + 1);  
  let day = (now.getDate() < 10 ? "0" : "") + now.getDate();  

  TiTleNo+=month+day
  if(DcoumentDome.jc_dj=='曠工開除'){
    TiTleNo+='K'
  }else{
    TiTleNo+='W'
  }

  
  return TiTleNo+now.getHours()+now.getMinutes();
} 
const DatE=now.getFullYear()+'年'+(now.getMonth() + 1)+'月'+now.getDate()+'日'

//随机id
const Rod='M' + Math.random() * 10 + 20

defineExpose({PrintsDocument})
</script>

<style scoped>

</style>