<template>
  <div id="Punish">
    <div id="Bodys">
        <div class="Content">
            <div class="index title-border">4</div>
            <div class="empno content-border">{{DoucumentInfo.empno3}}</div>
            <div class="name content-border"><div class="name-txt" >{{DoucumentInfo.name3}}</div></div>
            <div class="department content-border"><div class="dep-txt">{{DoucumentInfo.f_departname3}}</div></div>
            <div class="reson content-border"><div class="reson-txt">{{DoucumentInfo.remark3}}</div></div>
            <div class="type content-border"><div class="type-txt">{{DoucumentInfo.jc_dj3}}</div></div>
            <div class="Book content-border"><div class="type-txt">{{DoucumentInfo.jc_tl3}}</div></div>
            <div class="dates content-border"><div class="date-txt">{{DoucumentInfo.signtime3}}</div></div>
        </div>
        <div class="Content">
            <div class="index title-border">3</div>
            <div class="empno content-border">{{DoucumentInfo.empno2}}</div>
            <div class="name content-border"><div class="name-txt" >{{DoucumentInfo.name2}}</div></div>
            <div class="department content-border"><div class="dep-txt">{{DoucumentInfo.f_departname2}}</div></div>
            <div class="reson content-border"><div class="reson-txt">{{DoucumentInfo.remark2}}</div></div>
            <div class="type content-border"><div class="type-txt">{{DoucumentInfo.jc_dj2}}</div></div>
            <div class="Book content-border"><div class="type-txt">{{DoucumentInfo.jc_tl2}}</div></div>
            <div class="dates content-border"><div class="date-txt">{{DoucumentInfo.signtime2}}</div></div>
        </div>
        <div class="Content">
            <div class="index title-border">2</div>
            <div class="empno content-border">{{DoucumentInfo.empno1}}</div>
            <div class="name content-border"><div class="name-txt" >{{DoucumentInfo.name1}}</div></div>
            <div class="department content-border"><div class="dep-txt">{{DoucumentInfo.f_departname1}}</div></div>
            <div class="reson content-border"><div class="reson-txt">{{DoucumentInfo.remark1}}</div></div>
            <div class="type content-border"><div class="type-txt">{{DoucumentInfo.jc_dj1}}</div></div>
            <div class="Book content-border"><div class="type-txt">{{DoucumentInfo.jc_tl1}}</div></div>
            <div class="dates content-border"><div class="date-txt">{{DoucumentInfo.signtime1}}</div></div>
        </div>
        <div class="Content">
            <div class="index title-border">1</div>
            <div class="empno content-border">{{DoucumentInfo.empno0}}</div>
            <div class="name content-border"><div class="name-txt" >{{DoucumentInfo.name0}}</div></div>
            <div class="department content-border"><div class="dep-txt">{{DoucumentInfo.f_departname0}}</div></div>
            <div class="reson content-border"><div class="reson-txt">{{DoucumentInfo.remark0}}</div></div>
            <div class="type content-border"><div class="type-txt">{{DoucumentInfo.jc_dj0}}</div></div>
            <div class="Book content-border"><div class="type-txt">{{DoucumentInfo.jc_tl0}}</div></div>
            <div class="dates content-border"><div class="date-txt">{{DoucumentInfo.signtime0}}</div></div>
        </div>
        <div class="Content-Headers">
            <div class="index Header-border-top"><div class="Header-Min">NO.</div></div>
            <div class="empno Header-border"><div class="Header-Min-txt">工號</div></div>
            <div class="name Header-border"><div class="Header-Min-txt">姓名</div></div>
            <div class="department Header-border"><div class="Header-Min-txt">單位</div></div>
            <div class="reson Header-border"><div class="Header-Max-txt">違紀事由描述</div></div>
            <div class="type Header-border"><div class="Header-Type-txt">違紀處理類別</div></div>
            <div class="Book Header-border"><div class="Header-Book-txt">違紀處理條款</div></div>
            <div class="dates Header-border"><div class="Header-Date-txt">生效日</div></div>
        </div>
    </div>
    <div id="title">
        <div class="AdminName">人資主管<b class="title-content-bs">{{DoucumentInfo.Manage}}</b></div>
        <div class="title-man">茲公佈<b class="title-content-bs">{{DoucumentInfo.title}}</b>人事懲戒令</div>
        <div class="title-content">
            富士康科技集團Fii-CNS事業群
            <b class="title-content-bs">員工違紀處理公告</b>
            {{DoucumentInfo.Years}}字第{{DoucumentInfo.Years_no}}號
        </div>
    </div>
  </div>
  
</template>

<script setup>
import  print from 'print-js'
import { reactive } from 'vue'
import { ElMessage,ElMessageBox } from 'element-plus'
import '/style/PrintPunish.css'
import { Axios } from '../../Axios'

//单据信息
const DoucumentInfo=reactive({
    //第一列
    empno0:'以下空白',
    name0:'',
    f_departname0:'',
    remark0:'',
    jc_dj0:'',
    jc_tl0:'',
    signtime0:'',

    //第二列
    empno1:'以下空白',
    name1:'',
    f_departname1:'',
    remark1:'',
    jc_dj1:'',
    jc_tl1:'',
    signtime1:'',

    //第三列
    empno2:'以下空白',
    name2:'',
    f_departname2:'',
    remark2:'',
    jc_dj2:'',
    jc_tl2:'',
    signtime2:'',

    //第四列
    empno3:'以下空白',
    name3:'',
    f_departname3:'',
    remark3:'',
    jc_dj3:'',
    jc_tl3:'',
    signtime3:'',

    title:'',
    Manage:'',
    Years:'',//年
    Years_no:'',//第多少号问文件
})
//日期数据
const ChinaDate={
    '0':'零',
    '1':'一',
    '2':'二',
    '3':'三',
    '4':'四',
    '5':'五',
    '6':'六',
    '7':'七',
    '8':'八',
    '9':'九',
    '10':'十',
    '11':'十一',
    '12':'十二',
    '13':'十三',
    '14':'十四',
    '15':'十五',
    '16':'十六',
    '17':'十七',
    '18':'十八',
    '19':'十九',
    '20':'二十',
    '21':'二十一',
    '22':'二十二',
    '23':'二十三',
    '24':'二十四',
    '25':'二十五',
    '26':'二十六',
    '27':'二十七',
    '28':'二十八',
    '29':'二十九',
    '30':'三十',
    '31':'三十一',
}
//打印
const Punish=async(data)=>{
    await new Promise(async(resolver,reject)=>{
        //为空提示
        if(data.length<1){
            ElMessageBox.alert('請選擇要列印的單據','提示',{
              confirmButtonText: '確認',
              type: 'warning',
              draggable: true,
            })
            return
        }
        for(let key in DoucumentInfo){
            if(key.includes('empno')){
                continue
            }
            DoucumentInfo[key]=''
        }
        for(let i=0;i<data.length;i++){
            DoucumentInfo['empno'+i]=EmpNoConver(data[i].EMP_NO)
            DoucumentInfo['name'+i]=NameConver(data[i].NAME)
            DoucumentInfo['f_departname'+i]=data[i].F_DEPARTNAME
            DoucumentInfo['remark'+i]=data[i].REMARK
            DoucumentInfo['jc_dj'+i]=data[i].JC_DJ
            DoucumentInfo['jc_tl'+i]=data[i].JC_YJ+data[i].JC_TL
            //转换日期为中文日期
            const Years=new Date(data[i].OVERDATE)
            let year=Years.getFullYear().toString()
            let mounth=Years.getMonth().toString()
            let day=Years.getDate().toString()
            DoucumentInfo['signtime'+i]=ChinaDate[year[0]]+ChinaDate[year[1]]+ChinaDate[year[2]]+ChinaDate[year[3]]+"年"+ChinaDate[mounth]+"月"+ChinaDate[day]+"日"
            DoucumentInfo.title=DoucumentInfo.title+DoucumentInfo['name'+i]+'、'
        }
        const year=data[0].TIME_YEAR
        DoucumentInfo.Years=ChinaDate[year[0]]+ChinaDate[year[1]]+ChinaDate[year[2]]+ChinaDate[year[3]]
        DoucumentInfo.title=DoucumentInfo.title.substring(0,DoucumentInfo.title.length-1)
        //赋值人资主管
        const apply_no2=(data.length>1)?data[1].apply_no:''
        const apply_no3=(data.length>2)?data[2].apply_no:''
        const apply_no4=(data.length>3)?data[3].apply_no:''
        await RequsetHRLeader(data[0].APPLY_NO,data[0].TIME_YEAR,
        data[0].F_PLANTNO,data[0].JC_DJ_TYPE,apply_no2,apply_no3,apply_no4)
        return resolver()
    })
    print({
        documentTitle:'&nbsp;',
        type:'html',
        printable:'Punish',
        scanStyles:true,
        css:'/style/PrintPunish.css',
    })
}


//获取人资主管,文件号数
const RequsetHRLeader=async(apply_no1, time_year, plantno, jc_dj_type,
apply_no2 = undefined, apply_no3 = undefined, apply_no4 = undefined)=>{
    await Axios({
        url:'/IncentiveManage/Bulletin',
        method:'post',
        params:{
            apply_no1:apply_no1,
            time_year:time_year,
            plantno:plantno,
            jc_dj_type:jc_dj_type,
            apply_no2:apply_no2,
            apply_no3:apply_no3,
            apply_no4:apply_no4,
        }
    }).then(
        res=>{
            const data=res.data.Data
            const years=data.year_no
            for(let i=0;i<years.length;i++){
                DoucumentInfo.Year_no+=ChinaDate[years[i]]
            }
            DoucumentInfo.Manage=data.HRLeader
        }
    ).catch(
        err=>{
            console.log(err)
        }
    )
}

const NameConver=(name)=>{
    if(name.length==2){
        return name[0]+'*'
    }else if(name.length==3){
        return name[0]+'**'
    }else if(name.length==4){
        return name[0]+'***'
    }else if(name.length==5){
        return name[0]+'****'
    }
}

//遮盖工号
const EmpNoConver=(name)=>{
    return name.substring(0,4)+'****'
}

defineExpose({Punish})
</script>