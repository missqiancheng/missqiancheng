<template>
  <h2 class="table-title">獎懲條例查詢</h2>
  
  <!--头部查询框-->
  <div id="btn">
    <el-input type="text" 
              v-model="SearchContent" 
              class="empnos" 
              placeholder="請輸入關鍵詞搜索" 
              :suffix-icon="Search">
    </el-input>
    <el-button id="seletbtn" type="danger" @click="allDelete()">批量刪除</el-button>
  </div>

  <!--表单-->
  <el-table :data="TableData"
            id="big-width" @selection-change="changeColumn">
    <el-table-column type="selection" width="55" prop="changes" fixed  />
    <el-table-column label="序號" type="index" width="80" fixed />
    <el-table-column label="獎懲依據" prop="f_jcitemtype" width="220" />
    <el-table-column label="獎懲條例" prop="f_jctl" width="120"/>
    <el-table-column label="獎懲內容" prop="f_jcitemcontent" width="535" />
    <el-table-column label="獎懲等級" prop="f_jcdj" width="120" />
    <el-table-column label="獎懲類別" prop="f_jctype" width="120" />
    <el-table-column label="編輯人" prop="Editor" width="120" />
    <el-table-column label="編輯時間" prop="f_sysdate" width="120" />
    <el-table-column label="操作" fixed="right">
      <template #default="scope">
        <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">刪除</el-button>
      </template>
    </el-table-column>
  </el-table>

  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30,100,1000]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>

</template>

<script setup>
import { ref,reactive,computed,h,markRaw } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import UpLoad from '/src/pages/UpLoad.vue'
import { Axios,Token } from '/src/Axios'
import { SuccessFilled } from '@element-plus/icons-vue'

// #region 全局变量
//Seach内容
let SearchContent=ref()

//选中的表格数据
let ChangesData=[]
//获取选中数据
const changeColumn=(value)=>{
    ChangesData=value
}

//全部数据
let tableData=reactive([])

// #endregion


const init=()=>{
  Axios({
    url:'IncentiveManage/GetOrdinance',
    method:"post",
  }).then(
    async(res)=>{
      const data=res.data.Data
      await new Promise((resolve,reject)=>{
        for(let i=0;i<data.length;i++){
          tableData[i]={
            f_jcitemtype:data[i].F_JCITEMTYPE,
            f_jctl:data[i].F_JCTL,
            f_jcitemcontent:data[i].F_JCITEMCONTENT,
            f_jcdj:data[i].F_JCDJ,
            f_jctype:data[i].F_JCTYPE,
            Editor:data[i].F_SYSID,
            f_sysdate:data[i].F_SYSDATE,
            f_jcitemno:data[i].F_JCITEMNO
          }//wow
        }
        resolve()
      })
      DataCount.value=data.length
    }
  ).catch( 
    err=>{
      console.log(err)
    }
  )
}
init()

const TableData=computed(()=>{
  return tableData.filter((data) => !SearchContent.value
  ||data['f_jcitemtype'].includes(SearchContent.value)
  ||data['f_jctl'].includes(SearchContent.value)
  ||data['f_jcitemcontent'].includes(SearchContent.value)
  ||data['f_jcdj'].includes(SearchContent.value)
  ||data['f_jctype'].includes(SearchContent.value)
  ||data['Editor'].includes(SearchContent.value)
  ||data['f_sysdate'].includes(SearchContent.value)
  ).splice((pages.value-1)*PagesColumn.value,PagesColumn.value)
})

// #region 单条删除
//删除  《请求》
const handleDelete = (index, row) => {
  ElMessageBox.confirm('確定要刪除目前參考檔案嗎','提示',{
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      type: 'warning',
  }).then(() => {
      DeleteSingle(row.f_jcitemno)
      tableData.splice(tableData.indexOf(row),1)
      DataCount.value--
      ElMessage({
        type: 'success',
        message: '刪除成功',
      })
  }).catch(() => {})
}
//删除单条请求
const DeleteSingle=(f_jcitemno)=>{
  Axios({
    url:'IncentiveManage/DeleteOrdinance',
    method:"post",
    params:{
      f_jcitemno:f_jcitemno
    }
  }).then(
    res=>{
      const data=res.data
      if(data.Code==='200'){
        ElMessageBox.alert('刪除成功！','提示',{
          confirmButtonText: '確認',
          type: 'success',
          draggable: true,
          icon:markRaw(SuccessFilled)
        })
      }else{
        ElMessageBox.alert('刪除失敗！','提示',{
          confirmButtonText: '確認',
          type: 'warning',
          draggable: true,
        })
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

// #region 批量删除
//批量删除  《请求》
const allDelete=()=>{
  ElMessageBox.confirm('確定要刪除目前參考檔案嗎','提示',{
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      type: 'warning',
    }).then(() => {
      if(ChangesData.length===0){
        //提示栏
        ElMessage({
          type: 'info',
          message: '沒有選取資料',
        })
        return
      }

      DeleteData()
      //删除数据
      for(let j=0;j<ChangesData.length;j++){
        tableData.splice(tableData.indexOf(ChangesData[j]),1)
      }
      DataCount.value-=ChangesData.length
      
      //提示栏
      ElMessage({
        type: 'success',
        message: '刪除成功',
      })
  }).catch(() => {})

}
const DeleteData=()=>{ 
  let arr=[]
  for(let i=0;i<ChangesData.length;i++){
    arr[i]=ChangesData[i].f_jcitemno
  }

  Axios({
    url:'IncentiveManage/DeleteOrdinances',
    method:"post",
    params:{
      f_jcitemnos:JSON.stringify(arr)
    }
  }).then(
    res=>{
      const data=res.data
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

// #region 分页
//总行数
const CountNumber=computed(()=>{
  return tableData.filter((data) => !SearchContent.value
  ||data['f_jcitemtype'].includes(SearchContent.value)
  ||data['f_jctl'].includes(SearchContent.value)
  ||data['f_jcitemcontent'].includes(SearchContent.value)
  ||data['f_jcdj'].includes(SearchContent.value)
  ||data['f_jctype'].includes(SearchContent.value)
  ||data['Editor'].includes(SearchContent.value)
  ||data['f_sysdate'].includes(SearchContent.value)
  ).length
})
const DataCount=ref(CountNumber)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive([])
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
}
// #endregion
</script>

<style scoped>

.empnos{
  width: 280px;
  margin-top:7px;
  margin-left:7px;
}

.disbolk {
  background-color: gray;
  border: gray;
  /*禁用按钮*/
  pointer-events: none;
}

#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}
</style>
