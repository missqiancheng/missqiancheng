<template>
  <div class="ImportB">
    <div class="LoadMaxBox" id="loadbox">
      <div class="headTitles"><span style="margin-left: 14px;color: rgb(21, 79, 156);">批量導入</span></div>
      <el-upload drag  
                 v-bind:data="fileList" 
                 :auto-upload="false" 
                 :file-list="fileList" 
                 :limit="1"
                 :on-success="onsuc" 
                 :on-error="error" 
                 :before-upload="beforeAvatarUpload"
                 :action="LoadPath"
                 accept=".xls,.xlsx" 
                 method="post" 
                 ref="upload" 
                 class="LoadBox"
                 :headers="Headers"
                 >
          <!--限制文件类型，上传时获取事件-->
          <el-icon id="icon" class="el-icon--upload"><upload-filled /></el-icon>
          <div class="el-upload__text">將檔案拖到此處，或<em>點擊導入</em></div>
          <template #tip>
              <div class="subBox">
                  <el-button class="subBtn" id="subBtn" type="primary" @click="submitUpload">匯入excel到伺服器</el-button>
              </div>
              <div class="el-upload__tip el-upload-list__item-name">
                  <span>只能上傳.xlsx/.xls檔，且不超過5MB</span>
                  <span class="foot_right" @click="download">下載範本</span>
              </div>
          </template>
      </el-upload>
    </div>
  </div>
    
</template>

<script setup>
import { UploadFilled } from '@element-plus/icons-vue'
import {ElMessageBox} from 'element-plus'
import {ref,markRaw} from 'vue'
import { ServerPath } from '../../../Axios';
import { SuccessFilled } from '@element-plus/icons-vue'


//上传路径
const LoadPath=ref(ServerPath+'IncentiveManage/ImportsOrdinance')
//上传控件
const upload=ref()
//文件列表
const fileList=ref()
const Headers={
  'token':`${ localStorage.getItem("token") }`
}

//上传前 check
const beforeAvatarUpload=()=>{
}

//上传成功
const onsuc=(res)=>{
  if(res.Code==='200'){
    ElMessageBox.alert(res.Message+'!','提示',{
      confirmButtonText: '確認',
      type: 'success',
      draggable: true,
      icon:markRaw(SuccessFilled)
    })
  }else{
    ElMessageBox.alert(res.Message+'!','提示',{
      confirmButtonText: '確認',
      type: 'warning',
      draggable: true
    })
  }
}

//上传错误
const error=()=>{
  ElMessageBox.alert('網路錯誤，請檢查！','提示',{
    confirmButtonText: '確認',
    type: 'error',
    draggable: true,
  })
}


//上传文件
const submitUpload=()=>{
  upload.value.submit()
}

//下载模板
const download=()=>{
  location.href="/Incentive/奖惩条例导入模板.xlsx"
}


</script>
<style scoped>
.ImportB{
  height: 800px;
}
</style>

