<template>
  <div id="InputBox">
    <h2 class="table-title">獎懲條例添加</h2>
    <el-form :model="form"  ref="baseForm" label-width="140px" class="from" :rules="rules">

      <div class="EMPBox">
        <div class="BoxTitle">獎懲資訊</div>
        <hr style="border-top:1px #0066CC;" />
        <div class="empinfo">
          <!--第一行-->
          <el-row>
            <el-col :span="12">
              <el-form-item label="獎懲依據：" prop='f_jcitemtype'>
                <el-select v-model="form.f_jcitemtype" placeholder="請選擇">
                  <el-option v-for="item in OrdinanceDocument" :key="item.name" :label="item.name" :value="item.name" />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="獎懲條例：" prop='f_jctl'>
                <el-input v-model="form.f_jctl" />
              </el-form-item>
            </el-col>
          </el-row>
    
          <!--第二行-->
          <el-row>
            <el-col :span="12">
              <el-form-item label="獎懲類別：" prop='f_jctype'>
                <el-select v-model="form.f_jctype" placeholder="請選擇">
                  <el-option v-for="item in f_jctype" :key="item.name" :label="item.name" :value="item.name" />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="獎懲等級：" prop='f_jcdj'>
                <el-select v-model="form.f_jcdj" placeholder="請選擇">
                  <el-option v-for="item in f_jcdj" :key="item.name" :label="item.name" :value="item.name" />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
      
          <!--第三行-->
          <el-row>
            <el-col :span="20">
              <el-form-item label="條例內容：" prop='f_jcitemcontent'>
                <el-input type="textarea" v-model="form.f_jcitemcontent" />
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </div>
        
      <!--提交按钮-->
      <el-form-item label-width="0px">
        <el-button  type="primary" class="subtn"
                    @click="onSubmit(ruleFormRef)" >提交申請</el-button>
      </el-form-item>
    </el-form>
  </div>
  
  
</template>

<script setup>
import { ElNotification,ElMessageBox  } from 'element-plus'
import {h,onBeforeUnmount,reactive,ref,markRaw } from 'vue'
import { ArrowLeft } from '@element-plus/icons-vue'
import { Axios,Token } from '../../../Axios';
import { SuccessFilled } from '@element-plus/icons-vue'

//表单绑定提交数
const form = reactive({
  //奖惩依据
  f_jcitemtype:'',
  //奖惩条例
  f_jctl: '',
  //奖惩类型
  f_jctype: '',
  //奖惩等机
  f_jcdj:'',
  //奖惩内容
  f_jcitemcontent: '',
})

const init=()=>{
  Axios({
    url:'IncentiveManage/OrdinanceInputInfo',
    method:"post",
  }).then(
    res=>{
      const book=res.data.Data.book
      const dj=res.data.Data.dj
      const type=res.data.Data.type
      for(let i=0;i<book.length;i++){
        const obj={
          name:book[i].BOOK_NAME
        }
        OrdinanceDocument[i]=obj
      }
      for(let i=0;i<dj.length;i++){
        const obj={
          name:dj[i].DJ_NAME
        }
        f_jcdj[i]=obj
      }
      for(let i=0;i<type.length;i++){
        const obj={
          name:type[i].TYPE_NAME
        }
        f_jctype[i]=obj
      }
      
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
init()

//奖惩依据数据  《请求》
const OrdinanceDocument=reactive([])

//奖惩类别数据
const f_jctype=reactive([])

//奖惩等级
const f_jcdj=reactive([])

//表单验证规则
const rules=reactive({
  f_jcitemtype:[{
    required: true, message: '獎懲依據不能為空', trigger: 'change'
  }],
  f_jctl:[{
    required: true, message: '獎懲條例不能為空', trigger: 'blur'
  }],
  f_jctype:[{
    required: true, message: '獎懲類型不能為空', trigger: 'change'
  }],
  f_jcdj:[{
    required: true, message: '獎懲等級不能為空', trigger: 'change'
  }],
  f_jcitemcontent:[{
    required: true, message: '獎懲內容不能為空', trigger: 'blur'
  }],
})


//禁止选择当前时间之前的日期
const disabledDate = (time) => {
  return time.getTime() > Date.now()
}


//获取表单元素
const baseForm=ref(null)

//提交申请  《请求》
const onSubmit=()=>{
  baseForm.value.validate((valid) => {
    if (valid) {
      submitdata()
    } else {
      console.log("未通过");
    }
  })
}
//提交请求
const submitdata=()=>{
  Axios({
    url:'IncentiveManage/AddOrdinance',
    method:"post",
    params:{
      f_jcitemtype:form.f_jcitemtype,
      f_jctl:form.f_jctl,
      f_jcitemcontent:form.f_jcitemcontent,
      f_jcdj:form.f_jcdj,
      f_jctype:form.f_jctype,
    }
  }).then(
    res=>{
      if(res.data.Code==='200'){
        ElMessageBox.alert(res.data.Message+'!','提示',{
          confirmButtonText: '確認',
          type: 'success',
          draggable: true,
          icon:markRaw(SuccessFilled)
        })
      }else{
        ElMessageBox.alert(res.data.Message+'!','提示',{
          confirmButtonText: '確認',
          type: 'warning',
          draggable: true
        })
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
</script>

<style scoped>

.el-input{
  width:58%;
  /* min-width: ; */
}

/*表单整体样式 */
.from{
  width: 97%;
  margin:auto;
  margin-top: 35px;
}
.el-textarea{
  width: 89%;
}

/*员工信息边框 */
.empinfo{
  width: 90%;
  margin: auto;
  padding-top:20px;
}


/*边框label样式 */
.BoxTitle{
  /*边框label移动 */
  width: 80px;
  height:40px;
  font-size:20px;
  padding-left: 20px;
  padding-top: 10px;
}

/*提交按钮样式 */
.subtn{
  margin:auto;
  width:33.3%;
  height:50px;
  margin-top: 15px;
}

.EMPBox{
  background: white;
  width:100%;
  height: 260px;
  margin-bottom: 20px;
}

</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}
</style>
