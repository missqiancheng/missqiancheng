<template>
    <el-descriptions
    class="margin-top"
    title="基本資訊"
    :column="3"
    size="large"
    border
  >
    <template #extra>
      <el-button type="primary" @click="dialogTableVisible=true">修改</el-button>
    </template>
    <el-descriptions-item>
      <template #label>
        <div class="cell-item">
          <el-icon style="8px">
            <user />
          </el-icon>
          工号
        </div>
      </template>
      {{from.emp_no}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template #label>
        <div class="cell-item">
          <el-icon style="8px">
            <iphone />
          </el-icon>
          姓名
        </div>
      </template>
      {{from.name}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template #label>
        <div class="cell-item">
          <el-icon style="8px">
            <location />
          </el-icon>
          類型
        </div>
      </template>
      {{from.types}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template #label>
        <div class="cell-item">
          <el-icon style="8px">
            <tickets />
          </el-icon>
          廠區
        </div>
      </template>
      {{plants[from.plant]}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template #label>
        <div class="cell-item">
          <el-icon style="8px">
            <office-building />
          </el-icon>
          郵箱
        </div>
      </template>
      {{from.email}}
    </el-descriptions-item>
  </el-descriptions>

  <el-dialog v-model="dialogTableVisible" title="填寫資訊" width="30%" draggable>
    <template #default>
        <el-form>
          <el-form-item label="工号：">
            <el-input v-model="emp_no" />
          </el-form-item>
        </el-form>
      </template>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="UpdateRes()">修改</el-button>
        </div>
      </template>
  </el-dialog>

</template>

<script setup>
import {
  Iphone,
  Location,
  OfficeBuilding,
  Tickets,
  User,
} from '@element-plus/icons-vue'
import { Axios } from '/src/Axios'
import { reactive,ref } from 'vue';
import { ElMessageBox  } from 'element-plus'

//村骗乡，乡骗镇，一骗骗到国务院

const from=reactive({
    emp_no:'',
    name:'',
    plant:'',
    email:'',
    types:''
})

const plants={
    '001':'龍華',
    '002':'杭州',
    '005':'重慶',
    '003':'南寧',
}

const RequestPaper=()=>{
    Axios({
        url:'IncentiveManage/GetPaperMange',
        method:'post',
    }).then(
        res=>{
            const date=res.data.Data
            from.emp_no=date[0].F_EMPNO
            from.name=date[0].F_NAME
            from.plant=date[0].F_PLANTNO
            from.email=date[0].F_MAIL
            from.types=date[0].F_WINDOWNAME
        }
    ).catch(
        err=>{
            console.log(err)
        }
    )
}
RequestPaper()



const dialogTableVisible=ref(false)
const emp_no=ref('')


const UpdateRes=()=>{
    Axios({
        url:'IncentiveManage/SettingPaper',
        method:'post',
        params:{
            empno:emp_no.value,
            plant:from.plant
        }
    }).then(
        res=>{
            const data=res.data
            if(data.Code=='500'){
                ElMessageBox.alert(data.Message+"!",'提示',
                {confirmButtonText: '確認',type: 'warning',draggable: true})
            }else{
                ElMessageBox.alert("修改成功!",'提示',
                {confirmButtonText: '確認',type: 'warning',draggable: true})
                RequestPaper()
            }
            dialogTableVisible.value=false
        }
    ).catch(
        err=>{
            console.log(err)
        }
    )
}
</script>

<style scoped>
.el-descriptions {
  margin-top: 20px;
}
</style>