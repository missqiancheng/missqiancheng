<template>
  <h2 class="table-title">參考文件設定</h2>
  <el-table :data="tableData" id="big-width" >
    <el-table-column label="序號" type="index" min-width="8%" />
    <el-table-column label="文件名稱" prop="NAME" min-width="20%"/>
    <el-table-column label="文件版本" prop="F_TYPE" min-width="18%" />
    <el-table-column label="生效日期" prop="F_EFFECTDATE" min-width="10%" />
    <el-table-column label="編輯人" prop="LOADEMP" min-width="8%" />
    <el-table-column label="編輯時間" prop="LOADTIME" min-width="8%" />
    <el-table-column label="原件" prop="FILE_NAME" min-width="7%">
      <template #default="scope">
        <el-icon class="iconMidde" :size="IconSize" :color="IconColor" 
                   @click="Downloadf(scope.row)"><Download /></el-icon>
      </template>
    </el-table-column>
    <el-table-column min-width="7%">
      <template #header>
        <el-button size="small" @click="handleAdd()">添加</el-button>
      </template>
      <template #default="scope">
        <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">刪除</el-button>
      </template>
    </el-table-column>
  </el-table>

  <!--弹出框-->
  <el-dialog v-model="dialogVisible" title="标题" width="400px" draggable>
    <el-form :model="form" label-width="100px" :rules="rules" ref="forms">
      <el-form-item label="文件名稱：" prop="name">
        <el-input v-model="form.name" autocomplete="off" />
      </el-form-item>
      <el-form-item label="文件版本：" prop="f_type">
        <el-input v-model="form.f_type" autocomplete="off" />
      </el-form-item>
      <el-form-item label="生效日期：" prop="effectdate">
        <el-config-provider :locale="zhCn">
          <el-date-picker placeholder="請選擇" v-model="form.effectdate" type="date"/>
        </el-config-provider>
      </el-form-item>
      <el-form-item label="原件：">
        <UpLoad ref="load"></UpLoad>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="submit()">提交</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import {  ref,reactive,shallowRef,h,markRaw } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import UpLoad from '/src/pages/UpLoad.vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import { Axios,Token,DownLoad,Headers } from '../../../Axios';
import { SuccessFilled } from '@element-plus/icons-vue'
import { Download } from '@element-plus/icons-vue';

//显示dialog
const dialogVisible=ref(false)
//上传控件
const load=ref()
//表单
const forms=ref()

//全部数据
let tableData=reactive([])

//图标样式
const IconSize=ref(25)
const IconColor=ref('#409EFC')

//更新表格数据
const updateData=()=>{
  Axios({
    url:'IncentiveManage/AllDocumentData',
    method:"post",
  }).then(
    res=>{
      const data=res.data.Data
      for(let i=0;i<data.length;i++){
        tableData[i]=data[i]
      }
    }
  ).catch(
    err=>{
      console.log(err.data)
    }
  )
}

updateData()

//表单数据
const form = reactive({
  name: '',
  f_type:'',
  effectdate:'',
  file:''
})

//表单验证规则
const rules=reactive({
  name:[{
    required: true, message: '文件名稱不能為空', trigger: 'blur'
  }],
  f_type:[{
    required: true, message: '文件版本不能為空', trigger: 'blur'
  }],
  effectdate:[{
    required: true, message: '生效日期不能為空', trigger: 'blur'
  }],
})

//删除  《请求》
const handleDelete = (index, row) => {
  ElMessageBox.confirm('確定要刪除目前參考檔案嗎','提示',{
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      type: 'warning',
    }).then(() => {
      DeleteData(index,row)
  }).catch(() => {})
}
const DeleteData=(index,row)=>{
  Axios({
    url:'IncentiveManage/DeleteDocument',
    method:"post",
    params:{
      index:row.ID,
      Path:row.FILE_NAME==undefined?'':row.FILE_NAME,
    }
  }).then(
    res=>{
      tableData.splice(index,1)
      ElMessage({
        type: 'success',
        message: '刪除成功',
      })
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//下载  《路径》
const Downloadf=(row)=>{
  DownLoad(row.FILE_NAME,row.NAME)
}

//添加参考文件
const handleAdd=()=>{
  dialogVisible.value=true
}

//获取文件
const getfile=()=>{
  load.value.submitUpload()
  form.file=load.value.getfile()
}

//提交添加表单
const submit=()=>{
  forms.value.validate(async(valid)=>{
    if(valid){
      await getfile()
      if(form.file==''){
        ElMessageBox.alert('請上傳依據檔！','提示',{
          confirmButtonText: '確認',
          type: 'warning',
          draggable: true,
        })
      }else{
        RequestSubmit()
      }
    }else{
      console.log('未通过')
    }
  })
}
const RequestSubmit=()=>{
  let fromdata=new FormData()
  fromdata.append("file",form.file)
  Axios({
    url:'/IncentiveManage/AddDocument',
    method:'post',
    headers:Headers,
    params:{
      filename:form.name,
      filetype:form.f_type,
      effectdate:form.effectdate
    },
    data: fromdata,
  }).then(
    res=>{
      dialogVisible.value=false
      ElMessageBox.alert('上傳成功！','提示',{
        confirmButtonText: '確認',
        type: 'success',
        draggable: true,
        icon:markRaw(SuccessFilled)
      })
      updateData()
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
</script>

<style scoped>
/*图标居中*/
.iconMidde{
  vertical-align: middle;
  margin-right: 10px;
  margin-left: 10px;
}
.iconMidde:hover{
  color: orange;
}
</style>