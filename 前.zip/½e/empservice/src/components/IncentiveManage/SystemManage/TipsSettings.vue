<template>
  <h2 class="table-title">温馨提示设定</h2>
  <el-table :data="tableData" id="big-width" :border="true">
    <el-table-column label="序號" type="index" min-width="20%" />
    <el-table-column label="內容" prop="content" min-width="60%"/>
    <el-table-column min-width="20%">
      <template #header>
        <el-button size="small" type="primary" @click="SavaData()">保存</el-button>
        <el-button size="small" type="primary" @click="handleEdit(-1, '')">添加</el-button>
      </template>
      <template #default="scope">
        <el-button size="small" @click="handleEdit(scope.$index, scope.row)">修改</el-button>
        <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">刪除</el-button>
      </template>
    </el-table-column>
  </el-table>

  <!--弹出框-->
  <el-dialog v-model="dialogVisible" title="标题" width="400px" draggable>
    <el-form :model="form">
      <el-form-item label="內容：" :label-width="formLabelWidth">
        <el-input v-model="form.content" type="textarea" autocomplete="off" />
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="Edit()">提交</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import {  ref,reactive,onBeforeUnmount,markRaw } from 'vue'
import { ElNotification } from 'element-plus'
import {Axios,Token} from '/src/Axios'
import { ElMessage, ElMessageBox } from 'element-plus'
import { SuccessFilled } from '@element-plus/icons-vue'

//关闭提示  生命周期必须放在tips前面
onBeforeUnmount(()=>{
  Tips.close()
})

//dialog是否显示
const dialogVisible=ref(false)

let tableData = reactive([{content:''}])

Axios({
  url:'IncentiveManage/GetTips',
  method:"post",
}).then(
  res=>{
    const data=res.data.Data
    let i=1
    while(data[i]!=undefined){
      const obj={
        content:data[i]
      }
      tableData[i-1]=obj
      i++
    }
    Tips=UpdateTips()
  }
).catch(
  err=>{
    console.log(err)
  }
)

const form = reactive({
  index:'',
  content: '',
})

//更新温馨提示数据
const UpdateTips=()=>{
  //温馨提示内容
  const TipsContent=()=>{
    let content=""
    for(let i=0;i<tableData.length;i++){
      let index=i+1
      content=content+"<i style='color: red'>"+index+"."+tableData[i].content+"</i>"+'<br>'
    }
    return content
  }
  
  //温馨提示内容赋值
  let content=TipsContent()
  //温馨提示展示
  const Tips=ElNotification({
    title: '温馨提示',
    dangerouslyUseHTMLString: true,
    message: content,
    duration:0,
    offset:45
  })
  return Tips
}

let Tips;

//修改
const handleEdit = (index, row) => {
  form.content=row.content
  form.index=index
  dialogVisible.value=true
}

//修改提交
const Edit=()=>{
  if(form.index===-1){
    tableData.push({content:form.content})
  }else{
    tableData[form.index].content=form.content
  }
  Tips.close()
  Tips=UpdateTips()
  dialogVisible.value=false
}

//删除
const handleDelete = (index, row) => {
    tableData.splice(index,1)
    Tips.close()
    Tips=UpdateTips()
}

//保存
const SavaData=()=>{
  Axios({
    url:'IncentiveManage/SaveTips',
    method:'post',
    params:{Tips:ConversionData()}
  }).then(
    res=>{
      ElMessageBox.alert('保存成功！','提示',{
        confirmButtonText: '確認',
        type: 'success',
        draggable: true,
        icon:markRaw(SuccessFilled)
      })
      console.log(res.data)
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//合成要保存的字符串
const ConversionData=()=>{
  let strData=''
  for(let i=0;i<tableData.length;i++){
    strData+=(i+1)+'.'+tableData[i].content
  }
  console.log(strData)
  return strData
}
</script>

<style scoped>

</style>