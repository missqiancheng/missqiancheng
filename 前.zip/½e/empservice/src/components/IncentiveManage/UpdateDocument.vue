<template>
  <h2 class="table-title">員工獎懲申請</h2>
  <el-form :model="form"  ref="baseForm" width="100%" :rules="rules"
           label-width="140px" class="from">
    <div class="EMPBox">
      <div class="BoxTitle"><b>員工資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="empinfo">
        <!--第一行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="員工工號：" prop='emp_no'>
              <el-input v-model="form.emp_no" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="員工姓名：">
              <el-input v-model="form.name" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="目前工作擔當：" prop='duty'>
              <el-input v-model="form.duty" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第二行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="資位：">
              <el-input v-model="forms.f_grand" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="入職日期：">
              <el-input v-model="forms.f_infactorydate" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="部門名稱：">
              <el-input  v-model="forms.f_departname" readonly />
            </el-form-item>
          </el-col>
        </el-row>
    
        <!--第三行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="提報人：" prop='tbr'>
              <el-input v-model="form.tbr" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="提報人聯系方式：" prop='tbr_tel'>
              <el-input v-model="form.tbr_tel" />
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </div>

    <div class="RPMBox">
      <div class="BoxTitle"><b>獎懲資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="RPMinfo">
        <!--第四行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="獎懲發生日期：" prop="f_occurdate">
              <el-config-provider :locale="zhCn">
                <el-date-picker placeholder="請選擇" v-model="form.f_occurdate" 
                                :disabled-date="disabledDate" type="date" 
                                :shortcuts="shortcuts"/>
              </el-config-provider>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="獎懲依據：" prop="jc_yj">
              <el-select v-model="form.jc_yj" placeholder="請選擇">
                <el-option v-for="item in literature" :key="item.name" :label="item.name" :value="item.name" />
              </el-select><!---->
            </el-form-item>
          </el-col>
        </el-row>
        
        <!--第五行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="獎懲條例：" prop="jc_tl">
              <el-input v-model="form.jc_tl" readonly style="width:218px;" @click="SelectArticle" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第六行-->
        <el-row>
          <el-col :span="17">
            <el-form-item label="條例內容：">
              <el-input v-model="form.f_jcitemcontent" rows="4" readonly  type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第七行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="處理類別：">
              <label>{{form.jc_dj}}</label>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="獎懲類別：">
              <label>{{form.jc_type}}</label>
            </el-form-item>
          </el-col>
        </el-row>
        
        <!--第七行(隐藏)-->
        <el-row v-if="form.jc_dj==='開除'">
          <el-col :span="8">
            <el-form-item label="開除類型：">
              <label>{{form.f_delistype}}</label>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="曠工日期：" v-if="form.f_delistype==='曠工開除'">
              <label>{{form.absenteeismdate}}</label>
            </el-form-item>
          </el-col>
        </el-row>

        <!--第八行-->
        <el-row>
          <el-col :span="17">
            <el-form-item label="獎懲原由：" prop="remark">
              <el-input v-model="form.remark" rows="4" type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
        
        <!--第九行-->
        <el-row>
          <el-col :span="24">
            <el-form-item label="佐證材料：">
              <UpLoad ref="loadfs"></UpLoad>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="是否變更處理類別：">
              <el-switch
                v-model="form.f_changetype"
                class="mt-2"
                style="margin-left: 24px"
                inline-prompt
                :active-icon="Check"
                :inactive-icon="Close"
                :before-change="BeForeAlter"
              />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏一行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="8">
            <el-form-item label="變更等級：" prop="f_jcdj_new">
              <el-select v-model="form.f_jcdj_new" placeholder="請選擇">
                <el-option v-for="item in ChangeHandling" :key="item" :label="item" :value="item" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏二行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="17">
            <el-form-item label="變更類別原由：" prop="f_changereason">
              <el-input v-model="form.f_changereason" rows="4" type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏三行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="8">
            <el-form-item label="證明材料：">
              <UpLoad ref="loadhidden"></UpLoad>
            </el-form-item>
          </el-col>
        </el-row>
        
      </div>
    </div>
  </el-form>

  
  <!--奖惩条例查询弹出框-->
  <el-dialog v-model="dialogTableVisible" 
             title="奖惩条例查询" 
             :before-close="handleClose"
             width="80%" 
             :close-icon="CloseBold"
             draggable
  >
    <div v-loading="LoadingOrdinace">
      <el-input v-model="SelectValue" size="large" placeholder="請輸入關鍵詞搜索" :suffix-icon="Search">  
      </el-input>
      <el-table :data="ArticleSelect"
                height="500px" 
                @cell-click="handlesubmit">
        <el-table-column label="操作"  width="70">
          <template #default="scope">
            <el-button type="primary" :icon="Check" @click="handlesubmit(scope.row)" />
          </template>
        </el-table-column>
        <el-table-column type="index" label="序号" width="60" />
        <el-table-column property="f_jcitemtype" label="獎懲依據" width="200" />
        <el-table-column property="f_jctl" label="獎懲條例"  width="100" />
        <el-table-column property="f_jcitmecontent" label="獎懲條例內容"  width="400" />
        <el-table-column property="f_jcdj" label="處理類別" width="100" />
        <el-table-column property="f_jctype" label="獎懲類別" width="120" />
      </el-table><!---->
    </div>
  </el-dialog>

</template>

<script setup>
import { ref,reactive,computed } from 'vue'
import { Axios,DownLoad,Headers } from '/src/Axios'
import { Check, Close,CloseBold,Search,EditPen,DataLine  } from '@element-plus/icons-vue'
import UpLoad from '/src/pages/UpLoad.vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import { ElMessage } from 'element-plus'

// #region 基本数据
//表单绑定提交数据
const form = reactive({
  //@基本数据@
  //工号
  emp_no:'',
  //姓名
  name: '',
  //工作担当
  duty: '',
  //提报人
  tbr:localStorage.getItem('empno'),
  //提报人联系方式
  tbr_tel: '',
  
  //@奖惩数据@
  //1.奖惩发生日期
  f_occurdate: '',
  //2.奖惩依据单号
  f_jcitemno:'',
  //2.奖惩依据
  jc_yj:'',
  //3.奖惩条例
  jc_tl: '',
  //4.条款内容
  f_jcitemcontent:'',
  //5.处理类别
  jc_dj:'',//開除
  //6.奖惩类别
  jc_type:'',
  //7.奖惩原因
  remark:'',
  //8.相关自述材料
  file_name:'',
  //9.是否变更处理类别
  f_changetype: false,
  //隐藏1.变更类别等级
  f_jcdj_new:'',
  //隐藏2.变更类别理由
  f_changereason:'',
  //隐藏3.证明材料
  hr_file_name:'',
  //特殊提交：旷工日期
  absenteeismdate:'',
  //特殊提交：開除类型
  f_delistype:'',
  
  //单号
  apply_no:''
})
//1.The so-called desirelessness is that you have already got what you want
//2.Don't use your thinking to verify right or wrong, 
//use practice to verify it,and the world give you feedback.
//
//表单显示非提交数据
const forms=reactive({
  //职位
  f_grand: '',
  //入职日期
  f_infactorydate: '',
  //部门名称
  f_departname:''
})

//时间选择器快捷选择数据
const shortcuts = [
  {
    text: '當天',
    value: new Date(),
  },
  {
    text: '昨天',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24)
      return date
    },
  },
  {
    text: '一周前',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
      return date
    },
  },
]

//禁止选择当前时间之前的日期
const disabledDate = (time) => {
  return time.getTime() > Date.now()
}

const dialogTableVisible=ref()

//修改材料
const loadhidden=ref()

//自述材料
const loadfs=ref()

//表单验证规则
const rules=reactive({

  emp_no:[{
    required: true, message: '工號不能為空', trigger: 'blur'
  }],
  
  tbr_tel:[{  
    required: true, message: '提報人電話不能為空', trigger: 'blur'
  }],
  
  f_occurdate:[{
    required: true, message: '獎懲發生日期不能為空', trigger: 'change'
  }],
  
  jc_yj:[{
    required: true, message: '獎懲依據不能為空', trigger: 'change'
  }],
  
  jc_tl:[{
    required: true, message: '獎懲條例不能為空', trigger: 'change'
  }],
  
  remark:[{
    required: true, message: '獎懲原由不能為空', trigger: 'blur'
  }],
  
  f_jcdj_new:[{
    required: true, message: '變更等級不能為空', trigger: 'change'
  }],
  
  f_changereason:[{
    required: true, message: '變更類別原由不能為空', trigger: 'blur'
  }], 

})

// #endregion


// #region 奖惩条例
//奖惩依据选择数据  《请求》

const literature=reactive([])
const RequestJC_tl=()=>{
  Axios({
    url:'IncentiveManage/IncentiveDocument',
    method:'post',
  }).then(
    res=>{
      const data=res.data.Data
      for(let i=0;i<data.length;i++){
        literature[i]={
          name:data[i].NAME
        }
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequestJC_tl()

//奖惩条例数据
const Article = reactive([])
//奖惩条件
let SelectValue=ref()
//搜索后的select
const ArticleSelect=computed(()=>{
  return Article.filter((data)=>!SelectValue.value
  ||data.f_jcitemtype.includes(SelectValue.value)
  ||data.f_jctl.includes(SelectValue.value)
  ||data.f_jcitmecontent.includes(SelectValue.value)
  ||data.f_jcdj.includes(SelectValue.value)
  ||data.f_jctype.includes(SelectValue.value))
})

//加载中
const LoadingOrdinace=ref(true)
//关闭弹窗
const handleClose=(close)=>{
  LoadingOrdinace.value=true
  close()
}

//查询奖惩条例  《请求》
const SelectArticle=async()=>{
  if(form.jc_yj===''){
    ElMessageBox.alert('請先選擇獎懲依據！','提示',{
        confirmButtonText: '確認',
        type: 'warning',
        draggable: true,
      })
  }else{
    await new Promise((reslove,reject)=>{
      dialogTableVisible.value=true
      reslove()
    })
    RequestOrdinace()
  }
}
const RequestOrdinace=()=>{
  Axios({
    url:'IncentiveManage/GetOrdinace',
    method:'post',
    params:{
      jc_yj:form.jc_yj
    }
  }).then(
    res=>{
      Article.length=0
      LoadingOrdinace.value=false
      const data=res.data.Data
      for(let i=0;i<data.length;i++){
        Article[i]={
          f_jcitemno:data[i].F_JCITEMNO,
          f_jcitemtype: data[i].F_JCITEMTYPE,
          f_jctl: data[i].F_JCTL,
          f_jcitmecontent: data[i].F_JCITEMCONTENT,
          f_jcdj: data[i].F_JCDJ,
          f_jctype: data[i].F_JCTYPE,
        }
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

//验证开关能否打开事件
const BeForeAlter=()=>{
  if(form.jc_tl===''){
    ElMessageBox.alert('請先選擇變更前獎懲條例！','提示',{
      confirmButtonText: '確認',
      type: 'warning',
      draggable: true,
    })
    return false
  }else{
    return true
  }
}

//变更等级多选框数据
let ChangeHandling=reactive([])
//选择奖惩条例  《请求》
const handlesubmit=(row)=>{
  form.jc_type=''
  form.f_delistype=''
  form.f_jcitemno=row.f_jcitemno
  form.jc_tl=row.f_jctl
  form.f_jcitemcontent=row.f_jcitmecontent
  form.jc_dj=row.f_jcdj
  form.jc_type=row.f_jctype
  NewDjUpdate(form.jc_dj,form.jc_type)
  dialogTableVisible.value=false
  //
}

//变更奖惩等级
const NewDjUpdate=(jc_dj,jc_type)=>{
  if(jc_dj==='開除'){
    if(jc_type==='違反工作紀律(曠工開除)'){
      form.f_delistype='曠工開除'
      //请求旷工日期
      RequestAbsent()
    }else{
      form.f_delistype='違紀開除'
    }
  }
  if(jc_dj==='嘉獎一次'||jc_dj==='小功一次'||jc_dj==='大功一次'){
    ChangeHandling=reactive(['嘉獎一次','小功一次','大功一次'])
    ChangeHandling.splice(ChangeHandling.indexOf(jc_dj),1)
  }else{
    ChangeHandling=reactive(['警告一次','小過一次','大過一次','警告二次','小過二次','大過二次'])
    ChangeHandling.splice(ChangeHandling.indexOf(jc_dj),1)
  }
}


//请求旷工日期
const RequestAbsent=()=>{
  Axios({
    url:'IncentiveManage/GetAbsenteeism',
    method:'post',
    params:{
      f_empno:form.emp_no
    }
  }).then(
    res=>{
      const data=res.data
      if(data.Code==="500"){
        ElMessageBox.alert('该工号不能提报旷工開除！','提示',{
          confirmButtonText: '確認',
          type: 'warning',
          draggable: true,
        })
      }else{
        form.absenteeismdate=data.Data
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// computer software techonogy
// #endregion 


// #region 请求数据
//单据数据
const RequestHostory=(apply_nos,empno,year)=>{
  Axios({
    url:'IncentiveManage/GetYearAndHistory',
    method:'post',
    params:{
      empno:empno,
      applyno:apply_nos,
      year:year
    }
  }).then(
    res=>{
      const data=res.data.Data
      //单号
      form.apply_no=apply_nos
      //基本信息
      const DocumentInfo=data['DocumentInfo'][0]
      form.emp_no=DocumentInfo.EMP_NO
      form.name=DocumentInfo.NAME
      form.duty=DocumentInfo.DUTY
      forms.f_grand=DocumentInfo.F_GRAND
      forms.f_infactorydate=DocumentInfo.F_INFACTORYDATE
      forms.f_departname=DocumentInfo.F_DEPARTNAME
      form.tbr_tel=DocumentInfo.TBR_TEL
      form.tbr=DocumentInfo.TBR
      //奖惩信息
      form.f_occurdate=DocumentInfo.F_OCCURDATE
      form.jc_yj=DocumentInfo.JC_YJ
      form.jc_tl=DocumentInfo.JC_TL
      form.f_jcitemcontent=DocumentInfo.F_JCITEMCONTENT
      form.jc_dj=DocumentInfo.JC_DJ
      form.jc_type=DocumentInfo.JC_TYPE
      form.remark=DocumentInfo.REMARK
      form.file_name=DocumentInfo.FILE_NAME
      form.f_delistype=DocumentInfo.F_DELISTYPE
      form.absenteeismdate=DocumentInfo.F_ABSENTDATE
      //变更信息
      form.f_changetype=(DocumentInfo.F_CHANGETYPE=='是')
      form.f_changereason=DocumentInfo.F_CHANGEREASON
      form.f_jcdj_new=DocumentInfo.F_JCDJ_NEW
      form.hr_file_name=DocumentInfo.HR_FILE_NAME
      //修改数据
      NewDjUpdate(form.jc_dj,form.jc_type)
    }//
  ).catch(
    err=>{
      console.log(err)
    }
  )
}

// #region 提交
//表单
const baseForm=ref()
const CheckSubmit=async(Callback)=>{
  await new Promise((resolve,reject)=>{
    loadfs.value.submitUpload()
    form.file_name=loadfs.value.getfile()
    if(form.f_changetype){
      loadhidden.value.submitUpload()
      form.hr_file_name=loadhidden.value.getfile()
    }
    resolve()
  })
  
  baseForm.value.validate((valid) => {
    if (valid) {
      RequestSubmit(Callback)
    }
  })
  
}
//提交修改数据
const RequestSubmit=(Callback)=>{
  console.log(form.f_jcdj_new,form.f_changereason,form.absenteeismdate,form.f_delistype)
  let fromdata=new FormData()
  if(form.file_name!='') fromdata.append('file_name',form.file_name)
  if(form.hr_file_name!='') fromdata.append('hr_file_name',form.hr_file_name)
  Axios({
    url:'IncentiveManage/UpdateIncentive',
    method:'post',
    params:{
      apply_no:form.apply_no,
      duty:form.duty,
      tbr_tel:form.tbr_tel,
      f_occurdate:form.f_occurdate,
      f_jcitemno:form.f_jcitemno,
      jc_yj:form.jc_yj,
      jc_tl:form.jc_tl,
      f_jcitemcontent:form.f_jcitemcontent,
      jc_dj:form.jc_dj,
      jc_type:form.jc_type,
      remark:form.remark,
      f_changetype:form.f_changetype,
      f_jcdj_new:form.f_jcdj_new,
      f_changereason:form.f_changereason,
      f_absentdate:form.absenteeismdate,
      f_delistype:form.f_delistype,
    },
    headers:Headers,
    data:fromdata
  }).then(
    res=>{
      const data=res.data
      if(data.Code==='200'){
        ElMessageBox.alert("申請成功!",'提示',
        {confirmButtonText: '確認',
        type: 'suucess',draggable: true})

      }
      Callback()
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion
// #endregion



defineExpose({RequestHostory,CheckSubmit})

</script>

<style scoped>

*{
  user-select: auto;
}

/*申请单标题*/
.title{
  text-align: center;
  font-size: 30px;
}

.el-input{
  width:auto;
}

/*表单整体样式 */
.from{
  width: 98%;
  margin:auto;
  margin-top: 35px;
}
.el-textarea{
  width: 89%;
}

/*员工信息边框 */
.empinfo{
  border:0px;
  padding-top:20px;
  width:90%;
  margin:auto;
}

/*RPM边框 */
.RPMinfo{
  margin:auto;
  width:90%;
  padding-top:20px;
}
.History{
  margin:auto;

}
/*边框label样式 */
.BoxTitle{
  /*边框label移动 */
  width: 80px;
  height:40px;
  font-size:20px;
  padding-left: 20px;
  padding-top: 10px;
}


/*模板框 */
.EMPBox{
  background: white;
  width:100%;
  height: 230px;
  margin-bottom: 20px;
}
.RPMBox{
  background: white;
  width:100%;
  height: 100%;
  margin-bottom: 20px;
}
</style>