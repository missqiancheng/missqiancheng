<template>
    <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      :collapse="ASideType"
    >
        <el-sub-menu index="1">
            <template #title>
                <el-icon><Collection /></el-icon>
                <span>報表管理</span>
            </template>
                <el-menu-item index="1-1" @click="DispatchWorker()">
                    <el-icon><Suitcase /></el-icon>
                    <span>派遣工</span>
                </el-menu-item>
                <el-menu-item index="1-2">
                    <el-icon><DocumentDelete /></el-icon>
                    <span>三期異常</span>
                </el-menu-item>
                <el-menu-item index="1-3">
                    <el-icon><Notebook /></el-icon>
                    <span>實習生管理</span>
                </el-menu-item>
                <el-menu-item index="1-4">
                    <el-icon><DataLine /></el-icon>
                    <span>離職率管理</span>
                </el-menu-item>
                <el-menu-item index="1-5">
                    <el-icon><Timer /></el-icon>
                    <span>超六休一</span></el-menu-item>
                <el-menu-item index="1-6">
                    <el-icon><DataAnalysis /></el-icon>
                    <span>月加班統計</span>
                </el-menu-item>
        </el-sub-menu>
        <el-sub-menu index="2">
            <template #title>
                <el-icon><Document /></el-icon>
                <span>缺失公告与持续改善</span>
            </template>
                <el-menu-item index="2-1">
                    <el-icon><DocumentAdd /></el-icon>
                    <span>單據生成</span>
                </el-menu-item>
                <el-menu-item index="2-2">
                    <el-icon><Search /></el-icon>
                    <span>單據查詢</span>
                </el-menu-item>
                <el-menu-item index="2-3">
                    <el-icon><Notification /></el-icon>
                    <span>超六休一異常簽核</span>
                </el-menu-item>
                <el-menu-item index="2-4">
                    <el-icon><Notification /></el-icon>
                    <span>三期異常簽核</span>
                </el-menu-item>
                <el-menu-item index="2-5">
                    <el-icon><Notification /></el-icon>
                    <span>實習生異常簽核</span>
                </el-menu-item>
        </el-sub-menu>
      
    </el-menu>
</template>
<script setup>
import { Document,Notebook,DataAnalysis,Suitcase,Timer,DataLine,DocumentDelete,Collection,DocumentAdd,Search,Notification
} from '@element-plus/icons-vue';
import {ref,inject} from 'vue'

const ASideType=inject('ASideType')

const emit=defineEmits(['addTabs'])

//派遣工
const DispatchWorker=()=>{
    const NavigationPath="DispatchWorker"
    emit("addTabs","派遣工",NavigationPath)
}
</script>

<style scoped>
.el-menu-item.is-active{
  background-color: #daf2fe !important;
}
*{
  user-select: none;
}
</style>