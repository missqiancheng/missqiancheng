<template>
    第一：：：<UpLoad ref="upONe"></UpLoad>
    <el-button @click="submits">提交</el-button>
    <el-button @click="clea">清空</el-button>
</template>

<script setup>
import { reactive,ref } from "vue";
import UpLoad from '/src/pages/UpLoad.vue'
import axios from "axios";

const from=reactive({
    file_name:'',
    files_names:'',
})

const upONe=ref()

//获取文件


const getfile=()=>{
  upONe.value.submitUpload()
  from.file_name=upONe.value.getfile()
}

const clea=()=>{
    axios({
        url:'http://ics.efoxconn.com/cnsbg.pac'
    }).then(
        res=>{
            console.log(res)
        }
    ).catch(
        err=>{
            console.log(err)
        }
    )
}

const submits=async()=>{

}



 

</script>   