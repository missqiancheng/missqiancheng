<template>
    <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      :collapse="ASideType"
    >
      <el-menu-item index="1">
        <el-icon><EditPen /></el-icon>
        <span>管理員編輯</span>
      </el-menu-item>
      <el-menu-item index="2">
        <el-icon><DocumentAdd /></el-icon>
        <span>個人補貼申請</span>
      </el-menu-item>
      <el-menu-item index="3">
        <el-icon><Files /></el-icon>
        <span>個人補貼數據維護</span>
      </el-menu-item>
      <el-menu-item index="4">
        <el-icon><Printer /></el-icon>
        <span>個人補貼數據導出</span>
      </el-menu-item>
      <el-menu-item index="5">
        <el-icon><DocumentAdd /></el-icon>
        <span>企業補貼申請</span>
      </el-menu-item>
      <el-menu-item index="6">
        <el-icon><Files /></el-icon>
        <span>企業補貼數據維護</span>
      </el-menu-item>
      <el-menu-item index="7">
        <el-icon><Printer /></el-icon>
        <span>企業補貼數據導出</span>
      </el-menu-item>
      <el-menu-item index="8">
        <el-icon><DataAnalysis /></el-icon>
        <span>補貼數據可視化</span>
      </el-menu-item>
    </el-menu>
</template>
<script setup>
import { DocumentAdd,MessageBox,Printer,DataAnalysis,Files,EditPen
} from '@element-plus/icons-vue';
import {ref,inject} from 'vue'

const ASideType=inject('ASideType')
</script>

<style scoped>
.el-menu-item.is-active{
  background-color: #daf2fe !important;
}
*{
  user-select: none;
}
</style>