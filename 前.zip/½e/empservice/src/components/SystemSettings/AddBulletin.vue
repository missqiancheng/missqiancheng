<template>
    <el-form-item label="标题：">
      <el-input v-model="titles" placeholder="标题只能为繁体" />
    </el-form-item>
    <div style="border: 1px solid #ccc;">
      <Toolbar
        style="border-bottom: 1px solid #ccc;"
        :editor="editorRef"
        :defaultConfig="toolbarConfig"
        :mode="mode"
      />
      <Editor
        :style="EditorCss"
        v-model="EditorData"
        :defaultConfig="editorConfig"
        :mode="mode"
        @onCreated="handleCreated"
      />
    </div>
      <el-button @click="CheckRequest()" type="primary" style="width: 50%;margin:auto;">提交公告</el-button>
      <el-button @click="Reset()" style="width: 50%; margin:auto;">重置</el-button>
</template>

<script setup>
import { Axios } from '/src/Axios';
import { reactive, ref, watch, shallowRef,onBeforeUnmount  } from 'vue'
import { ElMessage,ElMessageBox,ElLoading  } from 'element-plus'
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import '@wangeditor/editor/dist/css/style.css' // 引入 css

// #region 基本数据
//edit数据
const EditorData=ref('')
//标题
const titles=ref('')
//editer组件
const editorRef=shallowRef()
//富文本框默认内容
const editorConfig = {
    placeholder: '请输入内容...',
    //文件上传地址
    MENU_CONF:{
        uploadImage:{
            server: '/api/upload',
            base64LimitSize: 3000 * 1024 // 3000kb
        }
    },
}

//文本框css
const EditorCss='overflow-y: hidden;height: '+(window.innerHeight-241)+"px;"


//记录editor 实例
const handleCreated = (editor) => {
    editorRef.value = editor // 记录 editor 实例，重要！
}

//工具栏配置
const toolbarConfig = reactive({})

//默认配置
const mode='default'

// 组件销毁时，也及时销毁编辑器
onBeforeUnmount(() => {
    const editor = editorRef.value
    if (editor == null) return
    editor.destroy()
})
// #endregion

// #region 事件验证
//限制验证
const CheckRequest=()=>{
    if(titles.value==''||editorRef==''){
        ElMessageBox.alert('信息不能为空！','提示',{
          type: 'warning',
          draggable: true
        })
    }else{
        RequestBulletin()
    }
}


//提交公告请求
const RequestBulletin=()=>{
    const formData=new FormData()
    const loading = ElLoading.service({
      lock: true,
      text: 'Loading',
      background: 'rgba(0, 0, 0, 0.7)',
    })
    formData.append('Content', encodeURI(SettingMaxWidth(EditorData.value)))
    Axios({
        url:'HomePages/WriteBullerin',
        method:'post',
        params:{
            title:titles.value,
        },
        data:formData
    }).then(
        res=>{
            const data=res.data
            ElMessageBox.alert('提交成功！','提示',{
              type: 'success',
              draggable: true
            })
            loading.close()
            Reset()//重置文本框内容
        }
    ).catch(
        err=>{
            loading.close()
            console.log(err)
        }
    )
}

const SettingMaxWidth=(str)=>{
    // 解析字符串，并查找所有的 style 属性
    let regExp = /(style="[^"]*")/g;
    let matches = str.match(regExp);
    
    if (matches) {
      // 遍历所有的 style 属性字符串
      for (let i = 0; i < matches.length; i++) {
        let styleAttr = matches[i]; // style 属性字符串
    
        // 将字符添加到 style 属性字符串中
        let modifiedStyleAttr = styleAttr.replace(/"$/, 'max-width:100%;"');
    
        // 替换原字符串中的 style 属性
        str = str.replace(styleAttr, modifiedStyleAttr);
      }
    }
    return str
}

//重置按钮
const Reset=()=>{
    titles.value=''
    EditorData.value=''
}
// #endregion
</script>

<style scoped>

</style>