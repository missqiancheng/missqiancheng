<template>
  
  <h2>公告設置</h2>

  <!--头部查询框-->
  <div id="btn">
  </div>

  <!--表单-->
  <el-table :data="Data" id="big-width"
            @row-click="OpenBulletin">
    <el-table-column label="編號" prop="ID" min-width="20%" />
    <el-table-column label="標題" prop="TITLE" min-width="20%" />
    <el-table-column label="發佈時間" prop="EDITDATE" min-width="20%"/>
    <el-table-column label="編輯人" prop="EDITEMP" min-width="20%"/>
    <el-table-column label="操作" min-width="20%">
      <template #default="scope">
        <el-button size="small" type="danger" @click.stop="DeleteBulletin(scope.$index, scope.row)"
                  >刪除</el-button>                 
      </template>
    </el-table-column>
  </el-table>

  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>

  <!--公告框-->
  <el-dialog
    v-model="dialogVisible"
    title="公告"
    width="80%"
    draggable
  >
    <h1 class="BulletinTitle">{{GuilderDiaLog.title}}</h1>
    <div class="BulletinBody" v-html="GuilderDiaLog.Content"></div>
    <template #footer>
      <span class="dialog-footer">
      </span>
    </template>
  </el-dialog>  
</template>

<script setup>
import { reactive, ref } from "vue"
import { Axios } from "/src/Axios";
import { ElMessage,ElMessageBox } from 'element-plus'
import axios from 'axios'

const tableData=reactive([])

const RequestBulletin=()=>{
  Axios({
    url:'HomePages/GetSettingBulletin',
    method:'post',
  }).then(
    res=>{
      const data=res.data.Data
      for(let i=0;i<data.length;i++){
        tableData[i]=data[i]
      }
      DataCount.value=data.length
      Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequestBulletin()

//删除公告
const DeleteBulletin=(index,rows)=>{
  ElMessageBox.confirm('確定要刪除目前參公告嗎','提示',{
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      type: 'warning',
  }).then(()=>{
    RequestDelete(index,rows.ID)
  }).catch(()=>{
    ElMessage({
      type: 'info',
      message: '删除取消',
    }) 
  })

}
const RequestDelete=(index,id)=>{
  Axios({
    url:'HomePages/DeleteBulletin',
    method:'post',
    params:{
      id:id
    }
  }).then(
    res=>{
      const data=res.data
      ElMessage({
        type: 'success',
        message: '删除成功',
      }) 
      console.log(index)
      DataCount.value--
      Data.splice(index,1)
      tablesIndex=tableData.map(item=>item.ID).indexOf(id)
      tableData.splice(tablesIndex,1)
      console.log(data)
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}


// #region 查看公告
const dialogVisible=ref(false)
const OpenBulletin=(row)=>{
    GuilderDiaLog.title=row.TITLE
    axios({
        url:row.CONTEXTFILE,
        method:'Get',
    }).then(
        res=>{
            GuilderDiaLog.Content=res.data
        }
    ).catch(
        err=>{
            console.log(err)
        }
    )
    dialogVisible.value=true
}
//弹窗公告数据
const GuilderDiaLog=reactive({
    title:'',
    Content:''
})
// #endregion


// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}

// #endregion

</script>

<style scoped>
#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}

h2{
  font-size:35px;
  text-align: center;
  line-height:80px;
}

.BulletinTitle{
  font-size: 40px;
  text-align: center;
  margin-bottom:20px;
}

.BulletinBody{
  width: 90%;
  margin:auto;
}
</style>