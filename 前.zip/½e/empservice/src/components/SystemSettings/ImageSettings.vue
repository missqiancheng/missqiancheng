<template>
  <div class="ShowIamge">
    <ShowImage ref="imgs"></ShowImage>
  </div>
  
  <!--头部查询框-->
  <div id="btn">
    <el-button id="seletbtn" @click="AddImageDialogVisible=true" type="primary">上傳圖片</el-button>
  </div>
  <!--表单-->
  <el-table :data="Data"  id="big-width">
    <el-table-column label="編號" type="index" min-width="5%" />
    <el-table-column label="檔名" prop="IMAGENAME" min-width="20%" />
    <el-table-column label="圖片內容" prop="IAMGEDETAILS" min-width="20%" />
    <el-table-column label="輪播號" prop="SHOWIDE" min-width="10%"/>
    <el-table-column prop="預覽" label="預覽" min-width="20%">
      <template #default="scope">
        <div class="demo-image__preview">
          <el-image
            style="width: 200px;height: 100px;"
            :src="scope.row.IMAGEPATH"
            :zoom-rate="1.2"
            :preview-src-list="[scope.row.IMAGEPATH]"
            :initial-index="0"
            fit="cover"
            preview-teleported
          />
        </div>
      </template>
    </el-table-column>
    <el-table-column label="操作" min-width="25%">
      <template #default="scope">
        <el-button size="small" type="danger" @click="DeleteImage(scope.$index, scope.row)"
                  >刪除</el-button>     
        <el-button size="small" type="primary" @click="settingImage(scope.$index, scope.row)"
                  >加入輪播圖</el-button>
        <el-button size="small" type="primary" @click="OffImage(scope.$index, scope.row)"
                  >取消轮播</el-button>                 
      </template>
    </el-table-column>
  </el-table>

  <!--分页框-->
  <div class="Pages">
    <el-pagination layout="total,sizes,prev,pager,next,jumper" :page-size="PagesColumn" :current-page="pages" :page-sizes="[5,10,20,30]" 
                   :total="DataCount" :background="true"
                   @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
  </div>

  <!--上传图片dialog-->
  <el-dialog v-model="AddImageDialogVisible" title="上傳輪播圖" width="40%" draggable>
    <el-form :model="Addform" ref="BaseForm" :rules="rules">
      <el-form-item label="標題名：" prop='name' label-width="80px">
        <el-input v-model="Addform.name" autocomplete="off" />
      </el-form-item>
      <el-form-item label="內容：" prop='content' label-width="80px">
        <el-input v-model="Addform.content" type="textarea" autocomplete="off" />
      </el-form-item>
      <el-form-item label="原件："  label-width="80px">
        <UpLoad ref="load"></UpLoad>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="AddImage()">
          提交
        </el-button>
      </span>
    </template>
  </el-dialog>

  <!--设置轮播图dialog-->
  <el-dialog v-model="SettingDialogVisible" title="設置輪播圖"  width="20%" draggable>
    <el-form :model="SettingForm">
      <el-form-item label="輪播位置：">
        <el-input-number v-model="SettingForm.orders" :min="1" :max="10" />
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="RequestSetting()">提交</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import ShowImage from '/src/components/Home/ShowImage.vue'
import { onMounted, ref, reactive } from 'vue';
import { Axios } from "../../Axios";
import UpLoad from '/src/pages/UpLoad.vue'
import { ElMessage, ElMessageBox,ElLoading } from 'element-plus'

// #region 基本数据
//showimage设置
const imgs=ref()

const tableData=reactive([])

const AddImageDialogVisible=ref(false)
const SettingDialogVisible=ref(false)

//添加图片表单
const Addform=reactive({
  name:'',
  files:'',
  content:''
})

//设置轮播图表单
const SettingForm=reactive({
  id:'',
  indexs:'',
  orders:0
})


const load=ref()

const rules=reactive({

  name:[{
    required: true, message: '標題名稱不能為空', trigger: 'blur'
  }],
  
  content:[{
    required: true, message: '內容稱不能為空', trigger: 'blur'
  }],

})

const BaseForm=ref()
// #endregion


// #region 请求
// #region 获取表格数据
const RequestImage=()=>{
  Axios({
    url:'HomePages/GetImage',
    method:'post',
  }).then(
    res=>{
      const data=res.data.Data
      tableData.length=0
      for(let i=0;i<data.length;i++){
        tableData[i]=data[i]
      }
      DataCount.value=tableData.length
      Data= reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RequestImage()
// #endregion

// #region 上传图片
//获取文件
const getfile=()=>{
  load.value.submitUpload()
  Addform.files=load.value.getfile()
}

const AddImage=async()=>{
  await getfile()
  BaseForm.value.validate((valid) => {
    if (valid) {
      if(Addform.files==''){
        ElMessageBox.alert("未上傳圖片!",'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
      }
      RequestAddImage()
    }
  })
  
  
}

const RequestAddImage=()=>{
  const loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    background: 'rgba(0, 0, 0, 0.7)',
  })
  const formData=new FormData()
  formData.append('files',Addform.files);
  Axios({
    url:'HomePages/LoadImage',
    method:'post',
    data:formData,
    params:{
      filename:Addform.name,
      content:Addform.content
    }
  }).then(
    res=>{
      const data=res.data.Data
      ElMessage({
        type: 'success',
        message: '添加成功',
      })
      loading.close()
      RequestImage()
    }
  ).catch(
    err=>{
      loading.close()
      console.log(err)
    }
  )
  AddImageDialogVisible.value = false
}
// #endregion

// #region 删除图片数据
const DeleteImage=(index,row)=>{
  ElMessageBox.confirm('確定要刪除目前參考圖片嗎','提示',{
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      type: 'warning',
    }).then(() => {
      RequsetDelete(row.ID)
  }).catch(() => {})

}
const RequsetDelete=(ids)=>{
  Axios({
    url:'HomePages/DeleteImage',
    method:'post',
    params:{
      id:ids
    }
  }).then(
    res=>{
      const data=res.data.Data
      ElMessage({
        type: 'success',
        message: '删除成功',
      })
      RequestImage()
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

// #region 设置轮播图
const settingImage=(index,row)=>{
  SettingForm.id=row.ID
  SettingForm.indexs=index
  SettingDialogVisible.value=true
}
const RequestSetting=()=>{
  for(let i=0;i<tableData.length;i++){
    if(SettingForm.orders==0){
      break;
    }
    if(SettingForm.orders==tableData[i].SHOWIDE){
      console.log(SettingForm.orders)
      console.log(tableData[i].SHOWIDE)
      ElMessageBox.alert('當前播放位置已被佔用。','提示',{
        confirmButtonText: '確定',
        type: 'warning',
      })
      return
    }
  }
  Axios({
    url:'HomePages/SettingOrder',
    method:'post',
    params:{
      id:SettingForm.id,
      order:SettingForm.orders,
    }
  }).then(
    res=>{
      const data=res.data.Data
      ElMessage({
        type: 'success',
        message: '設置成功',
      })
      const index=tableData.map(item=>item.ID).indexOf(SettingForm.id)
      if(SettingForm.orders=='0'){
        tableData[index].SHOWIDE=undefined
        Data[SettingForm.indexs].SHOWIDE=undefined
      }
      else{
        tableData[index].SHOWIDE=SettingForm.orders
        Data[SettingForm.indexs].SHOWIDE=SettingForm.orders
      }
      imgs.value.RequestImage()
      
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
  SettingDialogVisible.value=false
}
// #endregion

// #region 取消轮播
const OffImage=(index,row)=>{
  SettingForm.id=row.ID
  SettingForm.indexs=index
  SettingForm.orders=0
  RequestSetting()
  //
}
// #endregion

// #endregion


// #region 分页功能
//总行数
const DataCount=ref(tableData.length)
//一列多少行
const PagesColumn=ref(10)
//当前页数
const pages=ref(1)
//表单显示数据
let Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
//一列行数改变时触发
const handleSizeChange=(value)=>{
  PagesColumn.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}
//页数改变时触发
const handleCurrentChange=(value)=>{
  pages.value=value
  Data=reactive(JSON.parse(JSON.stringify(tableData)).splice((pages.value-1)*PagesColumn.value,PagesColumn.value))
}

// #endregion
</script>

<style scoped>
#seletbtn{
  margin:0px;
  padding:0px;
  line-height: 22px;
  border-radius:0px;
  height:30px;
  width:100px;
  border:1px solid rgb(176, 176, 211);
  margin-top:8px;
  margin-left: 3px;
  float:right;
  margin-right: 15px;
}
.demo-image__error .image-slot {
  font-size: 30px;
}
.demo-image__error .image-slot .el-icon {
  font-size: 30px;
}
.demo-image__error .el-image {
  width: 100%;
  height: 200px;
}
.demo-image__preview{
  margin-top: 10px;
}
.el-image-viewer__mask{
  z-index: 4;
}
.ShowIamge{
    width:98%;
    background-color: white;
    margin: auto;
    margin-top: 6px;
    margin-bottom: 13px;
}

</style>
