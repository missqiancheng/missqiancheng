<template>
  <el-menu
    default-active="2"
    class="el-menu-vertical-demo"
    :collapse="ASideType"
  >
    <el-menu-item index="1" @click="AccordingDocument()">
      <el-icon><Files /></el-icon>
      <span>主頁輪播圖設置</span>
    </el-menu-item>
    <el-menu-item index="2" @click="AddBulletin()">
      <el-icon><DataAnalysis /></el-icon>
      <span>添加公告</span>
    </el-menu-item>
    <el-menu-item index="3"  @click="BulletinSetting()">
      <el-icon><Files /></el-icon>
      <span>管理公告</span>
    </el-menu-item>
  </el-menu>
</template>
<script setup>
import { MessageBox,DataAnalysis,Files
} from '@element-plus/icons-vue';
import {ref,inject} from 'vue'

const ASideType=inject('ASideType')


const emit=defineEmits(['addTabs'])

//参考文件
const AccordingDocument=()=>{
  const NavigationPath="ImageSettings"
  emit("addTabs","主頁輪播圖設置",NavigationPath)
}

//添加公告
const AddBulletin=()=>{
  const NavigationPath="AddBulletin"
  emit("addTabs","添加公告",NavigationPath)
}

//管理公告
const BulletinSetting=()=>{
  const NavigationPath="BulletinSetting"
  emit("addTabs","公告設置",NavigationPath)
}
</script>

<style scoped>
.el-menu-item.is-active{
background-color: #daf2fe !important;
}
*{
user-select: none;
}
</style>