<template>
  <div class="infoBox">
    <div class="empinfo">
      <!--上半头像部分-->
      <div class="topBox">
        <el-avatar shape="square" class="headerimg" :size="130" :src="squareUrl" />
        <div class="empname">
          <div class="nametile">{{Empinfo.F_NAME}}</div>
          <div class="logintile">上次登錄時間: {{Empinfo.CREATEDATE}}</div>
          <div class="logintile">上次登錄IP: {{Empinfo.IPADDRESS}}</div>
        </div>
      </div>
      <!--下班信息部分-->
      <div class="bottomBox">
        <!--第一行-->
        <div class="flexs">
          <div class="flexs-one">工 號：</div>
          <div class="flexs-tow">{{Empinfo.F_EMPNO}}</div>
        </div>
        <!--第二行-->
        <div class="flexs">
          <div class="flexs-one">職 位：</div>
          <div class="flexs-tow">{{Empinfo.F_MANAGE}}</div>
        </div>
        <!--第三行-->
        <div class="flexs">
          <div class="flexs-one">附 属：</div>
          <div class="flexs-tow">{{Empinfo.F_ARTIFICIAL}}</div>
        </div>
        <!--第四行-->
        <div class="flexs">
          <div class="flexs-one">部 門：</div>
          <div class="flexs-tow"> {{Empinfo.F_DEPARTNAME}}</div>
        </div>
        <!--第五行-->
        <div class="flexs">
          <div class="flexs-one">分 機：</div>
          <div class="flexs-tow">{{Empinfo.F_EXT}}</div>
        </div>
        <!--第六行-->
        <div class="flexs">
          <div class="flexs-one">手 機：</div>
          <div class="flexs-tow">{{Empinfo.F_TELEPHONE}}</div>
        </div>
        <!--第七行-->
        <div class="flexs">
          <div class="flexs-one">郵 箱：</div>
          <div class="flexs-tow">{{Empinfo.F_EMAIL}}</div>
        </div>
        <!--第八行-->
        <div class="flexs">
          <div class="flexs-one">歸 屬：</div>
          <div class="flexs-tow">{{Empinfo.F_PROVINCE}}</div>
        </div>
        <!--第九行-->
        <div class="flexs">
          <div class="flexs-one">入 職：</div>
          <div class="flexs-tow">{{Empinfo.F_INFACTORYDATE}}</div>
        </div>
      </div>
    </div>
    <div class="calender">
      <el-calendar>
        <template #date-cell="{ data }">
          <p :class="data.isSelected ? 'is-selected' : ''">
            {{ data.day.split('-').slice(1).join('-') }}
            {{ data.isSelected ? '✔️' : '' }}
          </p>
        </template>
      </el-calendar>
    </div>
  </div>
</template>

<script setup>
import {ref,reactive} from 'vue'
import { Axios } from '../Axios'
import useStore from '../Store'



const squareUrl=ref('/image/header.png')

let Empinfo=reactive({
  F_NAME:'',
  CREATEDATE:'',
  IPADDRESS:'',
  F_EMPNO:'',
  F_MANAGE:'',
  F_ARTIFICIAL:'',
  F_DEPARTNAME:'',
  F_EXT:'',
  F_PROVINCE:'',
  F_TELEPHONE:'',
  F_EMAIL:'',
  F_INFACTORYDATE:''
})

const Store=useStore()

const RueqsetInfo=()=>{
  Axios({
    url:'HomePages/GetEmpInfo',
    method:'post',
    params:{
      empno:Store.empno
    }
  }).then(
    res=>{
      const data=res.data.Data
      if(data===null){
        return
      }
      const resData=data[0]
      Empinfo.F_NAME=resData.F_NAME
      Empinfo.CREATEDATE=resData.CREATEDATE
      Empinfo.IPADDRESS=resData.IPADDRESS
      Empinfo.F_EMPNO=resData.F_EMPNO
      Empinfo.F_MANAGE=resData.F_MANAGE
      Empinfo.F_ARTIFICIAL=resData.F_ARTIFICIAL
      Empinfo.F_DEPARTNAME=resData.F_DEPARTNAME
      Empinfo.F_EXT=resData.F_EXT
      Empinfo.F_PROVINCE=resData.F_PROVINCE
      Empinfo.F_TELEPHONE=resData.F_TELEPHONE
      Empinfo.F_EMAIL=resData.F_EMAIL
      Empinfo.F_INFACTORYDATE=resData.F_INFACTORYDATE
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
RueqsetInfo()
</script>

<style scoped>
.infoBox{
  width: 98%;
  margin:15px;
  margin-top:0px;
  display: flex;
}
.empinfo{
  flex:1;
  background:#e0ecf5;
}
.calender{
  flex:2;
  margin-left: 20px;
  border:1px solid #dcdfe6;
  
}
.topBox{
  height:35%;
  display: flex;
  border-bottom:1px dashed gray;
}
.headerimg{
  margin: 6%;
  flex:1;
  min-width: 130px;
}
.bottomBox{
  height:65%;
  padding-top: 20px;
}
.is-selected {
  color: #1989fa;
}
.empname{
  flex:4;
  height: 100%;
}
.nametile{
  margin-top: 12%;
  margin-bottom: 4%;
  font-size:35px;
}
.logintile{
  color: gray;
}
.flexs{
  display: flex;

}
.flexs-one{
  flex:1;
  text-align: center;
  margin: auto;
  margin: 2px;
}
.flexs-tow{
  flex:2;
  margin: auto;
}
</style>