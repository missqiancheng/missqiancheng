<template>
  <div class="footer">
    <div class="OneLine">
      <span class="SystemName">系统维护人员：陈锐</span>
      <span class="tel">联系电话：68736</span>
      <span class="emali">邮箱：nsd-b2b-web@mail.foxconn.com</span>
    </div>
    <div class="CopyRight">
      Copyright © 2023 Fii-CNS All Rights Reserved
    </div>
    
  </div>
</template>

<script>
export default {
    name:'Footer'
}
</script>

<style scoped>
.footer{
    width:100%;
    height:80px;
    background-color:#a5a9ac;
    color:break;
}
.SystemName{
  text-align: center;
  flex: 1;
}
.tel{
  flex: 1;
  text-align: center;
}

.emali{
  flex: 1;
  text-align: center;
}
.OneLine{
  display: flex;
  line-height: 60px;
}
.CopyRight{
  
  text-align: center;
}
</style>