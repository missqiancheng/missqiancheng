<template>
    <el-menu
      class="el-menu-demo"
      mode="horizontal"
      width="100%"
      background-color="#1a83eb"
      text-color="#fff"
      
      active-text-color="#ffd04b"
      router
    >
      <el-menu-item index="1" class="Header-icon" disabled>
        <img class="icon" src="/image/header.jpeg">
        <span class="title">Fii-CNS 員工服務系統</span>
      </el-menu-item>
      <el-menu-item index="/">&nbsp;&nbsp;首页&nbsp;&nbsp;</el-menu-item>
      <el-menu-item index="/EmpVoice">員工之聲</el-menu-item>
      <el-menu-item index="/SER">SER管理</el-menu-item>
      <el-menu-item index="/IncentiveManage">獎懲管理</el-menu-item>
      <el-menu-item index="/EndDispatch">終止派遣</el-menu-item>
      <el-menu-item index="/Subsidy">補貼管理</el-menu-item>
      <el-menu-item index="/FireDrill">消防演習</el-menu-item>
      <el-menu-item index="/HealthManagement">健康管理</el-menu-item>
      <el-sub-menu index="9" class="User-Header">
        <template #title><span>{{Username}}</span></template>
        <el-menu-item index="2" disabled>&nbsp;
          <el-tooltip placement="top">
            <template #content> 左侧菜单栏开关 </template>
            <el-switch 
              v-model="ASideType" 
              :style="ButtonStlye"
              :active-icon="Fold"
              :inactive-icon="Expand"
              inline-prompt
              @change="ASideShow"
            />
          </el-tooltip>
        </el-menu-item>
        <el-menu-item v-if="types==='3'||types==='41'" index="/SystemSetting" router="false">系統設置</el-menu-item>
        <el-menu-item index="/Login" router="false" @click="SignOut">退出登錄</el-menu-item>
      </el-sub-menu>
    </el-menu>
  </template>
  
<script setup>
import { ref,inject } from 'vue'
import {useRouter,useRoute} from 'vue-router'
import { Expand,Fold,Menu } from '@element-plus/icons-vue';
import useStore from '../Store';
import { Axios } from '/src/Axios'

//样式
const ButtonStlye='margin: auto;--el-switch-on-color: #000000;--el-switch-off-color: #c9c9c9;'

let Username=localStorage.getItem('empno')
const router = useRouter()

//退出登录
const SignOut=()=>{
  localStorage.clear()
  //Axios.defaults.headers['token']=''
}
const types=localStorage.getItem('userType')


//左侧菜单栏显示类型
const ASideType=inject('ASideType')
//宽度
const ASideWidth=inject('ASideWidth')
const ASideShow=(val)=>{
  if(val==true) ASideWidth.value='auto'
  else ASideWidth.value='15%'
}

defineExpose({ASideType})

</script>

<style scoped>
.User-Header{
  font-size:16px;
  font-weight:bold;
  margin-left: auto;
}
.icon {
  height: 56px;
}
.Header-icon{
  background: 0 0!important;
  --el-menu-hover-bg-color: rgb(1,1,1,0);
  min-width: 280px;
}

.el-menu-item.is-disabled {
    opacity: 1;
    cursor: default;
    background: 0 0!important;
}

.title{
  font-size: 20px;
}

.flex-grow{
  width:calc(100vw - 1253px);;
}

/*透明头 */
.el-menu-item{
    /* color: rgb(182, 182, 182);
    --el-menu-hover-text-color: rgba(2, 2, 2, 0.9); */
    font-size:16px;
    font-weight:bold;
  }
.el-menu--horizontal>.el-menu-item.Header-icon.is-active{
  /* border-bottom:1px solid #585858fb;
  --el-menu-active-color: rgb(182, 182, 182); */
}
.el-menu-demo el-menu-item:hover{
    /* color:black; */
}

.el-menu{
    /* --el-menu-bg-color:: rgba(R, G, B, A); */
    /* --el-menu-bg-color:rgb(255, 255, 255); */
    /* 选中背景色 */
    /* --el-menu-hover-bg-color: rgba(250, 250, 250, 0.32);
    --el-menu-active-color: var(--el-color-primary);
    --el-color-primary:rgb(255, 255, 255); */
    /* 边框线颜色 */
    /* --el-menu-border-color:rgb(1,1,1,0);
    background-image: linear-gradient(rgb(51, 51, 51), rgba(255, 255, 255, 0));
    border-bottom: 0px; */
}
.el-menu-item.Header-icon{
  /* --el-menu-hover-text-color: rgb(182, 182, 182); */
}
</style>
<style>
/*处理下拉头宽度固定 */
.el-menu--popup{
  margin:0px;
  padding:0px;
  min-width: 130px!important;
}

</style>