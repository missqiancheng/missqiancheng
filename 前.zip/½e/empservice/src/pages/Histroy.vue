<template>
  <h2 class="title">員工獎懲申請</h2>
  <el-form :model="form"  ref="baseForm" width="100%"
           label-width="140px" class="from">

    <!--职业健康体检信息-->
    <div class="EMPBox" v-if="FindBox">
      <div class="BoxTitle" style="color:red;"><b>職業健康監護資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="empinfo">
        <!--第一行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="監護崗位名稱：">
              {{ FIndTable.Cause_harm }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="預計安排體檢日期：">
              {{ FIndTable.Pre_Me_Date }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="體檢地點：">
              {{ FIndTable.Me_Place }}
            </el-form-item>
          </el-col>
        </el-row>
 
        <!--第二行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="實際體檢時間：">
              {{ FIndTable.Me_Date }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="體檢結果：">
              {{ FIndTable.Me_Result }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="出席狀態：">
              {{ FIndTable.Need_ME }}
            </el-form-item>
          </el-col>
        </el-row>
    
        <!--第三行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="不體檢說明：">
              {{ FIndTable.Quit_Reason }}
            </el-form-item>
          </el-col>
          <el-col :span="8"></el-col>
        </el-row>
      </div>
    </div>

    <div class="EMPBox">
      <div class="BoxTitle"><b>員工資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="empinfo">
        <!--第一行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="員工工號：" prop='emp_no'>
              <el-input v-model="form.emp_no" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="員工姓名：">
              <el-input v-model="form.name" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="目前工作擔當：" prop='duty'>
              <el-input v-model="form.duty" readonly />
            </el-form-item>
          </el-col>
        </el-row>

        <!--第二行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="資位：">
              <el-input v-model="forms.f_grand" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="入職日期：">
              <el-input v-model="forms.f_infactorydate" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="部門名稱：">
              <el-tooltip
                class="box-item"
                effect="dark"
                :content="forms.f_departname"
                placement="bottom-start"
              ><el-input  v-model="forms.f_departname" readonly /></el-tooltip>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第三行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="提報人：" prop='tbr'>
              <el-input v-model="form.tbr" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="提報人聯系方式：" prop='tbr_tel'>
              <el-input v-model="form.tbr_tel" readonly />
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </div>
    
    <div class="RPMBox">
      <div class="BoxTitle"><b>獎懲資訊</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="RPMinfo">
        <!--第四行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="獎懲發生日期：" prop="f_occurdate">
              <el-input v-model="form.f_occurdate" readonly />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="獎懲依據：" prop="jc_yj">
              <el-tooltip
                class="box-item"
                effect="dark"
                :content="form.jc_yj"
                placement="top-start"
              ><el-input v-model="form.jc_yj" readonly /></el-tooltip> 
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第五行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="獎懲條例：" prop="jc_tl">
              <el-input v-model="form.jc_tl" readonly style="width:218px;" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第六行-->
        <el-row>
          <el-col :span="17">
            <el-form-item label="條例內容：">
              <el-input v-model="form.f_jcitemcontent" rows="4" readonly  type="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第七行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="處理類別：">
              <label>{{form.jc_dj}}</label>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="獎懲類別：">
              <label>{{form.jc_type}}</label>
            </el-form-item>
          </el-col>
        </el-row>
        
        <!--第七行(隐藏)-->
        <el-row v-if="form.jc_dj==='開除'">
          <el-col :span="8">
            <el-form-item label="開除類型：">
              <label>{{form.f_delistype}}</label>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="曠工日期：" v-if="form.f_delistype==='曠工開除'">
              <label>{{form.absenteeismdate}}</label>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第八行-->
        <el-row>
          <el-col :span="17">
            <el-form-item label="獎懲原由：" prop="remark">
              <el-input v-model="form.remark" rows="4" type="textarea" readonly />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第九行-->
        <el-row>
          <el-col :span="24">
            <el-form-item label="佐證材料：">
              <span v-if="form.file_name==undefined">无上传文件</span>
              <el-icon class="iconMidde" :size="IconSize" :color="IconColor" v-else
                   @click="DownLoads(form.file_name)"><Download /></el-icon>
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="是否變更處理類別：">
              <el-switch
                v-model="form.f_changetype"
                class="mt-2"
                style="margin-left: 24px"
                inline-prompt
                :active-icon="Check"
                :inactive-icon="Close"
              />
            </el-form-item>
          </el-col>
        </el-row>
   
        <!--第十行（隐藏一行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="8">
            <el-form-item label="變更等級：" prop="f_jcdj_new">
              <el-input v-model="form.f_jcdj_new" readonly />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏二行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="17">
            <el-form-item label="變更類別原由：" prop="f_changereason">
              <el-input v-model="form.f_changereason" rows="4" type="textarea" readonly />
            </el-form-item>
          </el-col>
        </el-row>
  
        <!--第十行（隐藏三行）-->
        <el-row v-if="form.f_changetype">
          <el-col :span="8">
            <el-form-item label="證明材料：">
              <span v-if="form.hr_file_name==undefined">无上传文件</span>
              <el-icon class="iconMidde" :size="IconSize" :color="IconColor" v-else
                   @click="DownLoads(form.hr_file_name)"><Download /></el-icon>
            </el-form-item>
          </el-col>
        </el-row>
      
        <!--第十一行-->
        <el-row> 
          <el-col :span="8.5">
            <el-form-item label="員工年度獎懲信息：">
              <el-collapse v-model="activeNames">
                <el-collapse-item title="" name="1">
                  <el-table :data="RPMYear" :row-class-name="tableRowClassName">     
                      <!--序号-->
                      <el-table-column prop="F_OCCURDATE"
                                       label="獎懲時間"
                                       width="110">
                      </el-table-column>
                      <el-table-column prop="JC_DJ"
                                       label="獎懲等級"
                                       width="100">
                      </el-table-column>
                  </el-table>
                </el-collapse-item>
              </el-collapse>
            </el-form-item>
          </el-col>
        </el-row>

        <!--第十二行（HR结案文件）-->
        <el-row v-if="!form.hr_check==''">
          <el-col :span="8">
            <el-form-item label="結案文檔：">
              <span v-if="form.hr_check==null">无上传文件</span>
              <el-icon class="iconMidde" :size="IconSize" :color="IconColor" v-else
                   @click="DownLoads(form.hr_check)"><Download /></el-icon>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
    </div>
    
    <div class="buttonBox">
      <slot name="Pass"></slot>
      <slot name="Cancel"></slot>
    </div>

    <div class="RPMBox" v-if="SingHistory">
      <div class="BoxTitle"><b>簽核記錄</b></div>
      <hr style="border-top:1px #0066CC;" />
      <div class="History">
        <el-table :data="History" style="width: 100%;">     
            <!--序号-->
            <el-table-column prop="SIGNER"
                             label="簽核主管"
                             min-width="15%">
            </el-table-column>
            <el-table-column prop="F_NAME"
                             label="主管姓名"
                             min-width="15%">
            </el-table-column>
            <el-table-column prop="SIGNSTATUS"
                             label="簽核狀態"
                             min-width="25%">
            </el-table-column>
            <el-table-column prop="RESULT"
                             label="簽核結果"
                             min-width="15%">
            </el-table-column>
            <el-table-column prop="SIGNTIME"
                             label="簽核時間"
                             min-width="15%">
            </el-table-column>
            <el-table-column prop="MEMO"
                             label="簽核意見"
                             min-width="25%">
            </el-table-column>
            <el-table-column prop="SIGNTYPE"
                             label="簽核類型"
                             min-width="15%">
            </el-table-column>
        </el-table>
      </div>
    </div>

  </el-form>
  
</template>

<script setup>
import { onBeforeUnmount,reactive,ref } from 'vue'
import { Axios,Token,DownLoad,DownFile } from '/src/Axios'
import { Check, Close,Edit,Search,EditPen,DataLine,Download  } from '@element-plus/icons-vue'


// #region 基础数据
//表单绑定提交数据
const form = reactive({
  //@基本数据@
  //工号
  emp_no:'',
  //姓名
  name: '',
  //工作担当
  duty: '',
  //提报人
  tbr:localStorage.getItem('empno'),
  //提报人联系方式
  tbr_tel: '',
  
  //@奖惩数据@
  //1.奖惩发生日期
  f_occurdate: '',
  //2.奖惩依据单号
  f_jcitemno:'',
  //2.奖惩依据
  jc_yj:'',
  //3.奖惩条例
  jc_tl: '',
  //4.条款内容
  f_jcitemcontent:'',
  //5.处理类别
  jc_dj:'',//開除
  //6.奖惩类别
  jc_type:'',
  //7.奖惩原因
  remark:'',
  //8.相关自述材料
  file_name:'',
  //9.是否变更处理类别
  f_changetype: false,
  //隐藏1.变更类别等级
  f_jcdj_new:'',
  //隐藏2.变更类别理由
  f_changereason:'',
  //隐藏3.证明材料
  hr_file_name:'',
  //特殊提交：旷工日期
  absenteeismdate:'',
  //特殊提交：開除类型
  f_delistype:'',
  
  hr_check:''
})

//表单显示非提交数据
const forms=reactive({
  //职位
  f_grand: '',
  //入职日期
  f_infactorydate: '',
  //部门名称
  f_departname:'',
})

//年度奖惩信息数据
const RPMYear=reactive([])

//签核记录
const History=reactive([])

//动态显示年度奖惩表格背景
const tableRowClassName=(row,rowIndex)=>{
  if(row.row.Grade==="大过一次"){
    return "TabBg"
  }else if(row.row.Grade==="大过二次"){
    return "TabBg"
  }
}

//图标样式 
const IconSize=ref(25)
const IconColor=ref('#409EFC')

//默认展开
const activeNames=ref(1)

//下载文件
const DownLoads=(url)=>{
  if(url instanceof File){
    DownFile(url,url.name)
  }else{
    const filename=url.split("/")
    DownLoad(url,filename[filename.length-1])
  }
}
// #endregion

// #region 根据工号查询请求数据
const RequestHostory=(apply_nos,empno,year)=>{
  Axios({
    url:'IncentiveManage/GetYearAndHistory',
    method:'post',
    params:{
      empno:empno,
      applyno:apply_nos,
      year:year,
    }
  }).then(
    res=>{
      const data=res.data.Data
      //基本信息
      const DocumentInfo=data['DocumentInfo'][0]
      form.emp_no=DocumentInfo.EMP_NO
      form.name=DocumentInfo.NAME
      form.duty=DocumentInfo.DUTY
      forms.f_grand=DocumentInfo.F_GRAND
      forms.f_infactorydate=DocumentInfo.F_INFACTORYDATE
      forms.f_departname=DocumentInfo.F_DEPARTNAME
      form.tbr_tel=DocumentInfo.TBR_TEL
      form.tbr=DocumentInfo.TBR
      //奖惩信息
      form.f_occurdate=DocumentInfo.F_OCCURDATE
      form.jc_yj=DocumentInfo.JC_YJ
      form.jc_tl=DocumentInfo.JC_TL
      form.f_jcitemcontent=DocumentInfo.F_JCITEMCONTENT
      form.jc_dj=DocumentInfo.JC_DJ
      form.jc_type=DocumentInfo.JC_TYPE
      form.remark=DocumentInfo.REMARK
      form.file_name=DocumentInfo.FILE_NAME
      form.f_delistype=DocumentInfo.F_DELISTYPE
      form.absenteeismdate=DocumentInfo.F_ABSENTDATE
      //变更信息
      form.f_changetype=(DocumentInfo.F_CHANGETYPE=='是')
      form.f_changereason=DocumentInfo.F_CHANGEREASON
      form.f_jcdj_new=DocumentInfo.F_JCDJ_NEW
      form.hr_file_name=DocumentInfo.HR_FILE_NAME
      form.hr_check=DocumentInfo.HR_CHECK
      //年度奖惩信息
      for(let i=0;i<data['YaerTable'].length;i++){
        RPMYear[i]=data['YaerTable'][i]
      }
      
      //签核记录
      for(let i=0;i<data['SignerHistory'].length;i++){
        History[i]=data['SignerHistory'][i]
      }
      CheckFind(DocumentInfo.EMP_NO)
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
  
}

// #endregion

// #region 为表单赋值并请求年度信息和职业健康体检信息
const SingHistory=ref(true)
const GiveDetails=(emp_no,name,duty,tbr,tbr_tel,f_occurdate,jc_yj,jc_tl,jc_dj,jc_type,
remark,file_name,f_changetype,f_changereason,f_jcdj_new,hr_file_name)=>{
  //基本信息
  form.emp_no=emp_no
  form.name=name
  form.duty=duty
  form.tbr_tel=tbr_tel
  form.tbr=tbr
  //奖惩信息
  form.f_occurdate=f_occurdate
  form.jc_yj=jc_yj
  form.jc_tl=jc_tl
  form.jc_dj=jc_dj
  form.jc_type=jc_type
  form.remark=remark
  form.file_name=file_name
  //变更信息
  form.f_changetype=(f_changetype=='是')
  form.f_changereason=f_changereason
  form.f_jcdj_new=f_jcdj_new
  form.hr_file_name=hr_file_name
  //获取信息
  new Promise((resolve,reject)=>{
    FetchEmp(emp_no,name)
    resolve()
  }).then(()=>{
    RqeustJC_TL(jc_yj,jc_tl,jc_dj,jc_type)
  }).then(()=>{
    CheckFind(emp_no)
  })
  //隐藏签核记录
  SingHistory.value=false
}
//通过工号或员工信息 
const FetchEmp=(emp_nos,name)=>{
  Axios({
    url:'IncentiveManage/GetEmpInfo',
    method:'Post',
    params:{
      empno:emp_nos
    }
  }).then(
    res=>{
      const data=res.data
      if(data.Code==='500'){
        ElMessageBox.alert(data.Message+"!",'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
      }
      const info=data.Data.EmpInfo
      const YearIncentive=data.Data.YearIncentive
      if(name!=info[0].F_NAME){
        ElMessageBox.alert("姓名工號不一致，請檢查!",'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
        return
      }
      forms.f_grand=info[0].F_GRAND
      forms.f_infactorydate=info[0].F_DEPARTNAME
      forms.f_departname=info[0].F_INFACTORYDATE
      for(let i=0;i<YearIncentive.length;i++){
        RPMYear[i]=YearIncentive[i]
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
//获取奖惩条例内容
const RqeustJC_TL=(jc_yj,jc_tl,jc_dj,jc_type)=>{
  Axios({
    url:'IncentiveManage/IncentiveContent',
    method:'Post',
    params:{
      jc_yj:jc_yj,
      jc_tl:jc_tl,
      jc_dj:jc_dj,
      jc_type:jc_type
    }
  }).then(
    res=>{
      const Content=res.data.Data 
      if(Content===''){
        ElMessageBox.alert("當前單據獎懲依據，獎懲等級，獎懲條例，獎懲類型不匹配請重新填寫。",'提示',
        {confirmButtonText: '確認',type: 'warning',draggable: true})
      }
      form.f_jcitemcontent=Content
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

// #region 职业健康体检信息显示
//是否显示职业健康监控box
const FindBox=ref(false)
//职业健康内容
const FIndTable=reactive({
  Cause_harm:'',//岗位名称
  Pre_Me_Date:'',//預計安排體檢日期
  Me_Place:'',//體檢地點
  Me_Date:'',//實際體檢時間
  Me_Result:'',//體檢結果
  Need_ME:'',//体检状态
  Quit_Reason:'',//不體檢說明
}) 
//判断员工是否为职业健康监控岗位
const CheckFind=(emp_No)=>{
  const forms=new FormData()
  Axios({
    url:'IncentiveManage/GetEmpFind',
    method:'post',
    params:{
      f_empno:emp_No
    }
  }).then(
    res=>{
      if(res.data.Message!=''){
        const data=res.data.Data[0]
        FindBox.value=true
        FIndTable.Cause_harm=res.data.Message
        FIndTable.Pre_Me_Date=data.Pre_ME_date
        FIndTable.Me_Date=data.Me_Date
        FIndTable.Me_Place=data.ME_Place
        FIndTable.Me_Result=data.Me_Result
        FIndTable.Need_ME=(data.Need_ME=='Y')?'出席':'未出席'
        FIndTable.Quit_Reason=data.Quitme_Remark
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}
// #endregion

defineExpose({RequestHostory,History,form,GiveDetails})
</script>


<style scoped>

*{
  user-select: auto;
}

/*申请单标题*/
.title{
  text-align: center;
  font-size: 30px;
}

.el-input{
  width:auto;
}

/*表单整体样式 */
.from{
  width: 98%;
  margin:auto;
  margin-top: 35px;
}
.el-textarea{
  width: 89%;
}

/*员工信息边框 */
.empinfo{
  border:0px;
  padding-top:20px;
  width:90%;
  margin:auto;
}

/*RPM边框 */
.RPMinfo{
  margin:auto;
  width:90%;
  padding-top:20px;
}
.History{
  margin:auto;

}
/*边框label样式 */
.BoxTitle{
  /*边框label移动 */
  width: 160px;
  height:40px;
  font-size:20px;
  padding-left: 20px;
  padding-top: 10px;
}


/*模板框 */
.EMPBox{
  background: white;
  width:100%;
  height: 230px;
  margin-bottom: 20px;
}
.RPMBox{
  background: white;
  width:100%;
  height: 100%;
  margin-bottom: 20px;
}


/*图标居中*/
.iconMidde{
  vertical-align: middle;
  margin-right: 10px;
  margin-left: 10px;
}
.iconMidde:hover{
  color: orange;
  
}

.buttonBox{
  text-align: right;
  margin-bottom: 15px;
}
</style>
<style>
/*大过表格背景色 */
.el-table .TabBg{
  /* --el-table-tr-bg-color: var(--el-color-warning-light-9); */
  background:oldlace;
}
</style>