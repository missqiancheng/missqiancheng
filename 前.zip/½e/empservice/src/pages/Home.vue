<template>
  <el-scrollbar :height="PageSize">
    <div class="common-layout">
      <el-container>
        <!--菜单头部分-->
        <el-header>
          <Header ref="headerss"></Header>
        </el-header>
        <!--身体部分-->
        <el-container id="contents">
          <!--左边菜单部分-->
          <el-aside id="aside" :width="ASideWidth" v-if="!$route.meta.home">
            <!--Suspense组件在测试当中-->
            <Suspense>
              <template v-slot:default>
                <router-view v-slot="{ Component }">
                  <component :is="Component" @addTabs="addTabs" :ASideType="ASideType" :DefaultChange="DefaultChange" />
                </router-view>
              </template>
              <template v-slot:fallback>
                <h1>--加载中--</h1>
              </template>
            </Suspense>
            <!-- <router-view v-slot="{ Component }">
              <component :is="Component" @addTabs="addTabs" :ASideType="ASideType" />
            </router-view> -->
          </el-aside>
          <!--tabes标签部分，和主页主体部分-->
          <el-container id="mains">
            <el-main id="main">
              <Home v-if="$route.meta.home"></Home>
              <Tabs ref="tbs" v-else></Tabs>
            </el-main>
            <el-footer id="footer" v-if="$route.meta.home">
              <Footer></Footer>
            </el-footer>
          </el-container>
        </el-container>
      </el-container> 
    </div>
  </el-scrollbar>

  <!--系统日志-->
  <el-dialog
    v-model="centerDialogVisible"
    width="30%"
    align-center
    draggable
    destroy-on-close
  >
    <template #header="{ titleId, titleClass }">
      <div class="my-header">
        <el-icon color="green" size="20" style="margin-top: 2px;"><ElementPlus /></el-icon>
        <span :id="titleId" :class="titleClass" 
              style="color: green;vertical-align: top;font-size: 20px;">
          系统更新日志
        </span>
      </div>
    </template>
    <div class="demo-collapse">
      <el-collapse>
        <el-collapse-item title="新增功能" name="1">
          <el-timeline>
            <el-timeline-item
              v-for="(activity, index) in AddLog"
              :key="index"
              :icon="activity.icon"
              :type="activity.type"
              :color="activity.color"
              :hollow="activity.hollow"
              :timestamp="activity.timestamp"
            >
              {{ activity.content }}
            </el-timeline-item>
          </el-timeline>
        </el-collapse-item>
        <el-collapse-item title="bug修复" name="2">
          <el-timeline>
            <el-timeline-item
              v-for="(activity, index) in BugLog"
              :key="index"
              :icon="activity.icon"
              :type="activity.type"
              :color="activity.color"
              :hollow="activity.hollow"
              :timestamp="activity.timestamp"
            >
              {{ activity.content }}
            </el-timeline-item>
          </el-timeline>
        </el-collapse-item>
        <el-collapse-item title="页面优化" name="3">
          <el-timeline>
            <el-timeline-item
              v-for="(activity, index) in PagesLog"
              :key="index"
              :icon="activity.icon"
              :type="activity.type"
              :color="activity.color"
              :hollow="activity.hollow"
              :timestamp="activity.timestamp"
            >
              {{ activity.content }}
            </el-timeline-item>
          </el-timeline>
        </el-collapse-item>
        <el-collapse-item title="旧页面修改" name="4">
          <el-timeline>
            <el-timeline-item
              v-for="(activity, index) in UpdateLog"
              :key="index"
              :icon="activity.icon"
              :type="activity.type"
              :color="activity.color"
              :hollow="activity.hollow"
              :timestamp="activity.timestamp"
            >
              {{ activity.content }}
            </el-timeline-item>
          </el-timeline>
        </el-collapse-item>
      </el-collapse>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="centerDialogVisible = false">
          Are you sure?
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>


<script setup>
import Header from '/src/pages/Header.vue'
import Footer from '/src/pages/Footer.vue'
import Home from '/src/components/Home/Home.vue'
import Tabs from '/src/pages/Tabs.vue'
import { ref,reactive,provide } from 'vue'
import { ElementPlus } from '@element-plus/icons-vue'

// #region 日志数据
//新增功能日志数据
const AddLog = [
  {
    content: '管理后台默认页面构建完成',
    timestamp: '2023-05-18 11:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: '系统设置框架搭建完成',
    timestamp: '2023-05-20 20:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: '系统设置轮播图设置页面构建完成',
    timestamp: '2023-05-22 14:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: '系统设置轮播图设置功能完成',
    timestamp: '2023-04-24 13:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: '系统设置轮播图设置功能完成',
    timestamp: '2023-04-24 20:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: '公告查看功能开启',
    timestamp: '2023-05-3 13:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: '系统设置写公告功能完成',
    timestamp: '2023-05-12 08:21',
    type: 'primary',
    hollow: true,
  },
  {
    content: '系统设置管理公告功能开启',
    timestamp: '2023-05-19 14:45',
    type: 'primary',
    hollow: true,
  }
]

//bug修复
const BugLog = [
  {
    content: 'icon',
    timestamp: '2018-04-12 20:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: 'Tom color',
    timestamp: '2018-04-03 20:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: 'Custom size',
    timestamp: '2018-04-03 20:46',
    type: 'primary',
    hollow: true,
  }
]

//页面优化
const PagesLog = [
  {
    content: '调整刷新跳到登录设定',
    timestamp: '2018-05-24 11:41',
    type: 'primary',
    hollow: true,
  },
  {
    content: 'Custom color',
    timestamp: '2018-04-03 20:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: 'Custom size',
    timestamp: '2018-04-03 20:46',
    type: 'primary',
    hollow: true,
  }
]

//旧页面修改
const UpdateLog = [
  {
    content: 'Custom icon',
    timestamp: '2018-04-12 20:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: 'Custom color',
    timestamp: '2018-04-03 20:46',
    type: 'primary',
    hollow: true,
  },
  {
    content: 'Custom size',
    timestamp: '2018-04-03 20:46',
    type: 'primary',
    hollow: true,
  }
]

//日志弹窗
const centerDialogVisible=ref(false)
// #endregion



//滚动条高度
const PageSize=ref(window.innerHeight)
//滚动条按窗口大小变化
window.onresize=()=>{
  PageSize.value=window.innerHeight
  ctnMinHeight.value=window.innerHeight-58+'px'
}

//设置content的最小高度
let ctnMinHeight=ref(window.innerHeight-62+'px')


//获取tbs组件
const tbs=ref()
//添加标签页方法
const addTabs=(title,componentName)=>{
  tbs.value.addTabs(title,componentName)
}
const ASideWidth=ref('15%')
const DefaultChange=ref('')
const ASideType=ref(false)
provide('ASideType', ASideType)
provide('ASideWidth', ASideWidth);
provide('DefaultChange', DefaultChange);


</script>
  
<style scoped>
#aside{
  min-height:v-bind(ctnMinHeight);
  margin-right: 2px;
  background: white;
}
.el-header{
  /* opacity: 0.7; */
  /* background:rgba(R,G, B, A); */
  margin: 0px;
  padding: 0px;
  width:100%;
  user-select: none;
  height: 58px;
  margin-bottom: 4px;
}
.el-main{
  --el-main-padding: 0px;
}
#footer{
  padding: 0px;
}
.common-layout{
  background: #e8e4e4;
}
</style>
