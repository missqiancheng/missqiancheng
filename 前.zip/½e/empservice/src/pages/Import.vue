<template>
    <div class="LoadMaxBox" id="loadbox">
      <div class="headTitles"><span style="margin-left: 14px;color: rgb(0, 0, 0);">批量導入</span></div>
      <el-upload drag v-bind:data="fileList" :auto-upload="false" :file-list="fileList" :limit="1"
                :action="LoadPath" :on-success="OnSuccess" :on-error="error" :before-upload="beforeAvatarUpload"
                 accept=".xls,.xlsx" ref="upload" class="LoadBox" :method="Methods">
          <!--限制文件类型，上传时获取事件-->
          <el-icon id="icon" class="el-icon--upload"><upload-filled /></el-icon>
          <div class="el-upload__text">將檔案拖到此處，或<em>點擊導入</em></div>
          <template #tip>
              <div class="subBox">
                  <el-button class="subBtn" id="subBtn" type="primary" @click="submitUpload">上傳</el-button>
              </div>
              <div class="el-upload__tip el-upload-list__item-name">
                  <span>只能上傳.xlsx/.xls檔，且不超過5MB</span>
                  <span class="foot_right" @click="download">下載模板</span>
              </div>
          </template>
      </el-upload>
  </div>
</template>

<script setup>
import { UploadFilled } from '@element-plus/icons-vue'
import {ElMessageBox} from 'element-plus'
import {ref} from 'vue'
import { ArrowRight } from '@element-plus/icons-vue'


//父组件传值
const emit=defineEmits(["OnSuccess"])
const props = defineProps({
  LoadPath: String,//上传路径
  download:String,//模板下载路径
  Methods:String
})


//上传路径
const LoadPath=props.LoadPath
//上传控件
const upload=ref()
//文件列表
const fileList=ref()

//文件
let file=''
//上传前 check
const beforeAvatarUpload=(res)=>{
    if(res.name.includes('.xls')){
        file=res
        return true
    }else{
        ElMessageBox.alert('只能上傳.xlsx/.xls檔，且不超過5MB！','提示',{
          confirmButtonText: '確認',
          type: 'warning',
          draggable: true,
        })
        return false
    }
}

const getfile=()=>{
  return file
}

//上传成功
const OnSuccess=(res)=>{ 
  emit("OnSuccess",res)
}

//上传错误
const error=()=>{
  ElMessageBox.alert('網路錯誤，請檢查！','提示',{
    confirmButtonText: '確認',
    type: 'error',
    draggable: true,
  })
}


//上传文件
const submitUpload=()=>{
  upload.value.submit()
}

//下载模板
const download=()=>{
  location.href=props.download
}

defineExpose({getfile})

</script>

<style scoped>

</style>

