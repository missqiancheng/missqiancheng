<template>
  <div id="login_box">
    <h2>LOGIN</h2>
    <div id="input_box">
      <input v-model="form.empno" type="text" placeholder="请输入用户名">
    </div>
    <div class="input_box">
      <input v-model="form.password" type="password" placeholder="请输入密码">
    </div>
    <button @click="submit()">登录</button><br>
  </div>
</template>

<script setup>
import route from '/src/router'
import {reactive, ref} from 'vue'
import { Axios,Headers } from '/src/Axios';
import { ElMessage,ElMessageBox } from 'element-plus'


const form=reactive({
  empno:'',
  password:''
})

//登录提交
const submit=(async)=>{
  Axios({
    url:'/api/Login',
    method:'post',
    params:{
      empno:form.empno,
      password:form.password
    }
  }).then( 
    async(res)=>{
      const data=res.data
      if(data.token==='error'){
        ElMessageBox.alert('账号错误！','提示',{
          type: 'warning',
          draggable: true,
        })
      }else{
        await new Promise((resolve,reject)=>{
          localStorage.setItem('OverDate',Date.now() + 20 * 60 * 1000)
          localStorage.setItem('empno',form.empno)
          localStorage.setItem('userType',data.type)
          localStorage.setItem('token',data.token) 
          localStorage.setItem('plant',data.plant) 
          Headers.token=localStorage.getItem("token")
          //Axios.defaults.headers['token']=localStorage.getItem("token")
          resolve()
        })
        const body=document.getElementsByTagName('body')
        body[0].style.background='none'
        route.push({
          path:'/'
        })
      }
    }
  ).catch(
    err=>{
      console.log(err)
    }
  )
}



</script>
<style>
body {
  background:url('/image/login.jpg') no-repeat;
  background-size: 100% 130%;
  height: 80vh;
}
</style>
<style scoped>

#login_box {
  width: 20%;
  height: 400px;
  background-color: #00000060;
  margin: auto;
  margin-top: 10%;
  text-align: center;
  border-radius: 10px;
  padding: 50px 50px;
}
h2 {
  color: #ffffff90;
  margin-top: 5%;
}
#input-box {
  margin-top: 5%;
}
span {
  color: #fff;
}
input {
  border: 0;
  width: 60%;
  font-size: 15px;
  color: #fff;
  background: transparent;
  border-bottom: 2px solid #fff;
  padding: 5px 10px;
  outline: none;
  margin-top: 10px;
}
button {
  margin-top: 50px;
  width: 60%;
  height: 30px;
  border-radius: 10px;
  border: 0;
  color: #fff;
  text-align: center;
  line-height: 30px;
  font-size: 15px;
  background-image: linear-gradient(to right, #30cfd0, #330867);
}
#sign_up {
  margin-top: 45%;
  margin-left: 60%;
}
a {
  color: #b94648;
}
</style>