<template>
    <el-tabs
      model-value="editableTabsValue"
      v-model="SelectCard"
      type="card"
      class="demo-tabs"
      @tab-remove="removeTab"
      :before-leave="TbsLeave"
    >
      <el-tab-pane
        v-for="item in editableTabs"
        :key="item.name"
        :label="item.title"
        :name="item.name"
        :closable="item.closable"
      >
        <component :is="item.content" ref="cmps"></component>
      </el-tab-pane>
    </el-tabs>
</template>
<script setup>
import { reactive,ref,shallowRef,inject  } from "vue"
import Default from "/src/pages/DefaultPage.vue"
import { useRouter } from "vue-router"
import router from '/src/router'
//内部组件 《奖惩系列》
import According from "/src/components/IncentiveManage/AccordingDocument.vue"
import Application from "/src/components/IncentiveManage/Application.vue"
import IncentiveImport from "/src/components/IncentiveManage/IncentiveImport.vue"
import IncentiveSign from "/src/components/IncentiveManage/AwaitAction/IncentiveSign.vue"
import IncentiveClosing from "/src/components/IncentiveManage/AwaitAction/IncentiveClosing.vue"
import CompulsionSign from "/src/components/IncentiveManage/AwaitAction/CompulsionSign.vue"
import IncentiveProgress from "/src/components/IncentiveManage/IncentiveProgress.vue"
import PrintBulletin from "/src/components/IncentiveManage/PrintBulletin.vue"
import TipsSettings from "/src/components/IncentiveManage/SystemManage/TipsSettings.vue"
import SetAccordingDocument from "/src/components/IncentiveManage/SystemManage/SetAccordingDocument.vue"
import OrdinanceInput from "/src/components/IncentiveManage/SystemManage/OrdinanceInput.vue"
import OrdinanceImport from "/src/components/IncentiveManage/SystemManage/OrdinanceImport.vue"
import OrdinanceEnquiry from "/src/components/IncentiveManage/SystemManage/OrdinanceEnquiry.vue"
import PaperSetting from '/src/components/IncentiveManage/SystemManage/PaperSetting.vue'
//SER管理
import DispatchWorker from "/src/components/SER/TableManage/DispatchWorker.vue"
//健康管理系列
import AddHealth from "/src/components/HealthManagement/HealthInfo/AddHealth.vue"
//系统设置系列
import ImageSettings from '/src/components/SystemSettings/ImageSettings.vue'
import BulletinSetting from '/src/components/SystemSettings/BulletinSetting.vue'
import AddBulletin from '/src/components/SystemSettings/AddBulletin.vue'


//选中的选项卡
let SelectCard=ref()

//当前选项卡
const cmps=ref()

//标签页数据
let editableTabs = reactive([
  {
    title: '首页',
    name: '1',
    content: shallowRef(Default),
    closable:false
  }
])

//添加标签页
const addTabs = (title,componentName) => {
  //接收组件
  let cmp;
  //赋值组件
  switch(componentName){
    // #region 奖惩管理
    case "Application":
      cmp=Application
    break;
    case "AccordingDocument":
      cmp=According
    break;
    case "IncentiveImport":
      cmp=IncentiveImport
    break;
    case "IncentiveSign":
      cmp=IncentiveSign
    break;
    case "IncentiveClosing":
      cmp=IncentiveClosing
    break;
    case "CompulsionSign":
      cmp=CompulsionSign
    break;
    case "IncentiveProgress":
      cmp=IncentiveProgress
    break;
    case "PrintBulletin":
      cmp=PrintBulletin
    break;
    case "TipsSettings":
      cmp=TipsSettings
    break;
    case "SetAccordingDocument":
      cmp=SetAccordingDocument
    break;
    case "OrdinanceEnquiry":
      cmp=OrdinanceEnquiry
    break;
    case "OrdinanceInput":
      cmp=OrdinanceInput
    break;
    case "OrdinanceImport":
      cmp=OrdinanceImport
    break;
    // #endregion
    // #region SER管理
    case "DispatchWorker":
      cmp=DispatchWorker
    break;
    // #endregion
    // #region 系统设置
    case "ImageSettings":
      cmp=ImageSettings
    break;
    case "BulletinSetting":
      cmp=BulletinSetting
    break;
    case "AddBulletin":
      cmp=AddBulletin
    break;
    case "PaperSetting":
      cmp=PaperSetting
    break;
    // #endregion
    // #region 健康管理
    case "AddHealth":
      cmp=AddHealth
    break;
    // #endregion
  }
  
  //检索有无打开标签页，有则显示
  for(let i=0;i<editableTabs.length;i++){
    if(editableTabs[i].name===componentName){
      //切换选项卡
      SelectCard.value=componentName
      
      return
    }
  }
  
  //添加标签数据
  editableTabs.push({
    title: title,
    name: componentName ,
    content: shallowRef(cmp),
    closable:true,
  })

  //切换选择项卡
  SelectCard.value=componentName
}


//关闭
const removeTab = (targetName) => {
  for(let i=0;i<editableTabs.length;i++){
    if(editableTabs[i].name==targetName){
      editableTabs.splice(i,1)
    }
  }
}

const DefaultChange=inject('DefaultChange')

//宏暴露方法
defineExpose({addTabs,DefaultChange})


//获取router的query保存的navigation
const navigation=router.currentRoute.value.query.navigation

//获取路由打开当前标签页
switch (navigation){
  //default
  case "1":
    addTabs('',navigation)
  break;
  // #region 奖惩管理
  case "Application":
    addTabs('獎懲申請',navigation)
  break;
  case "AccordingDocument":
    addTabs('獎懲參考文件',navigation)
  break;
  case "IncentiveImport":
    addTabs('獎懲導入',navigation)
  break;
  case "IncentiveSign":
    addTabs('獎懲簽核',navigation)
  break;
  case "IncentiveClosing":
    addTabs('獎懲結案',navigation)
  break;
  case "CompulsionSign":
    addTabs('強制簽核',navigation)
  break;
  case "IncentiveProgress":
    addTabs('獎懲進度查詢',navigation)
  break;
  case "PrintBulletin":
    addTabs('列印公告單',navigation)
  break;
  case "TipsSettings":
    addTabs('溫馨提示設定',navigation)
  break;
  case "SetAccordingDocument":
    addTabs('參考文件設定',navigation)
  break;
  case "OrdinanceEnquiry":
    addTabs('獎懲條例查詢',navigation)
  break;
  case "OrdinanceInput":
    addTabs('獎懲條例單條添加',navigation)
  break;
  case "OrdinanceImport":
    addTabs('獎懲條例導入',navigation)
  break;
  // #endregion
  // #region SER管理
  case "DispatchWorker":
    addTabs('派遣工',navigation)
  break;
  // #endregion
  // #region 系统设置
  case "ImageSettings":
    addTabs('主頁輪播圖設置',navigation)
  break;
  case "BulletinSetting":
    addTabs('公告設置',navigation)
  break;
  case "AddBulletin":
    addTabs('添加公告',navigation)
  break;
  case "PaperSetting":
    addTabs('紙檔簽核設定',navigation)
  break;
  // #endregion
  // #region 健康管理
  case "AddHealth":
    addTabs('新增資訊',navigation)
  break;
  // #endregion
}

//切换标签页改变路由路径
const TbsLeave=(activeName, oldActiveName)=>{
  DefaultChange.value=activeName
  router.push({
    path:router.currentRoute.value.fullPath,
    query:{
      navigation:activeName
    }
  })
}


</script>
<style scoped>
.demo-tabs > .el-tabs__content {
  padding: 32px;
  color: #6b778c;
  font-size: 32px;
  font-weight: 600;
}
</style>