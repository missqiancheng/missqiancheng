<template>
  <el-upload :action="LoadAction" list-type="picture-card"
    v-model:file-list="fileList" method="get" :limit="MaxLinit"
    :auto-upload="false" :before-upload="handleSave" :on-exceed="replacement" ref="upload">
    <el-icon><Plus /></el-icon>
  </el-upload>
</template>

<script setup>
import { ref,reactive } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ServerPath } from '/src/Axios'


// #region 固定数据
//上传组件
const upload = ref()

//文件列表
const fileList=ref()

//上传路径
const LoadAction=ref(ServerPath+'IncentiveManage/FileTerminal')

//文件
let files

//最大上传数量
const MaxLinit=ref(1)

//
//超限制触发
const replacement=(RepFile,FileList)=>{
  FileList[0].uid=''
  FileList[0].name=RepFile[0].name
  FileList[0].percentage=''
  FileList[0].size=RepFile[0].size
  FileList[0].status='ready'
  let fileURL = URL.createObjectURL(RepFile[0]); 
  FileList[0].url=fileURL
  FileList[0].raw=RepFile[0]
}

//上传前
const handleSave=(rawFile)=>{
  files=rawFile
  return false
}
// #endregion


// #region 开放函数


//等待文件的个数
const FileLength=()=>{
  if(fileList.value===undefined){
    return 0
  }
  return fileList.value.length
}

//获取文件
const getfile=()=>{
  console.log(files)
  return files
}

//上传
const submitUpload = () => {
  upload.value.submit()
}

const ClearList=()=>{
  upload.value.clearFiles()
}
// #endregion


defineExpose({getfile,submitUpload,FileLength,ClearList})
</script>
  
<style>
.el-upload-list--picture-card{
  --el-upload-list-picture-card-size:80px;
}
.el-upload--picture-card{
  --el-upload-picture-card-size:80px;
}
</style>
