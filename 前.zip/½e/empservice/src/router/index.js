import {createRouter, createWebHistory, createWebHashHistory} from 'vue-router'
import { defineAsyncComponent } from 'vue'
import { CheckStore } from '/src/Axios'

const router = createRouter({ 
  history: createWebHashHistory(),  // hash 模式
  //history: createWebHistory(),  // history 模式
  routes: [
    {
      path: '/',
      name: 'Main',//异步引入，先加载父组件
      component:defineAsyncComponent(() => import(/*@vite-ignore*/`../pages/Home.vue`)),
      meta: {
        title: '首页',
        home:true,
      },
      children:[
        {
          path: '/Home',
          name: 'home',//异步引入，先加载父组件
          meta: {
            title: '首页',
            home:true,
          },
        },
        {
          path:'/EmpVoice',
          name:'EmpVoice',
          component:defineAsyncComponent(() => import(/*@vite-ignore*/`../components/EmpVoice/EmpVoiceASide.vue`)),
          meta:{
            title:'員工之聲',
            home:false,
          }
        },
        {
          path: '/IncentiveManage',
          name: 'IncentiveManage',
          component: defineAsyncComponent(() => import(/*@vite-ignore*/`../components/IncentiveManage/IncentiveManageASide.vue`)),
          meta: {
            title: '奖惩管理',
            home:false,
          }
        },
        {
          path:'/SER',
          name:'SER',
          component:defineAsyncComponent(() => import(/*@vite-ignore */`../components/SER/SERASide.vue`)),
          meta:{
            title:'SER管理',
            home:false,
          }
        },
        {
          path:'/EndDispatch',
          name:'EndDispatch',
          component:defineAsyncComponent(() => import(/*@vite-ignore */`../components/EndDispatch/EndDispatchASide.vue`)),
          meta:{
            title:'终止派遣管理管理',
            home:false,
          }
        },
        {
          path:'/Subsidy',
          name:'Subsidy',
          component:defineAsyncComponent(() => import(/*@vite-ignore */`../components/Subsidy/SubsidyASide.vue`)),
          meta:{
            title:'补贴管理',
            home:false,
          }
        },
        {
          path:'/FireDrill',
          name:'FireDrill',
          component:defineAsyncComponent(() => import(/*@vite-ignore */`../components/FireDrill/FireDrillASide.vue`)),
          meta:{
            title:'消防演习',
            home:false,
          }
        },
        {
          path:'/HealthManagement',
          name:'HealthManagement',
          component:defineAsyncComponent(() => import(/*@vite-ignore */`../components/HealthManagement/HealthManagementASide.vue`)),
          meta:{
            title:'健康管理',
            home:false,
          }
        },
        {
          path:'/SystemSetting',
          name:'SystemSetting',
          component:defineAsyncComponent(() => import(/*@vite-ignore */`../components/SystemSettings/SystemSettingASide.vue`)),
          meta:{
            title: '系統設置',
            home:false,
          },
          beforeEnter:(to,from,next)=>{
            const userType=localStorage.getItem('userType')
            if(userType==='3'||userType==='41'){
              next()
            }
            next('/Home')
          }
        },
      ]
    },
    {
      path: '/Login',
      name: 'Login',//异步引入，先加载父组件
      component:defineAsyncComponent(() => import(/*@vite-ignore*/`../pages/Login.vue`)),
      meta: {
        title: '登录',
        home:true,
      },
    },
    {
      path: '/Prints',
      name: 'Prints',//异步引入，先加载父组件
      component:defineAsyncComponent(() => import(/*@vite-ignore*/`../pages/Prints.vue`)),
      meta: {
        title: '打印',
        home:true,
      },
    },
    {
      path: '/*',
      redirect: '/',
    },
  ]
})


// 全局路由守卫
router.beforeEach(async(to, from, next)=>{
  if(!CheckStore()&&to.path !== '/Login'){
    next('/Login')
  }else{
    if(to.meta.title) document.title = `${to.meta.title}`;
    next()
  }
})

router.afterEach((to, from)=>{
})

export default router