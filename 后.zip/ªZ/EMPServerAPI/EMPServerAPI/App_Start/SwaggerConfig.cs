﻿using Swashbuckle.Application;
using System.Web.Http;
using WebActivatorEx;
using EMPServerAPI;

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace EMPServerAPI
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            var thisAssembly = typeof(SwaggerConfig).Assembly;

            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                {
                    //
                    c.SingleApiVersion("v1", "WebUI");

                    c.IncludeXmlComments(GetXmlCommentsPath());
                })
                .EnableSwaggerUi(c =>
                {

                });
        }
 
        protected static string GetXmlCommentsPath()
        {
            string a = string.Format(@"{0}\bin\EMPServerAPI.xml", System.AppDomain.CurrentDomain.BaseDirectory);
            return string.Format(@"{0}\bin\EMPServerAPI.xml", System.AppDomain.CurrentDomain.BaseDirectory);
        }
    }
}
