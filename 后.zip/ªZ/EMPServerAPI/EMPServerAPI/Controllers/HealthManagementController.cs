﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.DynamicData;
using System.Web.Http;
using EMPServerAPI.Models;
using EMPServerAPI.Models.Health;
using EMPServerAPI.Models.model;
using Infrastructure;
using Microsoft.International.Converters.TraditionalChineseToSimplifiedConverter;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace EMPServerAPI.Controllers
{
    public class HealthManagementController : ApiController
    {
        /// <summary>
        /// 获取健康公告
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HealthManagement/GetHealthArticle")]
        public HttpResponseMessage GetHealthArticle()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select healthno,articlesource,applicant,applicationtime,announcedtime,viewsnumber,articletitle" +
                ",articlecontent,applicationdepartment from CNSBGHR.tb_health where plant='" + token.plant
                + "' and status='已發佈'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 保存健康公告
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HealthManagement/Application")]
        public HttpResponseMessage Application(string Title,string Source,string Department)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            //单号
            string NumberNo = HealthNumber.Get(token.plant);
            //保存到本地
            Title = ChineseConverter.Convert(Title, ChineseConversionDirection.SimplifiedToTraditional);
            string paths = AppDomain.CurrentDomain.BaseDirectory + "File_Manager/Health/" + DateTime.Now.ToString("yyyyMMdd");
            Directory.CreateDirectory(paths);
            paths += "/" + Title + ".txt";
            string Content = HttpContext.Current.Request.Form["Content"];
            string Contexts = Uri.UnescapeDataString(Content);
            SaveFile.SavaText(paths, Contexts);
            //同步到服务器
            string[] filenames = new string[1];
            Stream[] stream = new Stream[1];
            filenames[0] = Title + ".txt";
            stream[0] = new FileStream(paths, FileMode.Open, FileAccess.Read);

            ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>
                (HttpRequests.UploadRequest("EMPServer/Health", stream, filenames));


            string sql = "insert into CNSBGHR.Tb_health values('" + NumberNo + "','" + Source + "','" + token.Emp 
                + "',sysdate,null,0,'" + Title + "','" + codes.Data[filenames[0]] + "','待發佈','" + 
                token.plant + "','" + Department + "')";

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 获取待送签的健康公告
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HealthManagement/GetAwaitInfo")]
        public HttpResponseMessage GetAwaitInfo()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select * from CNSBGHR.tb_health where applicant='" + token.Emp + "'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 送签公告单
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HealthManagement/SendSigner")]
        public HttpResponseMessage SendSigner(string HealthNo)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string[] Leader = DBHelper.Queues("select tl.f_allmanager from tb_employe te,tb_leader_redirect tl where " +
                "te.f_empno=tl.f_empno and te.f_empno='" + token.Emp + "'", token.plant).Rows[0][0].ToString().Split(';');
            
            string sql = "update CNSBGHR.tb_health set status='待簽核',signer='"+ Leader[0] 
                + "' where healthno='" + HealthNo + "'";

            string wWd = "liangdianban.hai";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Data = DBHelper.Inserts(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 删除公告单
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HealthManagement/DeleteArticle")]
        public HttpResponseMessage DeleteArticle(string HealthNo)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sql = "delete CNSBGHR.tb_health where healthno='" + HealthNo + "'";
            
            
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Data = DBHelper.Inserts(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
    }
}