﻿using EMPServerAPI.Models;
using EMPServerAPI.Models.model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace EMPServerAPI.Controllers
{
    
    public class HomeController : Controller
    {
        // GET: Home
        public String Index()
        {
            return "默认路径";
        }
    }
}