﻿using EMPServerAPI.Models.model;
using EMPServerAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json.Converters;
using System.IO;
using System.Data;
using NPOI.SS.Formula.Functions;
using System.Text;
using Infrastructure;
using EMPServerAPI.FIleManage;
using Microsoft.International.Converters.TraditionalChineseToSimplifiedConverter;

namespace EMPServerAPI.Controllers
{
    public class HomePagesController : ApiController
    {
        #region tabs首页
        /// <summary>
        /// 获取员工信息
        /// </summary>
        /// <param name="empno">工号</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/GetEmpInfo")]
        public HttpResponseMessage GetEmpInfo(string empno)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
            };
            if(empno == "sys")
            {
                code.Message = "该账号为系统账号";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            string sql = "select userid,ipaddress,createdate,emp.f_empno,emp.f_name,emp.f_manage,emp.f_departname,emp.f_telephone," +
                "emp.f_ext,emp.f_email,emp.f_artificial,emp.f_province,f_infactorydate from log_user logs,tb_employe emp where " +
                "emp.f_empno=logs.userid and detail='登陸成功' and emp.f_empno='" + empno + "' and createdate=(select MAX(createdate) " +
                "from log_user where detail='登陸成功' and userid='" + empno + "')";
            code.Data = DBHelper.Queues(sql, token.plant);
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
        #endregion


        #region 轮播图
        /// <summary>
        /// 获取轮播图片
        /// </summary>
        /// <returns>轮播图数据</returns>
        [Token]
        [HttpPost]
        [Route("HomePages/GetShowImage")]
        public HttpResponseMessage GetShowImage()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sql = "select imagepath,showide,imagename,iamgedetails from CNSBGHR.EMPSERVER_SHOWIMAGE where showide is not null";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 获取轮播图所有保存过的图片
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/GetImage")]
        public HttpResponseMessage GetImage()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sql = "select id, imagename, showide, imagepath,iamgedetails from CNSBGHR.EMPSERVER_SHOWIMAGE";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 上传轮播图
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/LoadImage")]
        public HttpResponseMessage LoadImage(string filename,string content)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            try
            {
                //获取图片文件
                HttpFileCollection file = HttpContext.Current.Request.Files;
                string[] filenames = new string[file.Count];
                Stream[] stream = new Stream[file.Count];
                for (int i = 0; i < file.Count; i++)
                {
                    filenames[i] = file[i].FileName;
                    stream[i] = file[i].InputStream;
                }
                ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>
                    (HttpRequests.UploadRequest("EMPServer/ShowImage", stream, filenames));
                string index = DBHelper.Queues("select MAX(ID) from CNSBGHR.EMPSERVER_SHOWIMAGE",
                    token.plant).Rows[0][0].ToString();
                
                if (index == "")
                {
                    index = "0";
                }

                string sql = "insert into CNSBGHR.EMPSERVER_SHOWIMAGE values(" + index + "+1" +
                      ",'" + filename + "','" + codes.Data[filenames[0]] + "',null,'" + content + "')";

                ReturnCode code = new ReturnCode()
                {
                    Code = "200",
                    Message = "成功",
                    Data = DBHelper.Queues(sql, token.plant)
                };
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            catch(Exception ex)
            {
                ReturnCode code = new ReturnCode()
                {
                    Code = "200",
                    Message = ex.Message,
                    Data = ex.Message
                };
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }

        }
        /// <summary>
        /// 删除轮播图
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/DeleteImage")]
        public HttpResponseMessage DeleteImage(string id)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string filepath = DBHelper.Queues("select imagepath from CNSBGHR.EMPSERVER_SHOWIMAGE where id=" + id, token.plant).Rows[0][0].ToString();
            FileManageSoapClient filemange = new FileManageSoapClient();
            filemange.DeleteFile(filepath);

            string sql = "delete CNSBGHR.EMPSERVER_SHOWIMAGE where id=" + id;

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 设置播放顺序
        /// </summary>
        /// <param name="id">图片</param>
        /// <param name="order">播放位置</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/SettingOrder")]
        public HttpResponseMessage SettingOrder(string id,string order)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            if (order == "0")
            {
                order = null;
            }
            string sql = "update CNSBGHR.EMPSERVER_SHOWIMAGE set showide='" + order + "' where id=" + id;
            
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        #endregion
        

        #region 重要公告
        /// <summary>
        /// 写公告
        /// </summary>
        /// <param name="title">标题</param>
        /// <param name="Context">内容</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/WriteBullerin")]
        public HttpResponseMessage WriteBullerin(string title)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            title = ChineseConverter.Convert(title, ChineseConversionDirection.SimplifiedToTraditional);
            //保存到本地
            string paths = AppDomain.CurrentDomain.BaseDirectory + "File_Manager/Bullerin/" + DateTime.Now.ToString("yyyyMMdd");
            Directory.CreateDirectory(paths);
            paths += "/" + title + ".txt";
            string Content = HttpContext.Current.Request.Form["Content"];
            string Contexts = Uri.UnescapeDataString(Content);
            SaveFile.SavaText(paths, Contexts);
            //同步到服务器
            string[] filenames = new string[1];
            Stream[] stream = new Stream[1];
            filenames[0] = title + ".txt";
            stream[0] = new FileStream(paths, FileMode.Open, FileAccess.Read);

            ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>
                (HttpRequests.UploadRequest("EMPServer/Bullerin", stream, filenames));

            string sql = "insert into CNSBGHR.EMPSERVER_Bulletin values((select coalesce(MAx(id),0) from CNSBGHR.EMPSERVER_Bulletin)+1," +
                "'" + title + "','" + codes.Data[filenames[0]] + "','" + token.Emp + "',sysdate)";

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)

            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 获取公告
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/GetBulletin")]
        public HttpResponseMessage GetBulletin()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sql = "select id,title,editdate,contextfile from CNSBGHR.EMPSERVER_Bulletin order by editdate desc";
            DataTable dt = DBHelper.Queues(sql, token.plant);
            
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = dt
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code,new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 获取设置公告信息
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/GetSettingBulletin")]
        public HttpResponseMessage GetSettingBulletin()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sql = "select id,title,editdate,editemp,contextfile from CNSBGHR.EMPSERVER_Bulletin order by editdate desc";
            DataTable dt = DBHelper.Queues(sql, token.plant);
            
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = dt
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
        /// <summary>
        /// 删除公告信息
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/DeleteBulletin")]
        public HttpResponseMessage DeleteBulletin(string id)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sql = "select contextfile from CNSBGHR.EMPSERVER_Bulletin where id=" + id;
            string path = DBHelper.Queues(sql, token.plant).Rows[0][0].ToString();

            //删除存储公告的文件
            FileManageSoapClient filemange = new FileManageSoapClient();
            filemange.DeleteFile(path);


            string Deletes = "delete CNSBGHR.EMPSERVER_Bulletin where id=" + id;
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(Deletes, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
        /// <summary>
        /// 上传公告文件
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("HomePages/LoadBulletinFile")]
        public HttpResponseMessage LoadBulletinFile()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            Dictionary<string,string> dic = SaveFile.fileUploads("");

            string path = Environment.CurrentDirectory;
            foreach (var item in dic.Keys)
            {
                path += dic[item];
            }

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = path
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }

        #endregion


        [Token]
        [HttpPost]
        [Route("HomePages/CEshi")]
        public HttpResponseMessage CEshi()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string[] path = new string[] { "imgtest.txt" };
            
            FileStream[] filestream = new FileStream[1];
            FileStream fs = new FileStream("D:\\ce\\1234.txt", FileMode.Open);
            filestream[0] = fs;
            string Reponse=HttpRequests.UploadRequest("cshi", filestream, path);
            fs.Close();
            ReturnCode FilesPath = JsonConvert.DeserializeObject<ReturnCode>(Reponse);
            Console.WriteLine("ces");
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = FilesPath.Data[path[0]]
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
    }
}
