﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Policy;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Http.Results;
using System.Web.Mvc.Ajax;
using System.Web.Routing;
using System.Web.Script.Serialization;
using System.Web.Services.Description;
using EMPServerAPI.Models;
using EMPServerAPI.Models.Incentive;
using EMPServerAPI.Models.model;
using EMPServerAPI.WorkFlow;
using Infrastructure;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using SixLabors.ImageSharp.Formats.Jpeg;
using EMPServerAPI.FIleManage;
using EMPServerAPI.ElistQuery;
using MathNet.Numerics.Distributions;
using Org.BouncyCastle.Bcpg.OpenPgp;
using static Microsoft.IO.RecyclableMemoryStreamManager;
using EMPServerAPI.OHSMS_Medical;
using System.ServiceModel.Channels;
using NPOI.SS.Formula.Functions;
using Microsoft.International.Converters.TraditionalChineseToSimplifiedConverter;
using NPOI.XSSF.Model;


namespace EMPServerAPI.Controllers
{
    public class IncentiveManageController : ApiController
    {
        #region 测试接口
        [Route("IncentiveManage")]
        [HttpGet]
        public String Index()
        {
            return "ssdd;";
        }

        /// <summary>
        /// 文件接收终点
        /// </summary>
        /// <param name="request">接收的文件</param>
        /// <returns></returns>
        [HttpGet]
        [Route("IncentiveManage/FileTerminal")]
        public string FileTerminal(HttpRequestMessage request)
        {
            return "完成";
        }
        #endregion


        #region 奖惩参考文件系列
        #region 奖惩参考文件页面接口
        /// <summary>
        /// 获取下载参考文件数据
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/AccordingDocument")]
        public HttpResponseMessage AccordingDocument()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Data = DBHelper.Queues("select id,name,file_name,f_type,f_effectdate,loadtime from tb_jc_book order by f_effectdate desc", token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
        #endregion

        #region 参考文件设定页面接口
        /// <summary>
        /// 获取所有参考文件数据
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/AllDocumentData")]
        public HttpResponseMessage AllDocumentData()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Data = DBHelper.Queues("select id,name,file_name,f_type,loadtime,loademp,f_effectdate from tb_jc_book order by id", token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
        /// <summary>
        /// 删除参考文件数据
        /// </summary>
        /// <param index="index">索引</param>
        /// <param Path="Path">文件下载路径</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/DeleteDocument")]
        public HttpResponseMessage DeleteDocument(int index,string Path)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode();

            FileManageSoapClient filemanage = new FileManageSoapClient();
            
            filemanage.DeleteFile(Path);

            DBHelper.Inserts("delete from tb_jc_book where id=" + index, token.plant);
            code.Code = "200";
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 添加参考文件数据
        /// </summary>
        /// <param filename="filename">文件名</param>
        /// <param filetype="filetype">文件类型</param>
        /// <param effectdate="effectdate">生效日期</param>
        /// <param file="file">文件</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/AddDocument")]
        public HttpResponseMessage AddDocument(string filename, string filetype,DateTime effectdate)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode();
            //同步文件
            var files = HttpContext.Current.Request.Files;
            string[] FileName = new string[files.Count];
            Stream[] FileStream = new Stream[files.Count];
            for (int i = 0; i < files.Count; i++)
            {
                FileName[i] = files[i].FileName;
                FileStream[i] = files[i].InputStream;
            }
            //请求
            string FilePath = HttpRequests.UploadRequest("EMPServer/AccordingDocument", FileStream, FileName);
            if (FilePath == null)
            {
                code.Code = "500";
                code.Message = "没有上传文件！";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }

            ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>(FilePath);
            string sql = "insert into tb_jc_book values((select Max(id) from tb_jc_book)+1,'" + filename + "','" + 
                codes.Data[FileName[0]] + "','" + filetype + "',sysdate,'" + token.Emp + "'," +
                "to_date('" + effectdate.ToString("yyyy/MM/dd") + "','yyyy-mm-dd') )";
            if (DBHelper.Inserts(sql, token.plant) > 0)
            {
                code.Code = "200";
                code.Message = "上传成功";
                code.Data = FilePath;
            }
            else
            {
                code.Code = "500";
                code.Message = "";
            }
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        #endregion

        #region 单条添加奖惩依据页面接口
        /// <summary>
        /// 单条奖惩条例添加
        /// </summary>
        /// <param name="f_jcitemtype">参考文件</param>
        /// <param name="f_jctl">条例</param>
        /// <param name="f_jcitemcontent">条例内容</param>
        /// <param name="f_jcdj">奖惩等级</param>
        /// <param name="f_jctype">奖惩类型</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/AddOrdinance")]
        public HttpResponseMessage AddOrdinance(string f_jcitemtype, string f_jctl, string f_jcitemcontent, string f_jcdj, string f_jctype)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode();
            string queues = "select count(*) from tb_jc_item where f_jcitemtype='"+ f_jcitemtype + "' and f_jctl='"+ f_jctl + "'";
            if (int.Parse(DBHelper.Queues(queues, token.plant).Rows[0][0].ToString())>0)
            {
                code.Code = "500";
                code.Message = "有相同的条例";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            //日期+0000
            string time=DateTime.Now.ToString("yyyyMMddHHmmss") + "0001";
            string sql = "insert into tb_jc_item values('"+ time + "','"+ f_jcitemtype + "','"+ f_jctl + "','"+ f_jcitemcontent + "','"+ f_jcdj + "','"+ f_jctype + "','"+token.Emp+"',sysdate,'Y')";
            if (DBHelper.Inserts(sql, token.plant) <1)
            {
                code.Code = "500";
                code.Message = "添加失败";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            code.Code = "200";
            code.Message = "添加成功";
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 奖惩依据单条表单信息
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/OrdinanceInputInfo")]
        public HttpResponseMessage OrdinanceInputInfo()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode();
            code.Code = "200";
            code.Data = new DataSet();
            DataTable book = DBHelper.Queues("select name as book_name from tb_jc_book", token.plant);
            DataTable dj = DBHelper.Queues("select name as dj_name from tb_jc_dj", token.plant);
            DataTable type = DBHelper.Queues("select name as type_name from tb_jc_type", token.plant);
            book.TableName = "book";
            dj.TableName = "dj";
            type.TableName = "type";
            code.Data.Tables.Add(book);
            code.Data.Tables.Add(dj);
            code.Data.Tables.Add(type);
            
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        #endregion

        #region 导入奖惩依据页面接口
        /// <summary>
        /// execl导入奖惩依据
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/ImportsOrdinance")]
        public HttpResponseMessage ImportsOrdinance()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode();
            string SavePath = AppDomain.CurrentDomain.BaseDirectory + "\\File_Manager\\Incentive\\Ordinance\\";
            Dictionary<string, string> FileName = SaveFile.fileUploads(SavePath, ".XLSX");
            if (FileName == null)
            {
                code.Code = "500";
                code.Message = "没有上传文件，或文件不符合格式"+ HttpContext.Current.Request.Files.Count;
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            //委托check方法
            Imports.CheckImport check = new Imports.CheckImport(OrdinanceImport.CheckData);
            //调用导入
            string Message = Imports.ImportExcel(SavePath + FileName[HttpContext.Current.Request.Files[0].FileName + 0], check, token);
            if (Message != "执行成功")
            {
                code.Code = "500";
                code.Message = Message;
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            code.Code = "200";
            code.Message = "导入成功";
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        #endregion

        #region 奖惩条例查询页面接口
        /// <summary>
        /// 获取所有奖惩条例数据
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetOrdinance")]
        public HttpResponseMessage GetOrdinance()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select * from tb_jc_item";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
            };
            DataTable dt = DBHelper.Queues(sql, token.plant);
            DataTable newdt = dt.Clone();
            newdt.Columns["F_JCITEMNO"].DataType=typeof(string);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                newdt.ImportRow(dt.Rows[i]);
            }
            code.Data = newdt;
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
        /// <summary>
        /// 删除单条奖惩条例
        /// </summary>
        /// <param name="f_jcitemno">奖惩条例单号</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/DeleteOrdinance")]
        public HttpResponseMessage DeleteOrdinance(string f_jcitemno)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "delete from tb_jc_item where f_jcitemno='"+f_jcitemno+"'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = new DataSet()
            };
            if (DBHelper.Inserts(sql, token.plant) <1)
            {
                code.Code = "500";
                code.Message = "执行失败";
            }
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 删除多条奖惩条例
        /// </summary>
        /// <param name="f_jcitemnos">奖惩条例单号</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/DeleteOrdinances")]
        public HttpResponseMessage DeleteOrdinances(string f_jcitemnos)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string[] f_jcitemno = JsonConvert.DeserializeObject<string[]>(f_jcitemnos);
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = new DataSet()
            };
            if (f_jcitemno == null)
            {
                code.Code = "500";
                code.Message = "参数为空";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            string sql = "delete from tb_jc_item where f_jcitemno='" + f_jcitemno[0] + "'";
            for(int i = 1; i < f_jcitemno.Length; i++)
            {
                sql += " or f_jcitemno='" + f_jcitemno[i] +"'";
            }
            if (DBHelper.Inserts(sql, token.plant) < 1)
            {
                code.Code = "500";
                code.Message = "执行失败";
            }
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }

        #endregion

        #endregion


        #region 温馨提示系列
        /// <summary>
        /// 获取温馨提示信息
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetTips")]
        public HttpResponseMessage GetTips()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select f_value from tb_parameter  where f_name='JC Tips'";
            string AllTips = DBHelper.Queues(sql, token.plant).Rows[0][0].ToString();
            Dictionary<int, string> tips = new Dictionary<int, string>();
            int i = 1;
            while (AllTips.Contains(i + "."))
            {
                int EndInedx = 0;
                int BeginIndex = 0;
                if (i == 1)
                {
                    BeginIndex = 2;
                    if (AllTips.Contains(i+1 + "."))
                        EndInedx = AllTips.IndexOf(i + 1 + ".") - 2;
                    else
                        EndInedx = AllTips.Length - 2;
                }
                else
                {
                    BeginIndex = AllTips.IndexOf(i + ".") + 2;
                    if (AllTips.Contains(i + 1 + "."))
                        EndInedx = AllTips.IndexOf(i + 1 + ".") - (AllTips.IndexOf(i + ".") + 2);
                    else
                        EndInedx = AllTips.Length - (AllTips.IndexOf(i + ".") + 2);
                }
                tips.Add(i, AllTips.Substring(BeginIndex, EndInedx));
                i++;
            }
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = tips
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 保存温馨提示
        /// </summary>
        /// <param name="Tips">温馨提示</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/SaveTips")]
        public HttpResponseMessage SaveTips(string Tips)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "update tb_parameter set f_value='"+ Tips + "' where f_name='JC Tips'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
            };
            if (DBHelper.Inserts(sql, token.plant)<0)
            {
                code.Code = "500";
                code.Message = "失败";
            }
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }

        #endregion


        #region 奖惩申请系列
        #region 单条奖惩申请页面接口
        /// <summary>
        /// 通过工号获取员工信息-员工年度奖惩信息
        /// </summary>
        /// <param name="empno">工号</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetEmpInfo")]
        public HttpResponseMessage GetEmpInfo(string empno)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = new DataSet()
            };
            if(token.permissions !="3" && token.permissions != "41" && empno != token.Emp)
            {
                string LeaderSql = "select te.f_empno,te.f_name,tl.f_allmanager,F_EmpLevel from tb_employe te," +
                    "tb_leader_redirect tl where te.f_empno=tl.f_empno and te.f_empno='" + empno + "'";
                bool Leaders = DBHelper.Queues(LeaderSql, token.plant).Rows[0][2].ToString().Contains(token.Emp);
                if (!Leaders)
                {
                    code.Code = "500";
                    code.Message = "该工号不在您的权限范围内";
                    return Jsons.JsonData(JsonConvert.SerializeObject(code,
                    new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
                }
            }else if (token.permissions == "41")
            {
                string LeaderSql = "select f_empno from tb_employe where f_empno='" + empno + "' and " +
                    "f_plantno=(select f_plantno from TB_HRWindow where f_empno='" + token.Emp + "')";
                int Leaders = DBHelper.Queues(LeaderSql, token.plant).Rows.Count;
                if (Leaders == 0)
                {
                    code.Code = "500";
                    code.Message = "该工号不在您的权限范围内";
                    return Jsons.JsonData(JsonConvert.SerializeObject(code,
                    new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
                }
            }

            string sql = "select f_empno,f_name,f_grand,f_departname,f_infactorydate,f_emptype_use from tb_employe where f_empno='" + empno.ToUpper()+"'";
            DataTable empinfo = DBHelper.Queues(sql, token.plant);
            if (empinfo.Rows.Count < 1)
            {
                code.Code = "500";
                code.Message = "工号不正确";
            }
            string Apply = "select * from tb_jc_apply where jc_dj='開除' and status!='已取消' and emp_no='"+ empno +"'";
            DataTable Applys = DBHelper.Queues(Apply, token.plant);
            if (Applys.Rows.Count > 0)
            {
                code.Code = "500";
                code.Message = "該員已提報開除";
            }
            Apply = "select f_empno,f_iscancel from tb_dimission where  f_empno='" + empno + "' and f_iscancel = 'N' " +
                "union all select f_empno, f_iscancel from tb_autodimission where f_empno = '" + empno + "' and f_iscancel = 'N'";
            Applys = DBHelper.Queues(Apply, token.plant);
            if (Applys.Rows.Count > 0)
            {
                code.Code = "500";
                code.Message = "該員工已提報離職";
            }

            
            sql = "select f_occurdate,jc_dj from tb_jc_apply where emp_no='"+ empno.ToUpper() + "' and time_year=to_char(sysdate,'yyyy')" +
                " and (status='已於原單位結案' or status='已公告' or status='已結案')";
            DataTable yearIncentive = DBHelper.Queues(sql, token.plant);

            empinfo.TableName = "EmpInfo";
            yearIncentive.TableName = "YearIncentive";
            code.Data.Tables.Add(empinfo);
            code.Data.Tables.Add(yearIncentive);
            return Jsons.JsonData(JsonConvert.SerializeObject(code,
                new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
        }
        /// <summary>
        /// 获取奖惩依据
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/IncentiveDocument")]
        public HttpResponseMessage IncentiveDocument(DateTime f_occurdate)
        {//tb_jc_book where f_effectdate<
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select name from tb_jc_book bc where bc.f_effectdate=(select Max(f_effectdate) from tb_jc_book " +
                "where f_effectdate<to_date('" + f_occurdate.ToString("yyyy/MM/dd") + "','yyyy-mm-dd') and bc.f_type=f_type group by f_type)";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 根据奖惩依据获取奖惩条例
        /// </summary>
        /// <param name="jc_yj">奖惩依据</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetOrdinace")]
        public HttpResponseMessage GetOrdinace(string jc_yj)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select f_jcitemno,f_jcitemtype,f_jctl,f_jcitemcontent,f_jcdj," +
                "f_jctype from tb_jc_item where f_jcitemtype='"+jc_yj+"'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 获取旷工时间
        /// </summary>
        /// <param name="f_empno"></param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetAbsenteeism")]
        public HttpResponseMessage GetAbsenteeism(string f_empno)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sqlInfo = "select f_emptype_use from tb_employe where f_emptype_use='派遣工' and f_empno='" + f_empno + "'";
            DataTable empinfo = DBHelper.Queues(sqlInfo, token.plant);
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
            };
            if (empinfo.Rows.Count > 0)
            {
                code.Code = "500";
                code.Message = "該員為派遣工不能提報離職";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            string sql = "select f_empno,f_dutydate,f_modifyresult,f_daytype from tb_analyse where f_empno='" + f_empno + "' and " +
                "f_dutydate<=to_char(sysdate-1,'yyyy/MM/dd') and f_dutydate>=to_char(add_months(sysdate,-4),'yyyy/MM/dd') and " +
                "f_modifyresult='曠工E' and f_beginwork is null and f_beginrest is null and f_endrest is null and f_endwork is null " +
                "and f_daytype='G1' order by f_dutydate";
            DataTable dt = DBHelper.Queues(sql, token.plant);
            string absenteeismdate = "";
            if (dt.Rows.Count > 3 || AddDcoument.CheckAbsent(dt))
            {
                if (AddDcoument.CheckAbsent(dt)) absenteeismdate = dt.Rows[0]["F_DUTYDATE"].ToString() + "~" + dt.Rows[2]["F_DUTYDATE"].ToString();
                else absenteeismdate = dt.Rows[0]["F_DUTYDATE"].ToString() + "," + dt.Rows[1]["F_DUTYDATE"].ToString()
                        + "," + dt.Rows[2]["F_DUTYDATE"].ToString();
            }
            code.Data = absenteeismdate;
            if (absenteeismdate == "")
            {
                code.Code = "500";
                code.Message = "該員工不符合曠工條件";
            }
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 判断该员工是否为职业健康体检，有则返回离职体检详细情况
        /// </summary>
        /// <param name="f_empno"></param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetEmpFind")]
        public HttpResponseMessage GetEmpFind(string f_empno)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            OHSMS_MedicalSoapClient ohs = new OHSMS_MedicalSoapClient();
            DataTable infoDT = ohs.FindCauseHarm_ByEmpNo(f_empno).Tables[0];
            string info =  infoDT.Rows.Count > 0 ? infoDT.Rows[0]["Cause_Harm"].ToString() : "";
            DataTable dt = ohs.FindMedicalInfo_ByEmpNo(f_empno, "離崗體檢").Tables[0];

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = info,
                Data = dt
            };
            if (!SendMail.Judgement(f_empno))
            {
                code.Message = "";
                code.Data = "";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 单条申请奖惩单
        /// </summary>
        /// 1<param name="emp_no">工号</param>
        /// 2<param name="name">姓名</param>
        /// 3<param name="duty">当担</param>
        /// 4<param name="tbr">提报人工号</param>
        /// 5<param name="tbr_tel">提报人电话</param>
        /// 6<param name="f_occurdate">发生日期</param>
        /// 7<param name="f_jcitemno">奖惩依据单号</param>
        /// 8<param name="jc_yj">奖惩依据</param>
        /// 9<param name="jc_tl">奖惩条例</param>
        /// 10<param name="f_jcitemcontent">奖惩内容</param>
        /// 11<param name="jc_dj">奖惩等级</param>
        /// 12<param name="jc_type">奖惩类型</param>
        /// 13<param name="remark">奖惩原由</param>
        /// 14<param name="f_changetype">是否变更处理类别</param>
        /// 15<param name="f_jcdj_new">变更等级</param>
        /// 16<param name="f_changereason">变更原由</param>
        /// 17<param name="absenteeismdate">旷工日期</param>
        /// 18<param name="f_delistype">開除类型</param>
        /// 19<param name="ApplicationType">人资申请类型</param>
        /// 19<param name="f_isspecialstation">是否职业健康监督岗位</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/ApplicationIncentive")]
        public HttpResponseMessage ApplicationIncentive(string emp_no, string name, string duty, string tbr, string tbr_tel,
            DateTime f_occurdate,string f_jcitemno,string jc_yj, string jc_tl, string f_jcitemcontent, string jc_dj, string jc_type, 
            string remark,string f_changetype,string f_jcdj_new, string f_changereason, string absenteeismdate,
            string f_delistype, string ApplicationType,string f_isspecialstation)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            try
            {
                if (f_changetype == "true")
                {
                    f_changetype = "是";
                }
                else
                {
                    f_changetype = "否";
                }
                //保存文件
                string file_name = null;
                string hr_file_name = null;
                var files = HttpContext.Current.Request.Files;
                if (files.Count > 0)
                {
                    string[] filenames = new string[files.Count];
                    Stream[] FileStreams = new Stream[files.Count];
                    for (int i = 0; i < files.Count; i++)
                    {
                        filenames[i] = files[i].FileName;
                        FileStreams[i] = files[i].InputStream;
                    }
                    ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>
                        (HttpRequests.UploadRequest("EMPServer/Incentive", FileStreams, filenames));
                    file_name = codes.Data[filenames[0]];
                    hr_file_name = (files.Count > 1) ? codes.Data[filenames[1]] : "";
                }

                //获取单号
                AddDcoument dco = new AddDcoument(token.plant);
                string applyno = dco.GetApply(token.plant);
                string LeaderJson = "";
                //创建workflow
                if (ApplicationType != "紙檔簽核" && ApplicationType != "調前記錄")
                {
                    LeaderJson = WorkFlows.CreateIncentive(applyno, token.Emp, emp_no, token.plant, jc_dj, f_changetype);
                }

                //生成单号，和sql语句
                (string sqls, string signemp) = AddDcoument.AddIncentive(applyno, emp_no, name, duty, token.Emp, tbr_tel, remark,
                    file_name, jc_yj, jc_tl, jc_dj, jc_type, hr_file_name, f_occurdate, f_delistype, f_jcitemno,
                    f_jcitemcontent, absenteeismdate, f_changetype, f_jcdj_new, f_changereason, LeaderJson, ApplicationType, f_isspecialstation);
                string sql = "insert into tb_jc_apply (apply_no,emp_no,name,duty,tbr,tbr_tel,remark,file_name,jc_yj,jc_tl,jc_dj," +
                    "jc_type,edittime,hr_check,signer,signertype,agent,signtime,status,is_upload,time_year,year_no,jc_dj_type," +
                    "hr_file_name,f_occurdate,f_isspecialstation,f_delistype,f_jcitemno,f_jcitemcontent,f_absentdate,f_changetype," +
                    "f_jcdj_new,f_changereason,leaderjson) " + sqls;

                sql = "begin " + sql + ";" +
                    "insert into tb_signhistory_jc values('" + applyno + "','" + tbr + "','','','" + jc_dj +
                    "','申請提交','申请人',sysdate,''); end;";
                SendMail sends = new SendMail();
                string Result = sends.SignMail(signemp).Result;
                if (jc_dj == "開除" && SendMail.Judgement(emp_no))
                {
                    string F_emp = DBHelper.Queues("select F_value from tb_parameter " +
                        "where f_remark='環安職業健康體檢' ", token.plant).Rows[0][0].ToString();
                    OHSMS_MedicalSoapClient ohs = new OHSMS_MedicalSoapClient();
                    if (ohs.FindCauseHarm_ByEmpNo(emp_no).Tables[0].Rows.Count > 0 )
                    {
                        Result = sends.PhysicalExaminationMail(F_emp, emp_no
                            , name).Result;
                    }

                }
                ReturnCode code = new ReturnCode()
                {
                    Code = "200",
                    Message = "成功"+ LeaderJson,
                    Data = DBHelper.Inserts(sql, token.plant)
                };
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            catch(Exception e)
            {
                ReturnCode code = new ReturnCode()
                {
                    Code = "200",
                    Message = "成功",
                    Data = e.Message
                };
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
        }
        #endregion

        #region 奖惩申请单导入页面接口
        /// <summary>
        /// 导入奖惩单
        /// </summary>
        /// <param name="JsonData">导入Json数据</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/ImportIncentive")]
        public HttpResponseMessage ImportIncentive(string JsonData)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            DataTable FormTable = JsonConvert.DeserializeObject<DataTable>(JsonData);
            //同步文件到服务器
            var files = HttpContext.Current.Request.Files;
            string[] filenames = new string[files.Count];
            Stream[] filestream = new Stream[files.Count];
            for(int i=0;i<files.Count; i++)
            {
                filenames[i] = files[i].FileName;
                filestream[i] = files[i].InputStream;
            }
            ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>
                (HttpRequests.UploadRequest("EMPServer/Incentive", filestream, filenames));
            //workflow
            WorkFlows works = new WorkFlows(token.plant);
            //check人资
            bool txtHR = WorkFlows.HRDB.AsEnumerable().Where(s => s.Field<string>("F_PLANTNO") == token.plant).
                    Where(a => a.Field<string>("F_EmpNo") == token.Emp).Count() > 0;//获取HR是否HR申请
            //不合格数据记录
            Dictionary<int, string> ErrorDic = new Dictionary<int, string>();
            //check
            string sqls = "" ,historysql = "";
            //签核人
            string[] signsName=new string[FormTable.Rows.Count];
            ReturnCode code = new ReturnCode();
            Dictionary<string,string> LeaderDic = new Dictionary<string, string>();
            AddDcoument doc = new AddDcoument(token.plant);
            if (token.permissions != "41" || token.permissions != "3")
            {
                DataTable dts = DBHelper.Queues("select te.f_empno,tl.f_allmanager from tb_employe te," +
                    "tb_leader_redirect tl where te.f_empno=tl.f_empno", token.plant);
                for(int i = 0; i < dts.Rows.Count; i++)
                {
                    LeaderDic.Add(dts.Rows[i][0].ToString(), dts.Rows[i][1].ToString());
                }
            }
            for (int i = 0; i < FormTable.Rows.Count; i++)
            {
                //1.单号
                string applyno = doc.GetApply(token.plant);
                //2.工号
                string emp_no = FormTable.Rows[i]["emp_no"].ToString();
                if (token.permissions != "41" && token.permissions != "3")
                {
                    if (!LeaderDic[emp_no].Contains(token.Emp))
                    {
                        ErrorDic.Add(i + 1, "当前账号没有提报该工号权限！");
                        continue;
                    }
                }
                //3.姓名
                string name = FormTable.Rows[i]["name"].ToString();
                //check工号姓名
                if(WorkFlows.EMPDB.AsEnumerable().Where(s => s.Field<string>("F_EMPNO") == emp_no).
                    Where(a => a.Field<string>("F_NAME") == name).Count()<1)
                {
                    ErrorDic.Add(i+1,"工号和姓名不匹配");
                    continue;
                }
                //4.当担
                string duty = FormTable.Rows[i]["duty"].ToString();
                //5.电话
                string tbr_tel = FormTable.Rows[i]["tbr_tel"].ToString();
                //6.原因
                string remark = FormTable.Rows[i]["remark"].ToString();
                //7.文件名
                string file_name = (FormTable.Columns.Contains("file_name")) ? FormTable.Rows[i]["file_name"].ToString() : "";
                //8.奖惩依据
                string jc_yj = FormTable.Rows[i]["jc_yj"].ToString();
                //9.奖惩条例
                string jc_tl = FormTable.Rows[i]["jc_tl"].ToString();
                //10.奖惩等级
                string jc_dj = FormTable.Rows[i]["jc_dj"].ToString();
                //11.奖惩类型
                string jc_type = FormTable.Rows[i]["jc_type"].ToString();
                //12.更改该文件名
                string hr_file_name = (FormTable.Columns.Contains("hr_file_name"))? FormTable.Rows[i]["hr_file_name"].ToString():"";
                //13.发生日期
                DateTime f_occurdate = DateTime.Parse(FormTable.Rows[i]["f_occurdate"].ToString());
                AddDcoument dc = new AddDcoument(token.plant);
                DataTable jcitem = new DataTable();
                try
                {
                    jcitem = AddDcoument.Jc_itemDB.AsEnumerable().Where(s => s.Field<string>("F_JCITEMTYPE") == jc_yj).
                        Where(k => k.Field<string>("F_JCTL") == jc_tl).CopyToDataTable();
                }
                catch(Exception ex)
                {
                    ErrorDic.Add(i + 1, "没有查询到该奖惩条例");
                    continue;
                }
                //15.奖惩条例单号
                string f_jcitemno = jcitem.Rows[0]["F_JCITEMNO"].ToString();
                //16.奖惩条例内容
                string f_jcitemcontent = jcitem.Rows[0]["F_JCITEMCONTENT"].ToString();
                //14.開除类型
                string f_delistype = (jc_dj == "開除") ? (jc_type == "違反工作紀律(曠工開除)") ? "曠工開除" : "違紀開除" : "";
                //17.旷工时间
                string absenteeismdate = "";
                if (f_delistype == "曠工開除")
                {
                    DataTable dt=new DataTable();
                    try
                    {
                        dt = AddDcoument.Absenteeismdate.AsEnumerable().Where(s => s.Field<string>("F_EMPNO") == emp_no).CopyToDataTable();
                    }
                    catch
                    {
                        ErrorDic.Add(i + 1, "旷工时数没有到达提交奖惩信息的条件");
                        continue;
                    }
                    
                    if (dt.Rows.Count > 3 || AddDcoument.CheckAbsent(dt))
                    {
                        if(AddDcoument.CheckAbsent(dt)) absenteeismdate = dt.Rows[0]["F_DUTYDATE"].ToString()+"~"+dt.Rows[2]["F_DUTYDATE"].ToString();
                        else absenteeismdate = dt.Rows[0]["F_DUTYDATE"].ToString() + "," + dt.Rows[1]["F_DUTYDATE"].ToString() 
                                + "," + dt.Rows[2]["F_DUTYDATE"].ToString();
                    }
                    else
                    {
                        ErrorDic.Add(i + 1, "旷工时数没有到达提交奖惩信息的条件");
                        continue;
                    }
                    
                }
                //18.是否变更奖惩等级
                string f_changetype =  FormTable.Rows[i]["f_changetype"].ToString();
                //19.变更奖惩等级高
                string f_jcdj_new = (FormTable.Columns.Contains("f_jcdj_new")) ? FormTable.Rows[i]["f_jcdj_new"].ToString() : "";
                //20.变更奖惩原因
                string f_changereason = (FormTable.Columns.Contains("f_changereason")) ? FormTable.Rows[i]["f_changereason"].ToString() : "";
                //特殊字段
                string ApplicationType = (FormTable.Columns.Contains("ApplicationType")) ? FormTable.Rows[i]["ApplicationType"].ToString() : "";
                //是否职业健康岗位
                OHSMS_MedicalSoapClient ohs = new OHSMS_MedicalSoapClient();
                string f_isspecialstation = ohs.FindCauseHarm_ByEmpNo(emp_no).Tables[0].Rows.Count>0 ? "Y" : "N";
                
                //赋值文件名
                if (FormTable.Rows[i]["f_changetype"].ToString() == "是")
                {
                    file_name = codes.Data[file_name];
                    hr_file_name = codes.Data[hr_file_name];
                }
                else if(FormTable.Columns.Contains("file_name")) file_name = codes.Data[file_name];
                
                string JsonLeader = "";
                //创建workflow
                if ((ApplicationType != "紙檔簽核" && ApplicationType != "調前記錄") || !txtHR)
                {
                    JsonLeader = WorkFlows.CreateIncentive(applyno, token.Emp, emp_no, token.plant, jc_dj, f_changetype);
                    if (JsonLeader == null)
                    {
                        ErrorDic.Add(i+ 1, "创建workflow失败，请联系管理员！");
                        continue;
                    }
                }
                //生成单号，和sql语句
                string sqlTxT = "";

                (sqlTxT, signsName[i]) = AddDcoument.AddIncentive(applyno, emp_no, name, duty, token.Emp, tbr_tel, remark,
                    file_name, jc_yj, jc_tl, jc_dj, jc_type, hr_file_name, f_occurdate, f_delistype, f_jcitemno, 
                    f_jcitemcontent, absenteeismdate, f_changetype, f_jcdj_new, f_changereason, JsonLeader, ApplicationType,
                    f_isspecialstation);
                sqls += (i == (FormTable.Rows.Count - 1)) ? sqlTxT: sqlTxT + " union all ";
                historysql += "insert into tb_signhistory_jc values('" + applyno + "','" + token.Emp + 
                    "','','','" + jc_dj + "','申請提交','申请人',sysdate,'');";

                if (token.permissions != "3" && token.permissions != "41")
                {
                    string LeaderSql = "select te.f_empno,te.f_name,tl.f_allmanager,F_EmpLevel from tb_employe te," +
                        "tb_leader_redirect tl where te.f_empno=tl.f_empno and te.f_empno='" + emp_no + "'";
                    bool Leaders = DBHelper.Queues(LeaderSql, token.plant).Rows[0][2].ToString().Contains(token.Emp);
                    if (!Leaders)
                    {
                        code.Code = "500";
                        code.Message = "该工号不在您的权限范围内";
                        return Jsons.JsonData(JsonConvert.SerializeObject(code,
                        new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd" }));
                    }
                }
            }
            string sql = "insert into tb_jc_apply (apply_no,emp_no,name,duty,tbr,tbr_tel,remark,file_name,jc_yj,jc_tl,jc_dj," +
                "jc_type,edittime,hr_check,signer,signertype,agent,signtime,status,is_upload,time_year,year_no,jc_dj_type," +
                "hr_file_name,f_occurdate,f_isspecialstation,f_delistype,f_jcitemno,f_jcitemcontent,f_absentdate,f_changetype," +
                "f_jcdj_new,f_changereason,leaderjson) " + sqls;
            sql = "begin " + sql + ";" + historysql + "end;";
            string message = "";
            foreach (int item in ErrorDic.Keys) 
            {
                message += "第" + item + "行：" + ErrorDic[item]+"\n";
            }
            code.Code = "200";
            code.Message = message;
            code.Data = ErrorDic;
            if (sqls == "" || DBHelper.Inserts(sql, token.plant) > 0)
            {
                code.Code = "500";
                code.Message = "添加错误！";
            }
            //发送邮件
            for(int i = 0;i< signsName.Length; i++)
            {
                SendMail sends = new SendMail();
                if (signsName[i] != "")
                {
                    string Result = sends.SignMail(signsName[i]).Result;
                }
                if (FormTable.Rows[i]["jc_dj"].ToString() == "開除" && SendMail.Judgement(FormTable.Rows[i]["emp_no"].ToString()))
                {
                    string F_emp = DBHelper.Queues("select F_value from tb_parameter " +
                        "where f_remark='環安職業健康體檢' ", token.plant).Rows[0][0].ToString();
                    OHSMS_MedicalSoapClient ohs = new OHSMS_MedicalSoapClient();
                    if (ohs.FindCauseHarm_ByEmpNo(FormTable.Rows[i]["emp_no"].ToString()).Tables[0].Rows.Count > 0)
                    {
                        string Result = sends.PhysicalExaminationMail(F_emp, FormTable.Rows[i]["emp_no"].ToString()
                            , FormTable.Rows[i]["name"].ToString()).Result;
                    }
                }
            }
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        } 
        /// <summary>
        /// 根据奖惩依据，条例，等级，类型获取奖惩内容
        /// </summary>
        /// <param name="jc_yj">依据</param>
        /// <param name="jc_tl">条例</param>
        /// <param name="jc_dj">等级</param>
        /// <param name="jc_type">类型</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/IncentiveContent")]
        public HttpResponseMessage IncentiveContent(string jc_yj,string jc_tl,string jc_dj,string jc_type)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select f_jcitemcontent from TB_JC_ITEM where f_jcitemtype='"
                + jc_yj + "' and f_jctl='" + jc_tl + "' and f_jcdj='" + jc_dj + "' and f_jctype='" + jc_type +"'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "",

                Data = DBHelper.Queues(sql,token.plant).Rows[0][0].ToString()
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        #endregion
        #endregion


        #region 奖惩进度查询
        /// <summary>
        /// 获取部门名
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetOrganization")]
        public HttpResponseMessage GetOrganization()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select f_organno,f_organname from tb_organization where f_plantno='" + token.plant + "'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 获取奖惩签核记录与年度奖惩信息
        /// </summary>
        /// <param name="empno">工号</param>
        /// <param name="applyno">奖惩单号</param>
        /// <param name="year">年份</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetYearAndHistory")]
        public HttpResponseMessage GetYearAndHistory(string empno,string applyno,string year)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            //年度奖惩信息
             string Yearsql = "select f_occurdate,jc_dj from tb_jc_apply a where  exists (select apply_no from tb_jc_apply b " +
                "where emp_no='" + empno + "' and  time_year='" + year + "' and a.apply_no=b.apply_no) and (status='已於原單位結案' " +
                "or status='已公告' or status='已結案')";
            DataTable YearTable = DBHelper.Queues(Yearsql, token.plant);
            YearTable.TableName = "YaerTable";
            //签核记录
            string Historysql = "select signer,f_name,CASE WHEN signstatus = '簽核完畢' THEN '通過' ELSE signstatus END AS signstatus" +
                ",signtime,memo,signtype,result from tb_signhistory_jc hist,tb_employe emp " +
                "where hist.signer=emp.f_empno and apply_no='" + applyno + "' order by signtime";
            DataTable SignerHistory = DBHelper.Queues(Historysql, token.plant);
            SignerHistory.TableName = "SignerHistory";
            //单据基本信息
            string Document = "select jc.apply_no,jc.emp_no,jc.name,jc.duty,emp.f_grand,emp.f_infactorydate,emp.f_departname" +
                ",jc.tbr,jc.tbr_tel,jc.f_occurdate,jc.jc_yj,jc.jc_tl,jc.jc_dj,jc.jc_type,jc.f_delistype,jc.f_jcitemcontent," +
                "jc.remark,jc.file_name,jc.f_changetype,jc.f_jcdj_new ,jc.f_changereason,jc.hr_file_name,jc.f_absentdate,jc.hr_check" +
                " from tb_jc_apply jc,tb_employe emp where jc.emp_no=emp.f_empno and apply_no='" + applyno + "'";
            DataTable DocumentTable = DBHelper.Queues(Document, token.plant);
            DocumentTable.TableName = "DocumentInfo";

            string Adds = "select signer,f_name,signertype from tb_jc_apply a,tb_employe b where signer=f_empno and apply_no='"+ applyno + "'";
            DataTable AddHistroy = DBHelper.Queues(Adds, token.plant);
            if (AddHistroy.Rows.Count > 0)
            {
                DataRow rows = SignerHistory.NewRow();
                rows["SIGNER"]= AddHistroy.Rows[0][0];
                rows["F_NAME"] = AddHistroy.Rows[0][1];
                rows["SIGNTYPE"] = AddHistroy.Rows[0][2];
                rows["SIGNSTATUS"] = "待签核";
                SignerHistory.Rows.Add(rows);
            }


            DataSet ds = new DataSet();
            ds.Tables.Add(YearTable);
            ds.Tables.Add(SignerHistory);
            ds.Tables.Add(DocumentTable);

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = ds
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 查询签核记录
        /// </summary>
        /// <param name="applyno"></param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetHistory")]
        public HttpResponseMessage GetHistory(string applyno)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            //签核记录
            string Historysql = "select signer,f_name,signstatus,signtime,memo,signtype from tb_signhistory_jc hist,tb_employe emp " +
                "where hist.signer=emp.f_empno and apply_no='" + applyno + "'";
            DataTable SignerHistory = DBHelper.Queues(Historysql, token.plant);
            SignerHistory.TableName = "SignerHistory";


            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = SignerHistory
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 根据条件查询奖惩进度
        /// </summary>
        /// <param name="empno">工号</param>
        /// <param name="Name">员工姓名</param>
        /// <param name="plant">厂区</param>
        /// <param name="ReporterEmpno">提报人工号</param>
        /// <param name="ReporterName">提报人姓名</param>
        /// <param name="jc_type">奖惩类型</param>
        /// <param name="jc_dj">奖惩等级</param>
        /// <param name="f_departname">部门名称</param>
        /// <param name="status">单据类型</param>
        /// <param name="stratTime">开始日期</param>
        /// <param name="endTime">结束日期</param>
        /// <param name="healthy">是否体检</param>
        /// <param name="f_isleave">在职状态</param>
        /// <param name="ApplicationType">申请类型</param>
        /// <param name="Closestrat">结案开始日期</param>
        /// <param name="CloseEnd">结案结束日期</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetIncentiveProgress")]
        public HttpResponseMessage GetIncentiveProgress(string empno, string plant, string ReporterEmpno, string ReporterName,
            string jc_type, string jc_dj, string f_departname, string status, string stratTime, string endTime, string healthy,
            string f_isleave,string ApplicationType,string Closestrat,string CloseEnd,string Name)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sql = "select apply_no,emp_no,name,duty,(select f_name from tb_employe where f_empno=tbr) as tbr,tbr_tel," +
                "remark,file_name,jc_yj,jc_tl,CASE WHEN jc_dj = '開除' THEN f_delistype ELSE jc_dj END AS jc_dj,jc_type,edittime," +
                "hr_check,(select f_name from tb_employe where f_empno=signer) as signer,signertype,(select f_name from tb_employe" +
                " where f_empno=agent) as agent,signtime,status,jc_dj_type,hr_file_name,f_occurdate,f_jcitemno,f_jcitemcontent," +
                "f_absentdate,f_delistype,f_changetype,f_jcdj_new,f_changereason,emp.f_infactorydate,emp.f_departname,emp.f_grand," +
                "jc.time_year,ROUND((sysdate-emp.f_infactorydate)/365, 2 ) as infactory,f_isspecialstation,Get_Value(emp.f_plantno," +
                "'DIMISSION_SPECIALDELIVERITEM','',jc.apply_no) as awaits,(select signtime from tb_signhistory_jc where " +
                "signstatus='簽核完畢' and apply_no=jc.apply_no) as overDate from tb_jc_apply jc,tb_employe emp,tb_organization org " +
                "where jc.emp_no = emp.f_empno and emp.f_organno = org.f_organno";

            if (plant == "41")
            {
                sql += " and emp.f_plantno = (select TH.F_PlantNo from TB_Employe TE,TB_HRWindow TH where " +
                    "TE.F_EmpNo=TH.F_EmpNo and TH.F_WindowType='HREmpWin_JC' and TE.f_empno='" + token.Emp + "')";
            }
            else if (plant == "3")
            {
            }
            else
            {
                sql += " and emp.f_plantno = '" + token.plant + "'";
            }


            if (token.permissions == "2" || token.permissions == "1")
            {
                sql += " and (emp_no in (select te.f_empno from tb_employe te," +
                    "tb_leader_redirect tl where te.f_empno=tl.f_empno and f_allmanager like '%" + token.Emp + "%')" +
                    "or jc.apply_no in (select apply_no from tb_signhistory_jc where signer='"+ token.Emp + "' group by apply_No))";
            }
            if (token.permissions == "0")
            {
                sql += " and emp_no='" + token.Emp + "'";
            }
            if (Name != null)
            {
                sql += "and jc.name like '%" + Name + "%'";
            }
            if(ReporterName != null && ReporterEmpno == null)
            {
                string sqlName = "select f_name from tb_employe where f_empno='" + ReporterName + "'";
                DataTable dt = DBHelper.Queues(sqlName,token.plant);
                ReporterEmpno = (dt.Rows.Count>0) ? dt.Rows[0][0].ToString() : "";
            }
            if (empno != null) sql += " and jc.emp_no='" + empno + "'";
            if (jc_type != null) sql += " and jc_type='" + jc_type + "'";
            if (jc_dj != null) sql += " and jc_dj='" + jc_dj + "'";
            if (status != null) sql += " and status='" + status + "'";
            if (stratTime != null) sql += " and edittime>to_date('" + stratTime + "','yyyy-mm-dd')";
            if (endTime != null) sql += " and edittime<to_date('" + endTime + "','yyyy-mm-dd')";
            if (ReporterEmpno != null) sql += " and tbr='" + ReporterEmpno + "'";
            if (f_departname != null) sql += " and emp.f_organno='" + f_departname + "'";
            if (healthy != null) sql += " and jc.F_ISSPECIALSTATION='" + healthy + "'";
            if (f_isleave != null) sql += " and emp.f_isleave='" + f_isleave + "'";
            if (ApplicationType == "正常申請")
            {
                sql += " and status not like '紙檔簽核%' and status not like '調前記錄%'";
            }
            else if (ApplicationType == "紙檔簽核")
            {
                sql += " and (jc.status='" + ApplicationType + "' or jc.status='" + ApplicationType + "(待簽核)')";
            }
            else if (ApplicationType == "調前記錄")
            {
                sql += " and (jc.status='" + ApplicationType + "' or jc.status='" + ApplicationType + "(待簽核)')";
            }
            if (Closestrat != null) sql += " and apply_no in (select apply_no from tb_signhistory_jc where signstatus='已結案'" +
                    " and signtime>to_date('" + Closestrat + "','yyyy-mm-dd') and signtime<to_date('" + CloseEnd + "','yyyy-mm-dd'))";

            sql += " order by jc.edittime desc";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql,token.plant)
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 取消申请单据
        /// </summary>
        /// <param name="apply_no"></param>
        /// <param name="MEMO"></param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/CancelIcnetive")]
        public HttpResponseMessage CancelIcnetive(string apply_no,string MEMO)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            //签核记录
            string sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + token.Emp + "','',"
                + "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'取消'," +
                "(select signertype from tb_jc_apply where apply_no='" + apply_no + "'),sysdate,'');";
            //单据状态
            string sqlApply = "update tb_jc_apply set signer='',signertype='',signtime=sysdate," +
                "status='已取消' where apply_no='" + apply_no + "';";

            string sqls = "begin " + sqlApply + sqlHistory + " end;";
            string tbr = DBHelper.Queues("select tbr from tb_jc_apply where apply_no='" + apply_no + 
                "'", token.plant).Rows[0][0].ToString();
            SendMail sends = new SendMail();
            string Result = sends.CancelMail(tbr).Result;
            

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Inserts(sqls, token.plant)
            };
            //终止workflow
            Workflow workflow = new Workflow();
            workflow.RunTerminate("HRM_JC", apply_no);

            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 获取导出文档
        /// </summary>
        /// <param name="apply_no"></param>
        /// <param name="emp_no"></param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/ExportIncentive")]
        public HttpResponseMessage ExportIncentive(string apply_no,string emp_no)
        {
            string[] apply_nos = JsonConvert.DeserializeObject<string[]>(apply_no);
            string[] emp_nos = JsonConvert.DeserializeObject<string[]>(emp_no);
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            List<Dictionary<string, string>> list = new List<Dictionary<string, string>>();
            for(int i = 0; i < apply_nos.Length; i++)
            {
                Dictionary<string, string> dic = new Dictionary<string, string>();
                OHSMS_MedicalSoapClient ohs = new OHSMS_MedicalSoapClient();
                DataTable ohsTable = ohs.FindMedicalInfo_ByEmpNo(emp_nos[i], "離崗體檢").Tables[0];
                string Need_ME = ohsTable.Rows.Count > 0 ? 
                    (ohsTable.Rows[0]["Need_ME"].ToString() == "Y" ? "出席" : "未出席") : "";

                dic.Add("Attendance", Need_ME);
                dic.Add("AwaitWork", DBHelper.Queues("select Get_Value('" + token.plant + "','DIMISSION_SPECIALDELIVERITEM','"
                     + apply_nos[i] + "','') from dual", token.plant).Rows[0][0].ToString());
                DataTable dt = DBHelper.Queues("select signstatus,signtime from tb_signhistory_jc where apply_no='" +
                    apply_nos[i] + "' and (signstatus='已結案' or signstatus='簽核完畢')", token.plant);
                EnumerableRowCollection<DataRow> CloseDt = 
                    dt.AsEnumerable().Where(s => s.Field<string>("signstatus") == "已結案");
                dic.Add("CloseDate", CloseDt.Count() > 0 ? CloseDt.CopyToDataTable().Rows[0][1].ToString() : "");
                EnumerableRowCollection<DataRow> SigerDt = 
                    dt.AsEnumerable().Where(s => s.Field<string>("signstatus") == "簽核完畢");
                dic.Add("SinerOver", SigerDt.Count() > 0 ? SigerDt.CopyToDataTable().Rows[0][1].ToString() : "");
                list.Add(dic);
            }
            
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = list
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        #endregion


        #region 列印公告单
        /// <summary>
        /// 获取能打印的公告单
        /// </summary>
        /// <param name="empno">工号</param>
        /// <param name="departname">部门名称</param>
        /// <param name="starttime">开始时间</param>
        /// <param name="endtime">结束时间</param>
        /// <param name="bulletintype">奖惩单类型</param>
        /// <param name="plant">厂区</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetPrintBulletin")]
        public HttpResponseMessage GetPrintBulletin(string empno,string departname,string starttime,string endtime,string bulletintype,string plant)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select apply_no,emp_no,name,f_grand,f_departname,signtime,edittime,f_plantno,jc_dj_type,time_year," +
                "CASE WHEN jc.jc_dj = '開除' THEN jc.f_delistype ELSE jc.jc_dj END AS jc_dj," +
                "(select f_name from tb_employe where f_empno=tbr) as tbr,(select f_name from tb_employe where f_empno=signer) as signer," +
                "(select f_name from tb_employe where f_empno=agent) as agent,signertype,f_isspecialstation,status," +
                "ROUND((sysdate-emp.f_infactorydate)/365, 2 ) as infactory," +
                "Get_Value(emp.f_plantno,'DIMISSION_SPECIALDELIVERITEM','',jc.apply_no) as awaits,jc_yj,jc_tl,remark," +
                "(select signtime from tb_signhistory_jc where signstatus='簽核完畢' and apply_no=jc.apply_no) as overDate " +
                "from tb_jc_apply jc,tb_employe emp where jc.emp_no = emp.f_empno and (status='已結案' or status='已公告')";
            
            if(empno != null)
            {
                sql += " and emp_no = '" + empno + "'";
            }
            if(departname != null)
            {
                sql += " and f_departname = '" + departname + "'";
            }
            if(bulletintype != null)
            {
                sql += " and jc_dj_type = '" + bulletintype + "'";
            }
            if(plant!= null)
            {
                sql += " and f_plantno = '" + plant + "'";
            }
            if(starttime != null)
            {
                sql += " and to_date(f_occurdate,'yyyy-mm-dd')> to_date('" + starttime + "','yyyy-mm-dd') and to_date(f_occurdate,'yyyy-mm-dd')<to_date('" + endtime + "','yyyy-mm-dd')";
            }

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 公告奖惩单
        /// </summary>
        /// <param name="apply_no1">单号</param>
        /// <param name="apply_no2">单号</param>
        /// <param name="apply_no3">单号</param>
        /// <param name="apply_no4">单号</param>
        /// <param name="time_year">年份号</param>
        /// <param name="plantno">单据所属厂区</param>
        /// <param name="jc_dj_type">单据所属厂区</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/Bulletin")]
        public HttpResponseMessage Bulletin(string apply_no1, string time_year,string plantno,string jc_dj_type,
            string apply_no2 = null, string apply_no3 = null, string apply_no4 = null)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            //记录sql执行状态
            Dictionary<string, string> dic = new Dictionary<string, string>();

            //获取公告单号
            string year_no = "select Max(year_no)+1 from tb_jc_apply where time_year='" + time_year + "' and jc_dj_type='" + jc_dj_type + "'";

            year_no = DBHelper.Queues(year_no, token.plant).Rows[0][0].ToString();
            //添加签核记录
            string sql = "insert into tb_signhistory_jc ";
            if (apply_no1 != null)
                sql += "select '" + apply_no1 + "','" + token.Emp + "','',null,null,'公告','人資公告',sysdate,null from dual";
            if (apply_no2 != null)
                sql += " union all select '" + apply_no2 + "','" + token.Emp + "','',null,null,'公告','人資公告',sysdate,null from dual";
            if (apply_no3 != null)
                sql += " union all select '" + apply_no3 + "','" + token.Emp + "','',null,null,'公告','人資公告',sysdate,null from dual";
            if (apply_no4 != null)
                sql += " union all select '" + apply_no4 + "','" + token.Emp + "','',null,null,'公告','人資公告',sysdate,null from dual";
            

            //修改奖惩单状态
            string BulletinSql = "update tb_jc_apply set status='已公告',year_no='" + year_no + "' where apply_no='" + apply_no1 + "'";
            if (apply_no2 != null)
            {
                BulletinSql += " or apply_no='" + apply_no2 + "'";
            }
            if (apply_no3 != null)
            {
                BulletinSql += " or apply_no='" + apply_no3 + "'";
            }
            if (apply_no4 != null)
            {
                BulletinSql += " or apply_no='" + apply_no4 + "'";
            }


            //hr主管
            string HRsql = "select TE.F_EmpNo,TE.F_Name,TH.F_WindowType,TH.F_WindowName,TH.F_PlantNo from TB_Employe TE,TB_HRWindow TH where " +
                "TE.F_EmpNo=TH.F_EmpNo and TH.F_WindowType ='HREmpWin_JC_Leader' and TH.f_plantno='" + plantno + "'";


            //公告单号
            dic.Add("year_no", year_no);
            //记录修改单据状态
            dic.Add("apply", DBHelper.Inserts(BulletinSql, token.plant).ToString());
            //记录签核记录执行状态
            dic.Add("history", DBHelper.Inserts(sql, token.plant).ToString());
            //hr主管
            dic.Add("HRLeader", DBHelper.Queues(HRsql, token.plant).Rows[0][1].ToString());


            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = dic
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 获取开除单信息
        /// </summary>
        /// <param name="emp_no"></param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetExpel")]
        public HttpResponseMessage GetExpel(string emp_no)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            //记录sql执行状态
            string sqls = "select f_infactorydate,CASE WHEN f_leavedate is null THEN sysdate ELSE f_leavedate " +
                "END AS f_leavedate, f_idcard, f_position, f_artificial, f_value from tb_employe emp,tb_parameter pa where " +
                "emp.f_plantno = pa.f_plantno and pa.f_name = 'JCPrint' and f_empno = '" + emp_no + "'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sqls,token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        #endregion

        
        #region 奖惩签核系列接口
        #region 奖惩签核页面接口
        /// <summary>
        /// 获取待签核的单据
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/")]
        public HttpResponseMessage GetAwaitSinger()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select apply_no,emp_no,name,duty,(select f_name from tb_employe where f_empno=tbr) as tbr," +
                "tbr_tel,remark,file_name,jc_yj,jc_tl," +
                "CASE WHEN f_changetype='是' THEN CASE WHEN f_jcdj_new = '開除' THEN f_delistype ELSE f_jcdj_new END " +
                "ELSE CASE  WHEN jc_dj = '開除' THEN f_delistype ELSE jc_dj END END AS jc_dj," +
                "jc_type,edittime,hr_check,signer,signertype,agent,signtime,status,jc_dj_type,hr_file_name,f_occurdate," +
                "f_jcitemno,f_jcitemcontent,f_absentdate,f_delistype,f_changetype,f_jcdj_new,f_changereason," +
                "ROUND((sysdate-emp.f_infactorydate)/365, 2) as infactory,emp.f_departname,emp.f_grand,jc.time_year," +
                "f_isspecialstation from tb_jc_apply jc,tb_employe emp,tb_organization org where jc.emp_no = emp.f_empno " +
                "and emp.f_organno = org.f_organno and signer='" + token.Emp + "' or agent='" + token.Emp + 
                "' order by edittime ";

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));

        }
        /// <summary>
        /// 通过签核
        /// </summary>
        /// <param name="apply_no">单据号</param>
        /// <param name="MEMO">签核原因</param>
        /// <param name="jc_dj">是否变更奖惩等级</param>
        /// <returns></returns>
        /// 
        [Token]
        [HttpPost]
        [Route("IncentiveManage/Signer")]
        public HttpResponseMessage Signer(string apply_no,string MEMO = null,string jc_dj = null)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string status = DBHelper.Queues("select status from tb_jc_apply where apply_no='"
                + apply_no + "'", token.plant).Rows[0][0].ToString();

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = 6
            };
            SignOff sis = new SignOff();
            try
            {
                if (status.Contains("紙檔簽核"))
                {
                    SignOff.SignerDocument(status, apply_no, MEMO, token.Emp, token.plant);
                }
                else
                {
                    sis.Signer(status, apply_no, MEMO, token.Emp, token.plant, jc_dj);
                }
                //SignOff.Signer("Approved", apply_no, MEMO, "F1339509", "001", jc_dj);
            }
            catch(Exception ex)
            {
                code.Data = ex.Message;
            }


            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 全部通过签核
        /// </summary>
        /// <param name="apply_nos">单号数据Json数据</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/ManySigner")]
        public HttpResponseMessage ManySigner(string apply_nos)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string[] apply = JsonConvert.DeserializeObject<string[]>(apply_nos);
            SignOff sis = new SignOff();
            for (int i = 0; i < apply.Length; i++)
            {
                sis.Signer("Approved", apply[i], "", token.Emp, token.plant);
            }
            

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = 6
            };
            
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 驳回签核
        /// </summary>
        /// <param name="apply_no">单号</param>
        /// <param name="MEMO">驳回理由</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/Reject")]
        public HttpResponseMessage Reject(string apply_no, string MEMO)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string status = DBHelper.Queues("select status from tb_jc_apply where apply_no='"
                + apply_no + "'", token.plant).Rows[0][0].ToString();
            string sqlHistory = "";
            string sqlApply = "";
            string signer = "";
            string agents = "";
            Workflow workflow = new Workflow();
            string CurrentApprover = workflow.GetNextApprover("HRM_JC", apply_no).Tables[0].Rows[0]["StationName"].ToString();
            //签核记录
            if (status == "駁回")
            {
                signer = DBHelper.Queues("select tbr from tb_jc_apply where apply_no='" + apply_no + "'", token.plant).Rows[0][0].ToString();
                agents = GetAgent.Agent(signer);
                sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + token.Emp + "','',"
                    + "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'同意駁回'," +
                    "'"+ CurrentApprover + "',sysdate,'');";
                //单据状态
                sqlApply = "update tb_jc_apply set signer='" + signer + "',signertype='申请人确认',agent='" + agents +
                    "',signtime=sysdate,status='待確認' where apply_no='" + apply_no + "';";
            }
            else if (status == "紙檔簽核(待簽核)" || status == "調前記錄(待簽核)")
            {
                sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + token.Emp + "','',"
                    + "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'驳回'," +
                    "(select signertype from tb_jc_apply where apply_no='" + apply_no + "'),sysdate,'');";
                //单据状态
                sqlApply = "update tb_jc_apply set signer='',signertype='',agent='',signtime=sysdate,status='"+
                    status.Substring(0,4)+ "(驳回)" + "' where apply_no='" + apply_no + "';";
            }
            else
            {
                if (CurrentApprover == "人資初審")
                {
                    signer = DBHelper.Queues("select tbr from tb_jc_apply where apply_no='" + apply_no +
                        "'", token.plant).Rows[0][0].ToString();
                    agents = GetAgent.Agent(signer);
                    sqlApply = "update tb_jc_apply set signer='" + signer + "',signertype='人資初審',signtime=sysdate," +
                                        "status='待確認',agent='" + agents + "' where apply_no='" + apply_no + "';";
                    sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + token.Emp + "','',"
                        + "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'駁回'," +
                        "'申请人确认',sysdate,'');";
                }
                else
                {
                    signer = DBHelper.Queues("select TE.F_EmpNo from TB_Employe TE,TB_HRWindow " +
                        "TH where TE.F_EmpNo=TH.F_EmpNo and TH.F_WindowType='HREmpWin_JC' and " +
                        "TH.F_PlantNo=(select f_plantno from tb_employe where f_empno=(select emp_no from tb_jc_apply " +
                        "where apply_no='" + apply_no + "'))", token.plant).Rows[0][0].ToString();
                    agents = GetAgent.Agent(signer);
                    sqlApply = "update tb_jc_apply set signer='" + signer + "',signertype='人資初審',signtime=sysdate," +
                        "status='駁回',agent='" + agents + "' where apply_no='" + apply_no + "';";
                    sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + token.Emp + "','',"
                        + "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'駁回'," +
                        "'"+ CurrentApprover + "',sysdate,'');";
                }
            }
            
            //发送邮件
            SendMail sends = new SendMail();
            string Result;
            if (agents == "") Result = sends.SignMail(signer).Result;
            else Result = sends.SignMail(agents).Result;

            string sqls = "begin " + sqlApply + sqlHistory + " end;";   
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Inserts(sqls,token.plant)
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 申请人修改奖惩单据
        /// </summary>
        /// <param name="apply_no">单号</param>
        /// <param name="duty">担当</param>
        /// <param name="tbr_tel">提报人电话</param>
        /// <param name="f_occurdate">奖惩发生日期</param>
        /// <param name="jc_yj">奖惩依据</param>
        /// <param name="jc_tl">奖惩条例</param>
        /// <param name="jc_dj">奖惩等级</param>
        /// <param name="jc_type">奖惩类型</param>
        /// <param name="f_jcitemcontent">奖惩条例内容</param>
        /// <param name="remark">奖惩原由</param>
        /// <param name="f_changetype">是否变更奖惩等级</param>
        /// <param name="f_jcdj_new">变更的奖惩等级</param>
        /// <param name="f_changereason">变更奖惩等级原因</param>
        /// <param name="f_jcitemno">奖惩条例单号</param>
        /// <param name="f_absentdate">旷工时间</param>
        /// <param name="f_delistype">開除类型</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/UpdateIncentive")]
        public HttpResponseMessage UpdateIncentive(string apply_no,string duty,string tbr_tel,string f_occurdate
            ,string jc_yj, string jc_tl,string jc_dj,string jc_type,string f_jcitemcontent,string remark
            ,string f_changetype, string f_jcitemno, string f_changereason = null, string f_jcdj_new = null
            ,string f_absentdate = null,string f_delistype = null)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            //是否变更奖惩等级
            if (f_changetype == "true")
            {
                f_changetype = "是";
            }
            else
            {
                f_changetype = "否";
            }
            //保存文件
            string file_name = null;
            string hr_file_name = null;
            var files = HttpContext.Current.Request.Files;
            if (files.Count > 0)
            {
                string[] filenames = new string[files.Count];
                Stream[] FileStreams = new Stream[files.Count];
                for (int i = 0; i < files.Count; i++)
                {
                    filenames[i] = files[i].FileName;
                    FileStreams[i] = files[i].InputStream;
                }
                ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>
                    (HttpRequests.UploadRequest("EMPServer/Incentive", FileStreams, filenames));
                file_name = codes.Data[filenames[0]];
                hr_file_name = (files.Count > 1) ? codes.Data[filenames[1]] : "";
            }
            //
            Workflow workflow = new Workflow();
            DataTable CurrentApprover = workflow.GetNextApprover("HRM_JC", apply_no).Tables[0];
            string signertype = CurrentApprover.Rows[0]["StationName"].ToString().Trim();
            string signer = CurrentApprover.Rows[0]["Approver"].ToString();
            string agents = GetAgent.Agent(signer);

            string sqlApply = "update tb_jc_apply set edittime=sysdate,duty='" + duty + "',tbr_tel='" + tbr_tel + "'," +
                "f_occurdate='" + f_occurdate + "',jc_yj='" + jc_yj + "',jc_tl='" + jc_tl + "',jc_dj='" + jc_dj + 
                "',jc_type='" + jc_type + "',f_jcitemcontent='" + f_jcitemcontent + "',remark='" + remark + "'," +
                "f_changetype='" + f_changetype + "',f_jcdj_new='" + f_jcdj_new + "',f_changereason='" + f_changereason + 
                "',f_jcitemno='" + f_jcitemno + "',f_absentdate='" + f_absentdate + "',f_delistype='" + f_delistype +
                "',status='待簽核',signer='" + signer + "',signertype='"+ signertype + "',agent='"+ agents + "'," +
                "file_name='" + file_name + "',hr_file_name='"+ hr_file_name + "' where apply_no='" + apply_no + "';";
            
            string agent= GetAgent.Agent(token.Emp); 
            string sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + token.Emp + "','" 
                + agent + "','',CNSBGHR.GET_JCDJ('" + apply_no + "'),'修改','申請人修改',sysdate,'');";

            //发送邮件
            SendMail sends = new SendMail();
            string Result;
            if (agents == "") Result = sends.SignMail(signer).Result;
            else Result = sends.SignMail(agents).Result;


            string sqls = "begin " + sqlApply + sqlHistory + " end;";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Inserts(sqls, token.plant)
            };


            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        #endregion

        #region 奖惩结案系列接口
        /// <summary>
        /// 获取待结案的单据
        /// </summary>
        /// <param name="empno">工号</param>
        /// <param name="name">姓名</param>
        /// <param name="jc_type">奖惩类型</param>
        /// <param name="jc_dj">奖惩等级</param>
        /// <param name="plant">厂区</param>
        /// <param name="StartTime">开始时间</param>
        /// <param name="EndTime">结束时间</param>
        /// <param name="f_isleave">在职状态</param>
        /// <param name="ExpelType">开除类型</param>
        /// <param name="f_isspecialstation">是否体检</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetClosing")]
        public HttpResponseMessage GetClosing(string empno,string name,string jc_type,string jc_dj,
            string plant,string StartTime,string EndTime,string f_isleave,string ExpelType,string f_isspecialstation)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sqls = "select apply_no,emp_no,name,duty,(select f_name from tb_employe where f_empno=tbr) as tbr,tbr_tel," +
                "remark,file_name,jc_yj,jc_tl," +
                "CASE WHEN f_changetype='是' THEN CASE WHEN f_jcdj_new = '開除' THEN f_delistype ELSE f_jcdj_new END " +
                "ELSE CASE  WHEN jc_dj = '開除' THEN f_delistype ELSE jc_dj END END AS jc_dj," +
                "jc_type,edittime,hr_check,signer,signertype,agent,signtime,status,jc_dj_type,hr_file_name,f_occurdate,f_jcitemno," +
                "f_jcitemcontent,f_absentdate,f_delistype,f_changetype,f_jcdj_new,f_changereason," +
                "ROUND((sysdate-emp.f_infactorydate)/365, 2 ) as infactory,emp.f_departname,emp.f_grand,jc.time_year," +
                "f_isspecialstation from tb_jc_apply jc,tb_employe emp,tb_organization org where " +
                "jc.emp_no = emp.f_empno and emp.f_organno = org.f_organno and status='待結案'";
            if (empno != null)
            {
                string[] emps=empno.Split(',');
                if (emps.Length > 1)
                {
                    sqls += " and (";
                    for(int i= 0; i < emps.Length; i++)
                    {
                        if(i == 0) sqls += "emp_no='" + emps[i] + "'";
                        else sqls += " or emp_no='" + emps[i] + "'";
                    }
                    sqls += ")";
                }
                else
                {
                    sqls += " and emp_no='" + empno + "'";
                }
                
            }
            if (name != null) sqls += " and name='" + name + "'";
            if (jc_type != null) sqls += " and jc_type='" + jc_type + "'";
            if (jc_dj != null) sqls += " and jc_dj='" + jc_dj + "'";
            if (StartTime != null) sqls += " and edittime>to_date('" + StartTime + "','yyyy-mm-dd')";
            if (EndTime != null) sqls += " and edittime<to_date('" + EndTime + "','yyyy-mm-dd')";
            if (plant != null) sqls += " and emp.f_plantno='" + plant + "'";
            if (f_isleave != null) sqls += " and emp.f_isleave='" + f_isleave + "'";
            if (ExpelType != null) sqls += " and jc.f_delistype='" + ExpelType + "'";
            if (f_isspecialstation != null) sqls += " and jc.f_isspecialstation='" + f_isspecialstation + "'";
            sqls += " order by edittime desc";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sqls, token.plant)
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 人资结案
        /// </summary>
        /// <param name="apply_no">奖惩单号</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/Closing")]
        public HttpResponseMessage Closing(string apply_no)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            

            //签核记录
            string agent = GetAgent.Agent(token.Emp);
            string sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + token.Emp + "','" + agent + "',"
                + "'','','已結案',(select signertype from tb_jc_apply where apply_no='" + apply_no + "'),sysdate,'');";
            //单据状态
            string sqlApply = "update tb_jc_apply set signer='',signertype='',signtime=sysdate," +
                "status='已結案' where apply_no='" + apply_no + "';";


            //同步文件到服务器 
            var files = HttpContext.Current.Request.Files;
            if (files.Count > 0)
            {
                string[] filenames = new string[files.Count];
                Stream[] filestream = new Stream[files.Count];
                for (int i = 0; i < files.Count; i++)
                {
                    filenames[i] = files[i].FileName;
                    filestream[i] = files[i].InputStream;
                }
                ReturnCode codes = JsonConvert.DeserializeObject<ReturnCode>
                    (HttpRequests.UploadRequest("EMPServer/Incentive", filestream, filenames));
                string filename = codes.Data[filenames[0]];
                sqlApply += "update tb_jc_apply set hr_check='" + filename + "' where apply_no='"+ apply_no + "';";
            }

            string sqls = "begin " + sqlApply + sqlHistory + " end;";
            DBHelper.Inserts(sqls, token.plant);
            
            string Smssql = "select jc.emp_no,CASE WHEN jc.f_changetype = '否' THEN jc.jc_dj ELSE jc.f_jcdj_new END AS jc_dj," +
                "jc.f_delistype,emp.f_name,emp.f_telephone,emp.f_idcard,emp.f_infactorydate,CASE WHEN emp.f_grand like '師%' " +
                "THEN emp.f_position ELSE emp.f_stationname END AS Tis,emp.f_artificial,emp.f_plantno from tb_jc_apply jc,tb_employe " +
                "emp where jc.emp_no=emp.f_empno and apply_no='" + apply_no + "'";
            DataTable dt = DBHelper.Queues(Smssql, token.plant);
            string err = "";
            if (dt.Rows[0][1].ToString() == "開除")
            {
                List<SmsInfo> list = new List<SmsInfo>();
                SmsInfo Sms = new SmsInfo();
                Sms.EmpNo = dt.Rows[0][0].ToString();
                Sms.Tel = dt.Rows[0][4].ToString();
                Sms.Name = dt.Rows[0][3].ToString();
                Sms.CloseDate = DateTime.Now.ToString("yyyy/MM/dd");
                Sms.ExpelType = dt.Rows[0][2].ToString();
                Sms.Sms = "【解除劳动合同通知】" + ChineseConverter.Convert(Sms.Name, ChineseConversionDirection.TraditionalToSimplified) + 
                    "（工号：" + Sms.EmpNo + "，身份证号："+ dt.Rows[0][5].ToString() +"），您在职时间为" + 
                    DateTime.Parse(dt.Rows[0][6].ToString()).ToString("yyyy/MM/dd") + "至"+ Sms.CloseDate + "，工作岗位为" + 
                     ChineseConverter.Convert(dt.Rows[0][7].ToString(), ChineseConversionDirection.TraditionalToSimplified)
                    + "，因您违反公司规章制度，我公司与您之劳动合同于"+ Sms.CloseDate + "解除，劳动关系终止，请您携带厂牌于" +
                    "下周五至公司办理未完成的交接手续，特此通知。系统自动发送，请勿直接回复短信。如有疑问，请联系人力资源处：" +
                    "0755-28129588-61800【"+ 
                    ChineseConverter.Convert(dt.Rows[0][8].ToString(), ChineseConversionDirection.TraditionalToSimplified) + "】";
                list.Add(Sms);
                //奖惩窗口
                string MailTo = DBHelper.Queues("select TE.F_EmpNo from TB_Employe TE,TB_HRWindow TH where TE.F_EmpNo=TH.F_EmpNo " +
                    "and TH.F_WindowType='HREmpWin_JC' and TH.f_plantno='" + dt.Rows[0][9].ToString() + "'", 
                    token.plant).Rows[0][0].ToString();
                err = SignOff.ExpelClosed(list, MailTo);
            }

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功" + err,
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 多条人资结案
        /// </summary>
        /// <param name="apply_nos">Json数组奖惩单号</param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/ManyClosing")]
        public HttpResponseMessage ManyClosing(string apply_nos)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string[] applys = JsonConvert.DeserializeObject<string[]>(apply_nos);

            string sqls = "begin ";
            //签核记录
            string agent = GetAgent.Agent(token.Emp);

            string Smssql = "select jc.emp_no,CASE WHEN jc.f_changetype = '否' THEN jc.jc_dj ELSE jc.f_jcdj_new END AS jc_dj," +
                "jc.f_delistype,emp.f_name,emp.f_telephone,emp.f_idcard,emp.f_infactorydate,CASE WHEN emp.f_grand like '師%' " +
                "THEN emp.f_position ELSE emp.f_stationname END AS Tis,emp.f_artificial,emp.f_plantno from tb_jc_apply jc,tb_employe " +
                "emp where jc.emp_no=emp.f_empno and ";
            for (int i = 0; i < applys.Length; i++)
            {
                string sqlHistory = "insert into tb_signhistory_jc values('" + applys[i] + "','" + token.Emp + "','" + agent + "',"
                    + "'','','已結案',(select signertype from tb_jc_apply where apply_no='" + applys[i] + "'),sysdate,'');";
                //单据状态
                string sqlApply = "update tb_jc_apply set signer='',signertype='',signtime=sysdate," +
                    "status='已結案' where apply_no='" + applys[i] + "';";
                sqls += sqlApply + sqlHistory;

                Smssql += i == applys.Length - 1 ? "apply_no='" + applys[i] + "'" : "apply_no='" + applys[i] + "' or ";
            }
            sqls += " end;";

            //奖惩窗口
            DataTable MailTo = DBHelper.Queues("select TE.F_EmpNo,TE.F_Name,TH.F_WindowType,TH.F_WindowName,TH.F_PlantNo " +
                "from TB_Employe TE,TB_HRWindow TH where TE.F_EmpNo=TH.F_EmpNo and TH.F_WindowType='HREmpWin_JC'",token.plant);
            //001龙华  002 杭州 005重庆 003 南宁

            DataTable dt = DBHelper.Queues(Smssql, token.plant);

            List<SmsInfo> LH = new List<SmsInfo>();
            List<SmsInfo> HZ = new List<SmsInfo>();
            List<SmsInfo> CQ = new List<SmsInfo>();
            List<SmsInfo> NN = new List<SmsInfo>();
            List<SmsInfo> FII = new List<SmsInfo>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][1].ToString() == "開除")
                {
                    SmsInfo Sms = new SmsInfo();
                    Sms.EmpNo = dt.Rows[i][0].ToString();
                    Sms.Tel = dt.Rows[i][4].ToString();
                    Sms.Name = dt.Rows[i][3].ToString();
                    Sms.CloseDate = DateTime.Now.ToString("yyyy/MM/dd");
                    Sms.ExpelType = dt.Rows[i][2].ToString();
                    Sms.Sms = "【解除劳动合同通知】" + ChineseConverter.Convert(Sms.Name, ChineseConversionDirection.TraditionalToSimplified) +
                        "（工号：" + Sms.EmpNo + "，身份证号：" + dt.Rows[i][5].ToString() + "），您在职时间为" +
                        DateTime.Parse(dt.Rows[i][6].ToString()).ToString("yyyy/MM/dd") + "至" + Sms.CloseDate + "，工作岗位为" +
                         ChineseConverter.Convert(dt.Rows[i][7].ToString(), ChineseConversionDirection.TraditionalToSimplified)
                        + "，因您违反公司规章制度，我公司与您之劳动合同于" + Sms.CloseDate + "解除，劳动关系终止，请您携带厂牌于" +
                        "下周五至公司办理未完成的交接手续，特此通知。系统自动发送，请勿直接回复短信。如有疑问，请联系人力资源处：" +
                        "0755-28129588-61800【" +
                        ChineseConverter.Convert(dt.Rows[i][8].ToString(), ChineseConversionDirection.TraditionalToSimplified) + "】";
                    if (dt.Rows[i][9].ToString() == "001") LH.Add(Sms);
                    else if (dt.Rows[i][9].ToString() == "002") HZ.Add(Sms);
                    else if (dt.Rows[i][9].ToString() == "003") NN.Add(Sms);
                    else if (dt.Rows[i][9].ToString() == "005") CQ.Add(Sms);
                    else if (dt.Rows[i][9].ToString() == "011") FII.Add(Sms);
                }
            }

            string err = "";

            if (LH.Count>1) err += SignOff.ExpelClosed(LH, MailTo.AsEnumerable().
                Where(s => s.Field<string>("F_PLANTNO") == "001").CopyToDataTable().Rows[0][0].ToString());
            if (HZ.Count > 1) err += SignOff.ExpelClosed(HZ, MailTo.AsEnumerable().
                Where(s => s.Field<string>("F_PLANTNO") == "002").CopyToDataTable().Rows[0][0].ToString());
            if (CQ.Count > 1) err += SignOff.ExpelClosed(CQ, MailTo.AsEnumerable().
                Where(s => s.Field<string>("F_PLANTNO") == "005").CopyToDataTable().Rows[0][0].ToString());
            if (NN.Count > 1) err += SignOff.ExpelClosed(NN, MailTo.AsEnumerable().
                Where(s => s.Field<string>("F_PLANTNO") == "003").CopyToDataTable().Rows[0][0].ToString());
            if (FII.Count > 1) err += SignOff.ExpelClosed(FII, MailTo.AsEnumerable().
                Where(s => s.Field<string>("F_PLANTNO") == "003").CopyToDataTable().Rows[0][0].ToString());

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功" + err,
                Data = DBHelper.Inserts(sqls, token.plant)
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }
        /// <summary>
        /// 获取打印旷工单信息
        /// </summary>
        /// <param name="apply_nos"></param>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/AbsenteeismDcoument")]
        public HttpResponseMessage AbsenteeismDcoument(string apply_nos)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string[] applys = JsonConvert.DeserializeObject<string[]>(apply_nos);
            string sqls = "select f_empno,f_artificial,f_subbu,TO_CHAR(f_infactorydate, 'YYYY/MM/DD') as f_infactorydate" +
                " from tb_employe where f_empno='"+ applys[0] + "'";
            for(int i = 1; i < applys.Length; i++)
            {
                sqls += " or f_empno='" + applys[i] + "'";
            }
            DataTable dt = DBHelper.Queues(sqls,token.plant);
            List<Dictionary<string, string>> list = new List<Dictionary<string, string>>();
            for(int i = 0; i < applys.Length; i++)
            {
                Dictionary<string, string> dic = new Dictionary<string, string>();
                DataTable dts = dt.AsEnumerable().Where(
                    s => s.Field<string>("F_EMPNO") == applys[i]).CopyToDataTable();

                dic.Add("f_artificial", dts.Rows[0]["F_ARTIFICIAL"].ToString());
                dic.Add("f_subbu", dts.Rows[0]["F_SUBBU"].ToString());
                dic.Add("f_infactorydate", dts.Rows[0]["F_INFACTORYDATE"].ToString());
                list.Add(dic);
            }

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = list
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        #endregion

        #region 强制签核系列接口
        /// <summary>
        /// 获取待强制签核的单据
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetMandatory")]
        public HttpResponseMessage GetMandatory()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);

            string sqls = "select apply_no,emp_no,name,duty,(select f_name from tb_employe where f_empno=tbr) as tbr," +
                "tbr_tel,remark,file_name,jc_yj,jc_tl," +
                "CASE WHEN f_changetype='是' THEN CASE WHEN f_jcdj_new = '開除' THEN f_delistype ELSE f_jcdj_new END " +
                "ELSE CASE  WHEN jc_dj = '開除' THEN f_delistype ELSE jc_dj END END AS jc_dj," +
                "jc_type,edittime,hr_check,signer,signertype,agent,signtime,status,jc_dj_type,hr_file_name,f_occurdate," +
                "f_jcitemno,f_jcitemcontent,f_absentdate,f_delistype,f_changetype,f_jcdj_new," +
                "ROUND((sysdate - emp.f_infactorydate) / 365, 2) as infactory,f_changereason,emp.f_departname,emp.f_grand," +
                "jc.time_year,f_isspecialstation from tb_jc_apply jc,tb_employe emp,tb_organization org where " +
                "jc.emp_no = emp.f_empno and emp.f_organno = org.f_organno and status='待簽核' " +
                "and signtime<sysdate-3 order by edittime";
            

            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sqls, token.plant)
            };

            return Jsons.JsonData(JsonConvert.SerializeObject(code,new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        #endregion
        #endregion


        #region 纸档签核设定
        /// <summary>
        /// 获取当前设定的签核主管
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/GetPaperMange")]
        public HttpResponseMessage GetPaperMange()
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            string sql = "select TE.F_EmpNo,TE.F_Name,TH.F_WindowType,TH.F_WindowName,TH.F_PlantNo,TH.F_Mail from TB_Employe TE,TB_HRWindow " +
                "TH where TE.F_EmpNo=TH.F_EmpNo and F_WindowType='HRLeaderWin_Paper_JC'";
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功",
                Data = DBHelper.Queues(sql, token.plant)
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        /// <summary>
        /// 设定签核主管
        /// </summary>
        /// <returns></returns>
        [Token]
        [HttpPost]
        [Route("IncentiveManage/SettingPaper")]
        public HttpResponseMessage SettingPaper(string empno,string plant)
        {
            Token token = JsonConvert.DeserializeObject<Token>(HttpContext.Current.Request.Headers["token"]);
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = "成功"
            };
            if (DBHelper.Queues("select * from tb_employe where f_empno='" + empno + "'", token.plant).Rows.Count < 1)
            {
                code.Code = "500";
                code.Message = "工號不正確";
                return Jsons.JsonData(JsonConvert.SerializeObject(code));
            }
            ElistQuerySoapClient Elist = new ElistQuerySoapClient();
            string Notes_ID = Elist.ByUserID(empno).Tables[0].Rows[0]["Notes_ID"].ToString();
            string sql = "update TB_HRWindow set f_empno = '" + empno + "', f_mail = '" + Notes_ID + "', f_sysid = '"+ token.Emp + "', " +
                "f_sysdate = sysdate where F_WindowType = 'HRLeaderWin_Paper_JC'";
            code.Data = DBHelper.Inserts(sql, token.plant);

            return Jsons.JsonData(JsonConvert.SerializeObject(code, new IsoDateTimeConverter() { DateTimeFormat = "yyyy/MM/dd" }));
        }
        #endregion
        /// <summary>
        /// 测试接口
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("IncentiveManage/ceshi")]
        public HttpResponseMessage ceshi(string apply_no)
        {
            Workflow workflow = new Workflow();
            string Approver = workflow.GetNextApprover("HRM_JC", apply_no).Tables[0].Rows[0]["StationName"].ToString().Trim();
            //
            ReturnCode code = new ReturnCode()
            {
                Code = "200",
                Message = (Approver == "").ToString()
            };
            return Jsons.JsonData(JsonConvert.SerializeObject(code));
        }


    }
}