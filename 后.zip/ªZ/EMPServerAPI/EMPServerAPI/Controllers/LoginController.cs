﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using EMPServerAPI.Models;
using Newtonsoft.Json;

namespace EMPServerAPI.Controllers
{
    public class LoginController : ApiController
    {
        // GET: Login
        public HttpResponseMessage Index(string empno,string password)
        {
            Dictionary<string,string> map = new Dictionary<string,string>();
            string token = "error";
            string sql = "select * from TB_ACCOUNT where f_account='" + empno + "'";
            DataTable dt = DBHelper.Queues(sql, "001");
            //debug
            if (empno == "F1339509")
            {
                token = DesEncrypt.GetToken(empno, "41", "001");
                map.Add("type", "41");
                map.Add("token", token);
                map.Add("plant","001");
                return Jsons.JsonData(JsonConvert.SerializeObject(map));
            }
            //测试
            try
            {
                if (dt.Rows.Count > 0)
                {
                    string plant = dt.Rows[0][9].ToString();
                    string sqls = "select TE.F_EmpNo,TE.F_Name,TH.F_WindowType,TH.F_WindowName,TH.F_PlantNo from TB_Employe " +
                        "TE,TB_HRWindow TH where TE.F_EmpNo=TH.F_EmpNo and TH.F_WindowType='HREmpWin_JC' and TE.f_empno='" + empno + "'";
                    string type = dt.Rows[0][5].ToString();
                    if (DBHelper.Queues(sqls, "001").Rows.Count > 0) type = "41";
                    if (empno.Contains("ADMIN")) empno = "sys";
                    token = DesEncrypt.GetToken(empno, type, plant);
                    map.Add("plant", plant);
                    map.Add("type", type);
                }
                map.Add("token", token);
                return Jsons.JsonData(JsonConvert.SerializeObject(map));
            }
            catch (Exception ex)
            {
                return Jsons.JsonData(JsonConvert.SerializeObject(ex.Message));
            }

        }
        
    }
}