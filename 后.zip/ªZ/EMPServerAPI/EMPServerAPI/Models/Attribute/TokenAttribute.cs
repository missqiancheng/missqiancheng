﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Cors;
using System.Web.Http.Filters;
using System.Web.Http.Results;
using System.Web.UI.WebControls;
using EMPServerAPI.Models;
using EMPServerAPI.Models.model;
using Newtonsoft.Json;
using Microsoft.Ajax.Utilities;
using Swashbuckle.Swagger;

namespace EMPServerAPI.Models
{
    public class TokenAttribute: ActionFilterAttribute
    {
        //执行action后判断token
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            base.OnActionExecuted(actionExecutedContext);
        }
        //执行action前判断token
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            string token = HttpContext.Current.Request.Headers["token"];

            //测试环境
            Token tokne = new Token();
            tokne.Emp = "X2000926";
            tokne.plant = "001";
            tokne.Times = new DateTime();
            tokne.permissions = "41";
            HttpContext.Current.Request.Headers["token"] = JsonConvert.SerializeObject(tokne);


            //正式环境
            //(Token, ReturnCode) tokencode = DesEncrypt.CheckToken(token);
            //if (tokencode.Item2.Code != "200")
            //{
            //    actionContext.Response = Jsons.JsonData(JsonConvert.SerializeObject(tokencode.Item2));
            //    return;
            //}
            //HttpContext.Current.Request.Headers["token"] = JsonConvert.SerializeObject(tokencode.Item1);

            base.OnActionExecuting(actionContext);
        }
    }
}