﻿using Microsoft.Ajax.Utilities;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;



namespace EMPServerAPI.Models
{
    public class DBHelper
    {
        //001龙华  002 杭州 005重庆 003 南宁
        //数据库连接池
        static OracleConnection conn;
        /// <summary>
        /// 数据库连接池
        /// </summary>
        //初始化数据库连接字符串
        //龙华
        public static void DataBases()
        {
            //数据源字符串其中localhost是你oracle数据库的机器ip,port是你oracle数据库的端口号,IRON是你的用户名
            string connString = (@"DATA SOURCE= (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.132.36.94)(PORT = 1521))
            (CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = CNSBGHRT)));PASSWORD=apadmin169!;USER ID=ap");
            conn = new OracleConnection(connString);
        }
        //南宁字符串
        public static void DataBases(string plant)
        {
            //数据源字符串其中localhost是你oracle数据库的机器ip,port是你oracle数据库的端口号,IRON是你的用户名
            string connString = (@"DATA SOURCE= (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.132.36.94)(PORT = 1521))
            (CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = CNSBGHRT)));PASSWORD=apadmin169!;USER ID=ap");
            conn = new OracleConnection(connString);
        }

        public static OracleDataReader getShow(string sql,string plan)
        {
            conn.Open();
            OracleCommand cmd = new OracleCommand(sql, conn);
            OracleDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            return rd;
        }
        /// <summary>
        /// 查询操作  方法跟ADO.NET的操作基本一样
        /// </summary>
        /// <param name="sql">要执行的sql脚本</param>
        /// <param plant="plant">厂区</param>
        /// <returns></returns>
        public static DataTable Queues(string sql,string plant)
        {
            DataTable ds = new DataTable();
            if (plant.Length > 3)
            {
                Dictionary<string, bool> plants = new Dictionary<string, bool>();
                plants.Add("NN", false);
                plants.Add("LH", false);
                for (int i = 0; i <= plant.Length/4; i += 4)
                {
                    if (plant.Substring(4*i,3)=="003")
                    {
                        plants["NN"] = true;
                    }
                    else
                    {
                        plants["LH"] = true;
                    }
                }
                if (plants["LH"] && plants["NN"])
                {
                    for(int i = 0; i < 2; i++)
                    {
                        if(i==0) DataBases("plant");
                        else DataBases();
                        conn.Open();
                        OracleCommand cmd = new OracleCommand(sql, conn);
                        OracleDataAdapter dap = new OracleDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        dap.Fill(dt);
                        dap.Dispose();
                        conn.Close();
                        ds.Merge(dt);
                    }
                }
                else if (plants["NN"])
                {
                    DataBases("plant");
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(sql, conn);
                    OracleDataAdapter dap = new OracleDataAdapter(cmd);
                    dap.Fill(ds);
                    dap.Dispose();
                    conn.Close();
                }
                else
                {
                    DataBases();
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(sql, conn);
                    OracleDataAdapter dap = new OracleDataAdapter(cmd);
                    dap.Fill(ds);
                    dap.Dispose();
                    conn.Close();
                }
            }
            else
            {
                if (plant == "003") DataBases("plant");
                else DataBases();
                conn.Open();
                OracleCommand cmd = new OracleCommand(sql, conn);
                OracleDataAdapter dap = new OracleDataAdapter(cmd);
                dap.Fill(ds);
                dap.Dispose();
                conn.Close();
            }
            return ds;
        }
        /// <summary>
        /// 添加方法
        /// </summary>
        /// <param name="sql"></param>
        /// <param plant="plant"></param>
        /// <returns></returns>
        public static int Inserts(string sql,string plant)
        {
            if (plant == "003") DataBases("plant");
            else DataBases();
            conn.Open();
            OracleCommand cmd = new OracleCommand(sql, conn);
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            return i;
        }
        
    }
}