﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using EMPServerAPI.Models;
using Antlr.Runtime;
using Newtonsoft.Json;
using System.Runtime.Serialization;
using Newtonsoft.Json.Converters;
using System.Web.Helpers;
using EMPServerAPI.Models.model;

namespace EMPServerAPI.Models
{
    public class DesEncrypt
    {
        //密钥长度8位
        private static byte[] _rgbKey = ASCIIEncoding.ASCII.GetBytes("Foxconnn");
        private static byte[] _rgbIV = ASCIIEncoding.ASCII.GetBytes("Foxconnn");

        /// <summary>
        /// DES加密
        /// </summary>
        /// <param name="text">需要加密的值</param>
        /// <returns>加密后的结果</returns>
        public static string Encrypt(string text)
        {
            DESCryptoServiceProvider dsp = new DESCryptoServiceProvider();
            using (MemoryStream memStream = new MemoryStream())
            {
                CryptoStream crypStream = new CryptoStream(memStream, dsp.CreateEncryptor(_rgbKey, _rgbIV), CryptoStreamMode.Write);
                StreamWriter sWriter = new StreamWriter(crypStream);
                sWriter.Write(text);
                sWriter.Flush();
                crypStream.FlushFinalBlock();
                memStream.Flush();
                return Convert.ToBase64String(memStream.GetBuffer(), 0, (int)memStream.Length);
            }
        }

        /// <summary>
        /// DES解密
        /// </summary>
        /// <param name="encryptText"></param>
        /// <returns>解密后的结果</returns>
        public static string Decrypt(string encryptText)
        {
            DESCryptoServiceProvider dsp = new DESCryptoServiceProvider();
            byte[] buffer = Convert.FromBase64String(encryptText);

            using (MemoryStream memStream = new MemoryStream())
            {
                CryptoStream crypStream = new CryptoStream(memStream, dsp.CreateDecryptor(_rgbKey, _rgbIV), CryptoStreamMode.Write);
                crypStream.Write(buffer, 0, buffer.Length);
                crypStream.FlushFinalBlock();
                return ASCIIEncoding.UTF8.GetString(memStream.ToArray());
            }
        }

        /// <summary>
        /// 获取Token
        /// </summary>
        /// <param emp="工号" permissions="权限"></param>
        /// <returns>Token</returns>
        public static string GetToken(string emp,string permissions,string plant)
        {
            Token tokens=new Token();
            tokens.Emp = emp;
            tokens.permissions = permissions;
            tokens.Times = DateTime.Now;
            //tokens.Times = DateTime.Parse("2023-8-4 00:00:00");
            tokens.plant = plant;
            IsoDateTimeConverter TimeFormat = new IsoDateTimeConverter();
            TimeFormat.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
            string token= JsonConvert.SerializeObject(tokens, TimeFormat);
            return Encrypt(token);
        }

        /// <summary>
        /// 验证Token是否合法  《20分钟》
        /// </summary>
        /// <param Token="要验证的Token"></param>
        /// <returns>Token</returns>
        public static (Token, ReturnCode) CheckToken(string Token)
        {
            string Tokens;
            ReturnCode code = new ReturnCode();
            try
            {
                Tokens = Decrypt(Token);
            }catch{
                code.Code = "401";
                code.Message = "Token错误";
                return (null,code);
            }
            Token token = JsonConvert.DeserializeObject<Token>(Tokens);
            TimeSpan DifferTime = DateTime.Now - token.Times;
            if(DifferTime.TotalMinutes>20)
            {
                code.Code = "401";
                code.Message = "Token过期";
                return (null, code);
            }
            code.Code = "200";
            code.Message = "请求成功";
            return (token, code);
        }

    }
}
