﻿using EMPServerAPI.ElistQuery;
using MathNet.Numerics.LinearAlgebra.Factorization;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace EMPServerAPI.Models
{
    public class GetAgent
    {
        /// <summary>
        /// 获取代理人
        /// </summary>
        /// <param name="Leader_EmpNo"></param>
        /// <param name="OrganNo"></param>
        /// <returns></returns>
        public static string Agent(string Leader_EmpNo,string OrganNo = "")
        {
            ElistQuerySoapClient ElistQuerys = new ElistQuerySoapClient();
            DataTable AgentTable = new DataTable();
            string Agent = "";
            try
            {
                if (!LeaderIsWork(Leader_EmpNo))
                {
                    AgentTable = ElistQuerys.ByUserID_FindAgent(Leader_EmpNo, OrganNo).Tables[0];
                    if (AgentTable.Rows.Count > 0)
                    {
                        for (int i = 0; i < AgentTable.Rows.Count; i++)
                        {
                            if (AgentTable.Rows[i]["NotDuty"].ToString() == "No" && AgentTable.Rows[i]["Travel"].ToString() == "No")
                            {
                                Agent = AgentTable.Rows[i]["User_ID"].ToString();
                            }
                        }
                    }
                    
                }
                return Agent;
            }
            catch
            {
                return "";
            }       
        }
        public static bool LeaderIsWork(string EmpNo)
        {
            ElistQuerySoapClient ElistQuerys = new ElistQuerySoapClient();
            try
            {
                DataTable dt = ElistQuerys.ByUserID(EmpNo).Tables[0];
                if (dt.Rows.Count > 0)
                {
                    string IsLeave = dt.Rows[0]["NotDuty"].ToString();
                    string IsEvection = dt.Rows[0]["Travel"].ToString();
                    if (IsLeave == "Yes" || IsEvection == "YEs") return false;
                }
                return !ElistQuerys.ByUserID_FindAgentSite(EmpNo, "龍華廠");
            }
            catch
            {
                return true;
            }

        }
    }
}