﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EMPServerAPI.Models.Health
{
    public class HealthNumber
    {
        public static string Get(string plant)
        {
            string HealthNumber = DBHelper.Queues("select healthno from CNSBGHR.Tb_health", plant).Rows[0][0].ToString();
            DateTime dateTime = DateTime.Now;
            string ModelNumber = "JK" + dateTime.Year + dateTime.Month + dateTime.Day;
            if (HealthNumber.Contains(ModelNumber))
            {
                HealthNumber = ModelNumber + (int.Parse(HealthNumber.Substring(10, 3)) + 1);
            }
            else
            {
                HealthNumber = ModelNumber + "001";
            }
            return HealthNumber;
        }
    }
}