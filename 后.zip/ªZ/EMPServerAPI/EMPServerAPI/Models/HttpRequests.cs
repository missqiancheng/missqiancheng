﻿using Microsoft.International.Converters.TraditionalChineseToSimplifiedConverter;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Infrastructure
{
    public class HttpRequests
    {
        /// <summary>
        /// 发起POST同步请求
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postData"></param>
        /// <param name="contentType">application/xml、application/json、application/text、application/x-www-form-urlencoded</param>
        /// <param name="headers">填充消息头</param>        
        /// <returns></returns>
        public static string HttpPost(string url, string postData = null, string contentType = null, int timeOut = 30, Dictionary<string, string> headers = null)
        {
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            postData = postData ?? "";
            using (HttpClient client = new HttpClient())
            {
                if (headers != null)
                {
                    foreach (var header in headers)
                        client.DefaultRequestHeaders.Add(header.Key, header.Value);
                }
                using (HttpContent httpContent = new StringContent(postData, Encoding.UTF8))
                {
                    if (contentType != null)
                        httpContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType);

                    HttpResponseMessage response = client.PostAsync(url, httpContent).Result;
                    return response.Content.ReadAsStringAsync().Result;
                }
            }
        }
        /// <summary>
        /// 同步文件到服务器
        /// </summary>
        /// <param name="url"></param>
        /// <param name="PathBase">文件base</param>
        /// <param name="FileStream">文件流</param>
        /// <param name="filename">文件名，带后缀</param>
        /// <returns></returns>
        public static string UploadRequest(string PathBase, Stream[] FileStream, string[] filename)
        {
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            using (var formData = new MultipartFormDataContent())
            {
                for (int i = 0; i < FileStream.Length; i++)
                {
                    MemoryStream memoryStream = new MemoryStream();
                    FileStream[i].CopyTo(memoryStream);
                    // 添加文件参数
                    byte[] fileData = memoryStream.ToArray();
                    ByteArrayContent fileContent = new ByteArrayContent(fileData); 
                    fileContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                    formData.Add(fileContent, "file", Uri.EscapeDataString(
                        ChineseConverter.Convert(filename[i], ChineseConversionDirection.SimplifiedToTraditional)));
                }
                
                formData.Add(new StringContent(PathBase), "PathBase");
                HttpClient httpClient = new HttpClient();
                //http://10.132.37.44:7664/FileManage.asmx/UploadFiles
                //https://waptest.cnsbg.efoxconn.com:7664/FileManage.asmx

                HttpResponseMessage response = httpClient.PostAsync("https://waptest.cnsbg.efoxconn.com:7664/FileManage.asmx/UploadFiles",
                    formData).Result;
                return response.Content.ReadAsStringAsync().Result;
            }
        }


        /// <summary>
        /// 发起POST异步请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postData"></param>
        /// <param name="contentType">application/xml、application/json、application/text、application/x-www-form-urlencoded</param>
        /// <param name="headers">填充消息头</param>        
        /// <returns></returns>
        public static async Task<string> HttpPostAsync(string url, string postData = null, string contentType = null, int timeOut = 30, Dictionary<string, string> headers = null)
        {
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            postData = postData ?? "";
            using (HttpClient client = new HttpClient())
            {
                client.Timeout = new TimeSpan(0, 0, timeOut);
                if (headers != null)
                {
                    foreach (var header in headers)
                        client.DefaultRequestHeaders.Add(header.Key, header.Value);
                }
                using (HttpContent httpContent = new StringContent(postData, Encoding.UTF8))
                {
                    if (contentType != null)
                        httpContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType);

                    HttpResponseMessage response = await client.PostAsync(url, httpContent);
                    return await response.Content.ReadAsStringAsync();
                }
            }
        }

        /// <summary>
        /// 发起GET同步请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers"></param>
        /// <param name="contentType"></param>
        /// <returns></returns>
        public static string HttpGet(string url, Dictionary<string, string> headers = null)
        {
            using (HttpClient client = new HttpClient())
            {
                if (headers != null)
                {
                    foreach (var header in headers)
                        client.DefaultRequestHeaders.Add(header.Key, header.Value);
                }
                else
                {
                    client.DefaultRequestHeaders.Add("ContentType", "application/x-www-form-urlencoded");
                    client.DefaultRequestHeaders.Add("UserAgent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                }
                try
                {
                    HttpResponseMessage response = client.GetAsync(url).Result;
                    return response.Content.ReadAsStringAsync().Result;
                }
                catch (Exception ex)
                {
                    //TODO 打印日志
                    Console.WriteLine($"[Http请求出错]{url}|{ex.Message}");
                }
                return "";
            }
        }

        /// <summary>
        /// 发起GET异步请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers"></param>
        /// <returns></returns>
        public static async Task<string> HttpGetAsync(string url, Dictionary<string, string> headers = null)
        {
            using (HttpClient client = new HttpClient())
            {
                if (headers != null)
                {
                    foreach (var header in headers)
                        client.DefaultRequestHeaders.Add(header.Key, header.Value);
                }
                HttpResponseMessage response = await client.GetAsync(url);
                return await response.Content.ReadAsStringAsync();
            }
        }
        /// <summary>
        /// 将xml转为DataSet
        /// </summary>
        public static DataTable XmlToDataTable(string xmlStr)
        {

            if (!string.IsNullOrEmpty(xmlStr))
            {
                try
                {
                    DataSet ds = new DataSet();
                    using (StringReader StrStream = new StringReader(xmlStr))
                    {
                        using (XmlTextReader Xmlrdr = new XmlTextReader(StrStream))
                        {
                            while (Xmlrdr.Read())
                            {
                                if (Xmlrdr.IsStartElement())
                                {
                                    //return only when you have START tag  
                                    switch (Xmlrdr.Name.ToString())
                                    {
                                        case "boolean":
                                            string a = Xmlrdr.ReadString();
                                            Console.WriteLine("The Name of the Student is " + Xmlrdr.ReadString());
                                            break;
                                        case "Grade":
                                            Console.WriteLine("The Grade of the Student is " + Xmlrdr.ReadString());
                                            break;
                                        case "string":
                                            string c = Xmlrdr.ReadString();
                                            Console.WriteLine("The Grade of the Student is " + Xmlrdr.ReadString());
                                            break;
                                    }
                                }
                            }
                            ds.ReadXml(Xmlrdr);
                        }
                    }
                    return ds.Tables[0];
                }
                catch (Exception)
                {
                    return null;
                }
            }
            return null;
        }
        /// <summary>
        /// xml转bool
        /// </summary>
        /// <param name="xmlStr"></param>
        /// <returns></returns>
        public static string XmlToBool(string xmlStr)
        {
            if (!string.IsNullOrEmpty(xmlStr))
            {
                try
                {
                    DataSet ds = new DataSet();
                    using (StringReader StrStream = new StringReader(xmlStr))
                    {
                        using (XmlTextReader Xmlrdr = new XmlTextReader(StrStream))
                        {
                            while (Xmlrdr.Read())
                            {
                                if (Xmlrdr.IsStartElement())
                                {
                                    //return only when you have START tag  
                                    if (Xmlrdr.Name.ToString()=="boolean")
                                    {
                                        return Xmlrdr.ReadString(); 
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    return null;
                }
            }
            return null;
        }
        /// <summary>
        /// xml转string
        /// </summary>
        /// <param name="xmlStr"></param>
        /// <returns></returns>
        public static string XmlToString(string xmlStr)
        {
            if (!string.IsNullOrEmpty(xmlStr))
            {
                try
                {
                    DataSet ds = new DataSet();
                    using (StringReader StrStream = new StringReader(xmlStr))
                    {
                        using (XmlTextReader Xmlrdr = new XmlTextReader(StrStream))
                        {
                            while (Xmlrdr.Read())
                            {
                                if (Xmlrdr.IsStartElement())
                                {
                                    //return only when you have START tag  
                                    if (Xmlrdr.Name.ToString() == "string")
                                    {
                                        return Xmlrdr.ReadString();
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    return null;
                }
            }
            return null;
        }

        /// <summary>
        /// dic转为params参数
        /// </summary>
        /// <param name="dic"></param>
        /// <returns></returns>
        public static string DictionaryToParams(Dictionary<string,string> dic)
        {
            string Params = "";
            foreach(string keys in dic.Keys)
            {
                Params += "&" + keys + "=" + dic[keys];
            }   
            return Params.Remove(0,1);
        }
    }
}
