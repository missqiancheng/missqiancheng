﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace EMPServerAPI.Models
{
    public class Imports
    {
        // 委托声明
        public delegate string CheckImport(List<ISheet> s,Token token);
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FilePath">文件地址</param>
        /// <param name="Check">check数据方法</param>
        /// <param name="token">token</param>
        /// <returns></returns>
        public static string ImportExcel(string FilePath, CheckImport Check, Token token)
        {
            //获取excel文件
            IWorkbook ReadWorkbook = null;
            // 获取扩展名
            string ExtensionName = System.IO.Path.GetExtension(FilePath);
            FileStream FileStream = new FileStream(FilePath, FileMode.Open, FileAccess.ReadWrite);
            if (ExtensionName.Equals(".xls"))
            {
                ReadWorkbook = new HSSFWorkbook(FileStream);
            }
            else if (ExtensionName.Equals(".xlsx"))
            {
                ReadWorkbook = new XSSFWorkbook(FileStream);
            }
            else
            {
                return "文件格式不正确";
            }
            FileStream.Close();

            //获取sheet表
            List<ISheet> Sheets = null;
            Sheets = new List<ISheet>();
            int SheetCount = ReadWorkbook.NumberOfSheets;
            if (SheetCount < 1)
            {
                return "没有创建sheet表";
            }
            for (int i = 0; i < SheetCount; i++)
            {
                Sheets.Add(ReadWorkbook.GetSheetAt(i));
            }

            //check内容
            string sql = Check(Sheets, token);
            if (!sql.Contains("begin"))
            {
                return sql;
            }

            DBHelper.Inserts(sql, token.plant);

            return "执行成功";
        }
    }
}