﻿using EMPServerAPI.OHSMS_Medical;
using EMPServerAPI.WorkFlow;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace EMPServerAPI.Models.Incentive
{
    public class AddDcoument
    {
        //重载
        public AddDcoument(string plant)
        {
            plants = plant;
        }
        //厂区
        private static string plants;
        //jc条例表
        private static DataTable _Jc_itemDB;
        internal static DataTable Jc_itemDB
        {
            get
            {
                if (_Jc_itemDB == null)
                {
                    string sql = "select f_jcitemno,f_jcitemtype,f_jctl,f_jcitemcontent,f_jcdj,f_jctype from tb_jc_item";
                    _Jc_itemDB = DBHelper.Queues(sql,plants);
                    return _Jc_itemDB;
                }else return _Jc_itemDB;
            }
        }
        //旷工记录表
        private static DataTable _Absenteeismdate;
        internal static DataTable Absenteeismdate
        {
            get
            {
                if (_Absenteeismdate == null)
                {
                    string sql = "select f_empno,f_dutydate,f_modifyresult,f_daytype from tb_analyse where " +
                        "f_dutydate<=to_char(sysdate-1,'yyyy/MM/dd') and f_dutydate>=to_char(add_months(sysdate,-4),'yyyy/MM/dd') and " +
                        "f_modifyresult='曠工E' and f_beginwork is null and f_beginrest is null and f_endrest is null and f_endwork is null " +
                        "and f_daytype='G1' order by f_dutydate";
                    _Absenteeismdate = DBHelper.Queues(sql,plants);
                    return _Absenteeismdate;
                }
                else return _Absenteeismdate;

            }
        }
        //存储的单号
        private string apply;
        /// <summary>
        /// 获取奖惩单号
        /// </summary>
        /// <param name="plant">厂区</param>
        /// <returns></returns>
        //修改出事生成单据号
        public string GetApply(string plant)
        {
            string applys;
            string Today = DateTime.Now.ToString("yyyyMMdd");
            if (apply != null)
            {
                applys = apply;
            }
            else
            {
                string applysql = "select Max(apply_no) from tb_jc_apply where apply_no like 'JC" + Today + "%'";
                //请求数据
                applys = DBHelper.Queues(applysql, plant).Rows[0][0].ToString();
            }

            if (applys == "")
            {
                applys = "JC" + Today + "0112";
                apply = applys;
            }
            else
            {
                applys = applys.Length == 10 ? applys : applys + 1;
                string a = (int.Parse(applys.Substring(8, 6)) + 1).ToString();
                applys = "JC" + Today + a.Substring(a.Length - 4, 4);
                apply = applys;
            }
            return applys;
        }
        /// <summary>
        /// 获取添加奖惩单sql
        /// </summary>
        /// <param name="apply_no">1.单号</param>
        /// <param name="emp_no">2.工号</param>
        /// <param name="name">3.姓名</param>
        /// <param name="duty">4.担当</param>
        /// <param name="tbr">5.提报人</param>
        /// <param name="tbr_tel">6.提报人电话</param>
        /// <param name="remark">7.提报理由</param>
        /// <param name="file_name">8.证明文件</param>
        /// <param name="jc_yj">9.奖惩依据</param>
        /// <param name="jc_tl">10.奖惩条例</param>
        /// <param name="jc_dj">11.奖惩等级</param>
        /// <param name="jc_type">12.奖惩类型</param>
        /// <param name="hr_file_name">25.变更参考文件</param>
        /// <param name="f_occurdate">27.奖惩发生日期</param>
        /// <param name="f_delistype">28.開除类型</param>
        /// <param name="f_jcitemno">31.变更奖惩单号</param>
        /// <param name="f_jcitemcontent"> 32.奖惩条例内容</param>
        /// <param name="f_absentdate">33.旷工日期</param>
        /// <param name="f_changetype">34.是否变更奖惩等级</param>
        /// <param name="f_jcdj_new">35.,变更奖惩等级</param>
        /// <param name="f_changereason">36.变更处理类别理由</param>
        /// <param name="jsondata">37.领导Json数据</param>
        /// <param name="ApplicationType">特殊字段（紙檔簽核，調前記錄）</param>
        /// <param name="f_isspecialstation">是否职业健康体检</param>
        /// <returns></returns>
        public static (string,string) AddIncentive(string apply_no, string emp_no,string name,string duty,string tbr,string tbr_tel,
            string remark,string file_name,string jc_yj,string jc_tl,string jc_dj,string jc_type,string hr_file_name, 
            DateTime f_occurdate,string f_delistype,string f_jcitemno,string f_jcitemcontent,string f_absentdate, string f_changetype, 
            string f_jcdj_new,string f_changereason,string jsondata,string ApplicationType,string f_isspecialstation)
        {
            //1.apply_no,--单号
            //13.edittime,--编辑时间
            //14.hr_check,
            //15.signer,--签核人
            string signer = "";
            //16.signertype,--签核类型
            string signertype = "";
            //17.agent,--代理人
            string agent = "";
            //18.signtime,--签核时间
            //19.status,--单据状态
            string status = "";
            //20.f_error,--null
            //21.is_upload,--是否上传修改附件
            //22.time_year,--年号
            if (ApplicationType != "紙檔簽核" && ApplicationType != "調前記錄")
            {
                Workflow workflow = new Workflow();
                DataTable NextApprover = workflow.GetNextApprover("HRM_JC", apply_no).Tables[0];
                signer = NextApprover.Rows[0]["Approver"].ToString();
                signertype = NextApprover.Rows[0]["StationName"].ToString();
                agent = GetAgent.Agent(signer);
                status = "待簽核";
            }
            else
            {
                signer = DBHelper.Queues("select f_empno from tb_hrwindow where " +
                    "F_WindowType='HRLeaderWin_Paper_JC'", "001").Rows[0][0].ToString();
                SendMail sends = new SendMail();
                
                status = ApplicationType + "(待簽核)";
            }
            string time_year = DateTime.Now.Year.ToString();
            //23.year_no,--公告号
            string year_no = "0";
            //24.jc_dj_type,--奖励单或惩罚单，值为J C
            string[] Incentive = new string[] { "嘉獎一次", "小功一次", "大功一次", "" };
            string jc_dj_type = (Incentive.Contains(jc_dj)) ? "J" : "C";

            //29.f_absentstart,--空
            //30.f_absentend,--空




            string sql = "select '" + apply_no +"','"+ emp_no + "','"+ name +"','"+ duty + "','"+ tbr + "','"+ tbr_tel +"'," +
                "'"+ remark + "','"+ file_name + "','" + jc_yj + "','"+ jc_tl + "','"+ jc_dj + "','"+ jc_type + "',sysdate,'','"+ signer + "'," +
                "'"+ signertype + "','"+ agent + "','','"+ status + "',''," + time_year + ","+ year_no + ",'"+ jc_dj_type + "'," +
                "'"+ hr_file_name + "','"+ f_occurdate.ToString("yyyy/MM/dd") + "','" + f_isspecialstation + "','"+ f_delistype + "','" +
                ""+ f_jcitemno + "','"+ f_jcitemcontent + "','"+ f_absentdate + "','"+ f_changetype + "','"+ f_jcdj_new + "','"+ f_changereason + 
                "','" + jsondata + "' from dual ";

            return (sql, (agent == "") ? signer : agent);
        }

        /// <summary>
        /// dt里有四筆數據或者dt里有連續曠工三天(工作日星期一至星期五)數據即可提交曠工開除
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static bool CheckAbsent(DataTable dt)
        {
            if(dt.Rows.Count < 3)
            {
                return false;
            }
            
            DateTime One = DateTime.Parse(dt.Rows[0]["F_DUTYDATE"].ToString());
            DateTime Two = DateTime.Parse(dt.Rows[1]["F_DUTYDATE"].ToString());
            DateTime Three = DateTime.Parse(dt.Rows[2]["F_DUTYDATE"].ToString());
            //间隔
            TimeSpan Interval = Two - One;
            TimeSpan Intervals = Three - Two;
            //连续三天为true
            return (Interval.TotalDays >= 1 && Interval.TotalDays < 2) && (Intervals.TotalDays >= 1 && Intervals.TotalDays < 2);
        }
    }
}