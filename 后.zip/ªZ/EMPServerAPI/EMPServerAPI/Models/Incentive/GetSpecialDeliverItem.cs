﻿using MathNet.Numerics.LinearAlgebra.Factorization;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using static NPOI.HSSF.Util.HSSFColor;
using EMPServerAPI.CheckBook;
using EMPServerAPI.CheckDimission;

namespace EMPServerAPI.Models.Incentive
{
    public class GetSpecialDeliverItem
    {
        public static string GetValue(string EmpNo)
        {
            string DeliveringItem = "";
            DataTable dsSpecialDeliver = 
                DBHelper.Queues("select F_ItemTypeName from TB_ItemTypeSetting where F_Type='Dimission_SpecialDeliver'", "001");

            for (int i = 0; i < dsSpecialDeliver.Rows.Count; i++) 
            {
                string arrSpeclalDeliverItem = dsSpecialDeliver.Rows[i][0].ToString();
                string arrIsSpecialDeliver = getIsSpecialDeliver(EmpNo, arrSpeclalDeliverItem);
                if (arrIsSpecialDeliver == "Y") DeliveringItem += arrSpeclalDeliverItem + ",";
            }

            //特殊崗位體檢、公祖房、股權激勵、集團圖書、A系統、工傷事宜、簽核權限
            if (GetIsProductDeliver(EmpNo) == "Y") DeliveringItem += "A系統,";
            if (getIsSpecialDeliver(EmpNo, "ReturnBook") == "Y") DeliveringItem += "集團圖書,";
            if (getIsSpecialDeliver(EmpNo, "工作手機") == "Y") DeliveringItem += "工作手機,";
            if (getIsSpecialDeliver(EmpNo, "事業群委培獎學金") == "Y") DeliveringItem += "事業群委培獎學金,";
            if (DBHelper.Queues("SELECT TE.F_EMPNO FROM TB_EMPLOYE TE,TB_LEADER_REDIRECT TL WHERE TE.F_EMPNO=" +
                "TL.F_EMPNO AND TE.F_ISLEAVE='N' AND TE.F_ISTAIWAN IN ('1','N') AND ';'||TL.F_ALLMANAGER||';' LIKE '%;"
                + EmpNo + ";%' AND ROWNUM<=1", "001").Rows.Count > 0) DeliveringItem += "簽核權限,";
            if (DeliveringItem == "") DeliveringItem += "無,";
            return DeliveringItem;
        }

        public static string GetIsProductDeliver(string EmpNo)
        {
            ServiceSoapClient serviceSoapClient = new ServiceSoapClient();
            //DataTable dt = 
            //    serviceSoapClient.CheckUser(EmpNo).Tables[0];
            if(false)
            {
                return "Y";
            }
            else
            {
                return "N";
            }
        }
        public static string getIsSpecialDeliver(string EmpNo, string DeliverItem)
        {
            DimissionServiceSoapClient dim = new DimissionServiceSoapClient();
            return dim.getIsSpecialDeliver(EmpNo, DeliverItem);
        }
    }
}