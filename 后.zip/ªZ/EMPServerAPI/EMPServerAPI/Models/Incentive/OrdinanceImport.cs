﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Web;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;


namespace EMPServerAPI.Models.Incentive
{
    public class OrdinanceImport
    {
        private static string plants;
        //参考文件表
        private static string[] _BookTable;
        private static string[] BookTable
        {
            get
            {
                if (_BookTable == null)
                {
                    DataTable dt = DBHelper.Queues("select Name from tb_jc_book", plants);
                    string[] BookName = new string[dt.Rows.Count];
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        BookName[i] = dt.Rows[i][0].ToString();
                    }
                    _BookTable = BookName;
                    return _BookTable;
                }
                else
                {
                    return _BookTable;
                }
            }
        }
        //奖惩等级表
        private static string[] _DjTable;
        private static string[] DjTable
        {
            get
            {
                if (_DjTable == null)
                {
                    DataTable dt = DBHelper.Queues("select name from tb_jc_dj", plants);
                    string[] djName = new string[dt.Rows.Count];
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        djName[i] = dt.Rows[i][0].ToString();
                    }
                    _DjTable = djName;
                    return _DjTable;
                }
                else
                {
                    return _DjTable;
                }
            }
        }
        //奖惩类型表
        private static string[] _TypeTable;
        private static string[] TypeTable
        {
            get
            {
                if (_TypeTable == null)
                {
                    DataTable dt = DBHelper.Queues("select name from tb_jc_type", plants);
                    string[] TypeName = new string[dt.Rows.Count];
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        TypeName[i] = dt.Rows[i][0].ToString();
                    }
                    _TypeTable= TypeName;
                    return _TypeTable;
                }
                else
                {
                    return _TypeTable;
                }
            }
        }
        //奖惩依据表
        private static DataTable _YjTalbe;
        private static DataTable YjTalbe
        {
            get
            {
                if(_YjTalbe == null)
                {
                    DataTable dt = DBHelper.Queues("select f_jctl,f_jcitemtype from tb_jc_item", plants);
                    _YjTalbe= dt;
                    return _YjTalbe;
                }
                else
                {
                    return _YjTalbe;
                }
            }
        }

        /// <summary>
        /// 获取 Sheet 表数据
        /// </summary>
        /// <param name="Sheet"></param>
        public static string CheckData(List<ISheet> Sheets,Token token)
        {
            plants = token.plant;
            string sql = "begin ";
            string times = DateTime.Now.ToString("yyyyMMddHHmmss")+"0000";
            long timesno = long.Parse(times);
            for (int i=0;i< Sheets.Count; i++)
            {
                if (Sheets[i] == default)
                {
                    return "有空的sheet表";
                }
                for (int j = 1; j <= Sheets[i].LastRowNum; j++)
                {
                    // 获取具体行
                    IRow row = Sheets[i].GetRow(j);
                    if (row != null)
                    {
                        string yj = row.GetCell(0).ToString(), tl = row.GetCell(1).ToString(), content = row.GetCell(2).ToString(),
                        dj = row.GetCell(3).ToString(), type = row.GetCell(4).ToString();
                        if (yj==null||tl==null||content==null||dj==null||type==null)
                        {
                            empty();
                            return "第" + j + "行有单元格为空";
                        }
                        //判断是否有重复数据
                        for (int k = j-1; k > 0; k--)
                        {
                            if(Sheets[i].GetRow(k).GetCell(0).ToString() == yj && Sheets[i].GetRow(k).GetCell(1).ToString() ==tl &&
                                Sheets[i].GetRow(k).GetCell(3).ToString() == dj && Sheets[i].GetRow(k).GetCell(2).ToString() == content)
                            {
                                empty();
                                return "有重复数据" + j + "and" + k;
                            }
                        }
                        if (!BookTable.Contains(yj))
                        {
                            empty();
                            return "第" + j + "行奖惩依据文件不存在";
                        }
                        if (!DjTable.Contains(dj))
                        {
                            empty();
                            return "第" + j + "行奖惩等级不存在";
                        }
                        if (!TypeTable.Contains(type))
                        {
                            empty();
                            return "第" + j + "行奖惩类型不存在";
                        }
                        int yjClounm = YjTalbe.AsEnumerable().Where(s => s.Field<string>("F_JCTL") == tl)
                            .Where(k=> k.Field<string>("F_JCITEMTYPE") == yj).Count();
                        if (yjClounm > 0)
                        {
                            empty();
                            return "第" + j + "行奖惩条例存在";
                        }
                        timesno++;
                        sql += "insert into tb_jc_item values('"+ timesno + "','"+ yj + "','"+ tl + "','"+ content + "','"+ dj + "','"+ type + "','"+ token.Emp + "',sysdate,'Y');";
                    }
                }
            }
            empty();
            return sql+ " end;";
        }
        //清空数据缓存
        private static void empty()
        {
            _BookTable = null;
            _DjTable = null;
            _TypeTable = null;
            _YjTalbe = null;
        }


    }
}