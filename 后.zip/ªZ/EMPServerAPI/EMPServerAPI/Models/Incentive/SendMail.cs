﻿using EMPServerAPI.ElistQuery;
using MathNet.Numerics.LinearAlgebra.Factorization;
using NPOI.SS.Formula.Functions;
using Org.BouncyCastle.Bcpg.OpenPgp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Security.Policy;
using System.Web.Helpers;
using NPOI.OpenXmlFormats.Dml;
using System.IO;
using static ICSharpCode.SharpZipLib.Zip.ExtendedUnixData;
using System.Runtime.InteropServices.ComTypes;
using NPOI.XWPF.UserModel;
using System.Threading.Tasks;

namespace EMPServerAPI.Models.Incentive
{
    public class SendMail
    {
        //邮件发送人
        string MailFrom = "nsd.system@foxconn.com";
        //邮件CC
        string MailCC = "kelly.fl.zhou@mail.foxconn.com";
        //签核网页地址
        string SignIP = "https://127.0.0.1:5173/#/IncentiveManage?navigation=IncentiveSign";
        //查询网页地址
        string SelectIP = "https://127.0.0.1:5173/#/IncentiveManage?navigation=IncentiveProgress";
        string MailMessage = "";
        /// <summary>
        /// 发送提醒签核邮件
        /// </summary>
        /// <param name="ToEmp">待签主管</param>
        public async Task<string> SignMail(string ToEmp)
        {
            try
            {
                (string MailTo, string ToName, string plant) = GetEmpNo_NotesID(ToEmp);
                //主题
                string Subject = ToName + "您好﹗您有一筆獎懲信息等待審核﹗";
                string ContactWindow = DBHelper.Queues("select F_Value from TB_Parameter where F_PlantNo='" 
                    + plant + "' and F_Name='JC Contact Window'", "001").Rows[0][0].ToString();
                if (ContactWindow == "") ContactWindow = "系統推動作業窗口 :周芳蓮 EXT: 61800 \nEmail: kelly.fl.zhou@mail.foxconn.com";
                //邮件主体
                string Body = "\n" + Subject + "\n\n" +
                    "系統網址: " + SignIP +
                    "用戶名及密碼同考勤管理系統\n\n\n\n  " +
                    ContactWindow + "\n\n";
                MailTo = "nsd-b2b-web@mail.foxconn.com";
                MailMessage = SendNotesMail(MailFrom, MailTo, MailCC, "", Subject, Body);
                return MailMessage;
            }
            catch(Exception ex)
            {
                return MailMessage + ToEmp + "發送Mail失敗，錯誤：" + ex.Message + "\n";
            }
        }
        /// <summary>
        /// 发送提醒取消邮件
        /// </summary>
        /// <param name="ToEmp">取消邮件</param>
        public async Task<string> CancelMail(string ToEmp)
        {
            try
            {
                (string MailTo, string ToName, string plant) = GetEmpNo_NotesID(ToEmp);
                //主题
                string Subject = ToName + "您好！ 您有一筆獎懲資訊已被取消！";
                string ContactWindow = DBHelper.Queues("select F_Value from TB_Parameter where F_PlantNo='"
                    + plant + "' and F_Name='JC Contact Window'", "001").Rows[0][0].ToString();
                if (ContactWindow == "") ContactWindow = "系統推動作業窗口 :周芳蓮 EXT: 61800 \nEmail: kelly.fl.zhou@mail.foxconn.com";
                //邮件主体
                string Body = "\n" + Subject + "\n\n" +
                    "系統網址: " + SelectIP +
                    "用戶名及密碼同考勤管理系統\n\n\n\n  " +
                    ContactWindow + "\n\n";

                MailTo = "nsd-b2b-web@mail.foxconn.com";
                MailMessage = SendNotesMail(MailFrom, MailTo, MailCC, "", Subject, Body);
                return MailMessage;
            }
            catch (Exception ex)
            {
                return MailMessage + ToEmp + "發送Mail失敗，錯誤：" + ex.Message + "\n";
            }
        }
        /// <summary>
        /// 发送提醒取消邮件
        /// </summary>
        /// <param name="ToEmp">工号</param>
        /// <param name="Emp">工号人</param>
        /// <param name="Name">姓名</param>
        public async Task<string> PhysicalExaminationMail(string ToEmp, string Emp,string Name)
        {
            try
            {
                (string MailTo, string ToName, string plant) = GetEmpNo_NotesID(ToEmp);
                //主题
                string Subject = "【溫馨提醒】您好！請確認職業健康監護崗位員工 " + 
                    Name + "（" + Emp + "） 的離崗體檢狀態";
                string ContactWindow = DBHelper.Queues("select F_Value from TB_Parameter where F_PlantNo='"
                    + plant + "' and F_Name='JC Contact Window'", "001").Rows[0][0].ToString();
                if (ContactWindow == "") ContactWindow = "系統推動作業窗口 :周芳蓮 EXT: 61800 \nEmail: kelly.fl.zhou@mail.foxconn.com";
                //邮件主体
                string Body = "\n" + Subject + "\n\n" +
                    "系統網址: " + SelectIP +
                    "用戶名及密碼同考勤管理系統\n\n\n\n  " +
                    ContactWindow + "\n\n";
                MailTo = "nsd-b2b-web@mail.foxconn.com";
                MailMessage = SendNotesMail(MailFrom, MailTo, MailCC, "", Subject, Body);
                return MailMessage;
            }
            catch (Exception ex)
            {
                return MailMessage + ToEmp + "發送Mail失敗，錯誤：" + ex.Message + "\n";
            }
        }
        /// <summary>
        /// 发送开除结案短信提醒邮件
        /// </summary>
        /// <param name="ToEmp">工号</param>
        /// <param name="FilePath">文件路径</param>
        public async Task<string> PhysicalSmsMail(string ToEmp,string FilePath)
        {
            try
            {
                (string MailTo, string ToName, string plant) = GetEmpNo_NotesID(ToEmp);
                //主题
                string Subject = ToName + "您好，附件為已結案的開除名單，請及時發送【解除勞動合同通知】短信";
                string ContactWindow = "系統推動作業窗口 :周芳蓮 EXT: 61800 \nEmail: kelly.fl.zhou@mail.foxconn.com";
                //邮件主体
                string Body = "\n" + Subject + "\n\n" +
                    ContactWindow + "\n\n";
                MailTo = "nsd-b2b-web@mail.foxconn.com";
                MailMessage = SendNotesMail(MailFrom, MailTo, MailCC, "", Subject, Body, FilePath);
                return MailMessage;
            }
            catch (Exception ex)
            {
                return MailMessage + ToEmp + "發送Mail失敗，錯誤：" + ex.Message + "\n";
            }
        }
        /// <summary>
        /// 发送提醒环安安排体检
        /// </summary>
        /// <param name="ToEmp">工号</param>
        /// <param name="Emp">工号</param>
        /// <param name="Name">姓名</param>
        public async Task<string> BodyCheckMail(string ToEmp, string Emp,string Name)
        {
            try
            {
                (string MailTo, string ToName, string plant) = GetEmpNo_NotesID(ToEmp);
                //主题
                string Subject = ToName + "【溫馨提醒】您好！請確認職業健康監護崗位員工 " + Name + "（" + Emp + "） 的離崗體檢狀態";
                string ContactWindow = "系統推動作業窗口 :周芳蓮 EXT: 61800 \nEmail: kelly.fl.zhou@mail.foxconn.com";
                //邮件主体
                string Body = "\n" + Subject + "\n\n" +
                    ContactWindow + "\n\n";
                MailTo = "nsd-b2b-web@mail.foxconn.com";
                MailMessage = SendNotesMail(MailFrom, MailTo, MailCC, "", Subject, Body);
                return MailMessage;
            }
            catch (Exception ex)
            {
                return MailMessage + ToEmp + "發送Mail失敗，錯誤：" + ex.Message + "\n";
            }
        }
        /// <summary>
        /// 发送提醒下级员工提报奖惩邮件
        /// </summary>
        /// <param name="ToEmp">工号</param>
        /// <param name="Emp">工号</param>
        /// <param name="Name">姓名</param>
        /// <param name="jc_dj">奖惩等级</param>
        /// <returns></returns>
        public async Task<string> LowerMail(string ToEmp, string Emp, string Name,string jc_dj)
        {
            try
            {
                (string MailTo, string ToName, string plant) = GetEmpNo_NotesID(ToEmp);
                //主题
                string Subject = "【溫馨提醒】" + ToName + "您好！您的下級員工 " + Name + "（" + Emp + "）已提报" + jc_dj + "的獎懲單據，請注意查看";
                string ContactWindow = "系統推動作業窗口 :周芳蓮 EXT: 61800 \nEmail: kelly.fl.zhou@mail.foxconn.com";
                //邮件主体
                string Body = "\n" + Subject + "\n\n" +
                    ContactWindow + "\n\n";
                MailTo = "nsd-b2b-web@mail.foxconn.com";
                MailMessage = SendNotesMail(MailFrom, MailTo, MailCC, "", Subject, Body);
                return MailMessage;
            }
            catch (Exception ex)
            {
                return MailMessage + ToEmp + "發送Mail失敗，錯誤：" + ex.Message + "\n";
            }
        }
        public static bool Judgement(string emp_No)
        {
            return (emp_No == "G5697753"
                    || emp_No == "G5697929" || emp_No == "G5666739"
                    || emp_No == "G5664893" || emp_No == "F1336014"
                    || emp_No == "G5592086" || emp_No == "G5452244"
                    || emp_No == "G5576886" || emp_No == "F4176634"
                    || emp_No == "F1411637");
        }


        private (string,string,string) GetEmpNo_NotesID(string empno)
        {
            string plant = "";
            string Name = "";
            string Notes_ID = "";
            try
            {
                string sqls = "select TL.F_EmpNo, TL.F_Emp_Mail as Notes_ID, TE.F_Name as User_Name, " +
                       "TL.F_Emp_JobTitle as Job_Title,TE.f_plantno from TB_Leader_Redirect TL, TB_Employe" +
                       " TE where TL.F_EmpNo=TE.F_EmpNo and TE.F_EmpNo='" + empno + "' union all select F_HRHQ as " +
                       "F_EmpNo,F_Mail as Notes_ID, F_Name as User_Name,'' as JobTitle,f_plantno from TB_HRHQ where '"
                       + empno + "' like '%'||F_HRHQ||'%'";
                DataTable dt = new DataTable();
                if (dt.Rows.Count == 0)
                {
                    ElistQuerySoapClient Elist = new ElistQuerySoapClient();
                    dt = Elist.ByUserID(empno).Tables[0];
                    if (dt.Rows[0]["USER_ID_EXT"].ToString().Trim() == "南寧廠")
                    {
                        plant = "003";
                    }
                    else if (dt.Rows[0]["USER_ID_EXT"].ToString().Trim() == "龍華廠")
                    {
                        plant = "001";
                    }
                    GC.Collect();
                }
                else
                {
                    plant = dt.Rows[0]["F_PLANTNO"].ToString().Trim();
                }
                Name = dt.Rows[0]["User_Name"].ToString().Trim();
                Notes_ID = dt.Rows[0]["Notes_ID"].ToString().Trim();
                return (Notes_ID, Name, plant);
            }
            catch (Exception ex)
            {
                GC.Collect();
                return (Notes_ID, Name, plant);
            }

        }
        private string SendNotesMail(string MailFrom, string MailTo, string MailCC, 
            string MailBCC, string Subject, string Body,string MailFile = "")
        {
            try
            {
                //MailFrom = "system@foxconn.com";
                if (MailTo == "Fang-Ming Lu/CEN/FOXCONN" || MailTo == "K.L. Lee/NSG/FOXCONN"
                    || MailTo == "Michael Ling/USA/FOXCONN" || MailTo.ToUpper().IndexOf("FANG-MING LU") > -1
                    || MailTo.ToUpper().IndexOf("K.L. LEE") > -1 || MailTo.ToUpper().IndexOf("MICHAEL LING") > -1
                    || MailTo.ToUpper().IndexOf("MICHAEL.LING") > -1 || MailTo.ToUpper().IndexOf("BRAND.CHENG") > -1)
                {
                    MailTo = "nsd-b2b-web@mail.foxconn.com";
                }
                if (MailCC == "Fang-Ming Lu/CEN/FOXCONN" || MailCC == "K.L. Lee/NSG/FOXCONN"
                    || MailCC == "Michael Ling/USA/FOXCONN" || MailCC.ToUpper().IndexOf("FANG-MING LU") > -1
                    || MailCC.ToUpper().IndexOf("K.L. LEE") > -1 || MailCC.ToUpper().IndexOf("MICHAEL LING") > -1
                    || MailCC.ToUpper().IndexOf("MICHAEL.LING") > -1 || MailCC.ToUpper().IndexOf("BRAND.CHENG") > -1)
                {
                    MailCC = "kelly.fl.zhou@mail.foxconn.com";
                }


                SMTService.SMTPServiceSoapClient Emails = new SMTService.SMTPServiceSoapClient();
                
                SMTService.MailStruct EmalisVal = new SMTService.MailStruct();
                EmalisVal.from = MailFrom;
                EmalisVal.mailto = MailTo;
                EmalisVal.cc = MailCC;
                EmalisVal.subject = Subject;
                EmalisVal.body = Body + "\n\n";
                EmalisVal.mediatype = "application/x-myType";
                EmalisVal.format = "TEXT";

                SMTService.ContainsKey SessionID = new SMTService.ContainsKey();
                if (MailFile != "")
                {
                    FileStream fs = new FileStream(MailFile, FileMode.Open);
                    byte[] byteobj = new byte[fs.Length];
                    fs.Read(byteobj, 0, byteobj.Length);
                    string fileNames = MailFile.Substring(MailFile.LastIndexOf("\\"));
                    Emails.SaveAttachment(ref SessionID, fileNames, byteobj);
                }
                //发送邮件
                Emails.SendMail(ref SessionID, EmalisVal);
                return "发送成功";
                
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}