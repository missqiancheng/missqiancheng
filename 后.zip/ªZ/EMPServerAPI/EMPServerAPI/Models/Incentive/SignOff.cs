﻿using EMPServerAPI.Models.model;
using EMPServerAPI.OHSMS_Medical;
using EMPServerAPI.WorkFlow;
using Newtonsoft.Json;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.WebPages;

namespace EMPServerAPI.Models.Incentive
{
    public class SignOff
    {
        private Dictionary<string,string> _Jc_Apply;
        internal Dictionary<string, string> Jc_Apply
        {
            get
            {
                if( _Jc_Apply == null)
                {
                    Dictionary<string,string> dic=new Dictionary<string,string>();
                    string sql = "select apply_no,leaderjson from tb_jc_apply";
                    DataTable dt = DBHelper.Queues(sql, plants);
                    for(int i = 0; i < dt.Rows.Count; i++)
                    {
                        dic.Add(dt.Rows[i][0].ToString(), dt.Rows[i][1].ToString());
                    }
                    _Jc_Apply = dic;
                    return _Jc_Apply;
                }else return _Jc_Apply;
            }
        }
        private static string plants;
        /// <summary>
        /// 通过签核执行
        /// </summary>
        /// <param name="Signs">签核状态</param>
        /// <param name="apply_no">单号</param>
        /// <param name="MEMO">签核原因</param>
        /// <param name="empno">签核人</param>
        /// <param name="plant">厂区</param>
        /// <param name="jc_dj">更改的奖惩等级</param>
        /// <returns></returns>
        public string Signer(string Signs, string apply_no, string MEMO,string empno,string plant, string jc_dj = null)
        {
            plants = plant;
            Workflow workflow = new Workflow();
            DataTable CurrentApprover = workflow.GetNextApprover("HRM_JC", apply_no).Tables[0];
            string signertype = (Signs == "紙檔簽核(待簽核)" || Signs == "調前記錄(待簽核)") ?
                "":CurrentApprover.Rows[0]["StationName"].ToString().Trim();
            //代理
            string agent = GetAgent.Agent(empno);
            //签核人职级
            string signerGrade = "";
            //添加签核记录sql
            string sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + empno + "','" + agent + "'," +
                "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'通過','" + signertype + "',sysdate,'" + signerGrade + "');";
            string sqlApply = "";
            if (Signs == "駁回")
            {
                sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + empno + "','" + agent + "'," +
                "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'不同意駁回','人資確認',sysdate,'" + signerGrade + "');";
                
                string signer = CurrentApprover.Rows[0]["Approver"].ToString();
                string Awaitagent = GetAgent.Agent(signer);
                SendMail sends = new SendMail();
                //代理 //发送签核提醒邮件
                string Result;
                if (Awaitagent != "") Result = sends.SignMail(Awaitagent).Result;
                else Result = sends.SignMail(signer).Result;
                sqlApply = "update tb_jc_apply set signer='" + signer + "',signertype='" + signertype + "'," +
                    "signtime=sysdate,status='待簽核',agent='" + Awaitagent + "' where apply_no='" + apply_no + "';";
            }
            else if (Signs == "紙檔簽核(待簽核)"|| Signs == "調前記錄(待簽核)")
            {
                sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + empno + "',''," +
                "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'通過','人資確認',sysdate,'" + signerGrade + "');";
                sqlApply = "update tb_jc_apply set signer='',signertype=''," +
                    "signtime=sysdate,status='"+ Signs.Substring(0, 4) + "',agent='' where apply_no='" + apply_no + "';";
            }
            else
            {
                //执行workflow
                string singers = CurrentApprover.Rows[0]["Approver"].ToString();
                workflow.CookieContainer = new System.Net.CookieContainer();
                string sdd = Jc_Apply[apply_no];
                List<Dictionary<string, string>> list = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(sdd);
                
                for (int i = 0; i < list.Count; i++)
                {
                    string keys = list[i].Keys.ToArray()[0];
                    workflow.FormAdd(keys, list[i][keys]);
                }
                //是否修改
                if (jc_dj != null)
                {
                    workflow.FormAdd("isModify", "Y");
                }
                else
                {
                    workflow.FormAdd("isModify", "N");
                }
                
                bool a = workflow.RunWorkflow("HRM_JC", apply_no, singers, "Approved", "");
                //string c = workflow.GetError();

                //修改单据表
                DataTable NextApprover = workflow.GetNextApprover("HRM_JC", apply_no).Tables[0];
                string signer = NextApprover.Rows[0]["Approver"].ToString();
                signertype = NextApprover.Rows[0]["StationName"].ToString();
                if(signertype == "人資初審")
                {
                    OHSMS_MedicalSoapClient ohs = new OHSMS_MedicalSoapClient();
                    string f_empno = DBHelper.Queues("select emp_no from tb_jc_apply where apply_no='" + apply_no 
                        + "'",plant).Rows[0][0].ToString();
                    ohs.ExecMedical_ByEmpNo(f_empno, "", "", out string err);
                }
                string status = "待簽核";
                //签核完毕
                string Approver = workflow.GetNextApprover("HRM_JC", apply_no).Tables[0].Rows[0]["StationName"].ToString().Trim();
                if (Approver == "")
                {
                    status = "待結案";
                    signer = "";
                    signertype = "";
                    string ErrMessage = workflow.GetError();
                    if (ErrMessage == "無法找到下一個流程的資料")
                    {
                        workflow.RunTerminate("HRM_JC", apply_no);
                    }
                    sqlHistory = sqlHistory.Replace("通過", "簽核完畢");
                }


                string Awaitagent = GetAgent.Agent(signer);
                SendMail sends = new SendMail();
                //代理 
                //发送签核提醒邮件
                string Result;
                if (Awaitagent != "") Result = sends.SignMail(Awaitagent).Result;
                else Result = sends.SignMail(signer).Result;
                

                //修改单据sql
                sqlApply = "update tb_jc_apply set signer='" + signer + "',signertype='" + signertype + "',signtime=sysdate," +
                    "status='" + status + "',agent='" + Awaitagent + "' where apply_no='" + apply_no + "';";
                if (jc_dj != null)
                {
                    sqlApply = "update tb_jc_apply set signer='" + signer + "',signertype='" + signertype + "',signtime=sysdate," +
                    "status='" + status + "',f_changetype='是',f_jcdj_new='" + jc_dj + "' where apply_no='" + apply_no + "';";
                    sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + empno + "','" + agent + "'," +
                        "'" + MEMO + "','" + jc_dj + "','修改','" + CurrentApprover.Rows[0]["StationName"].ToString().Trim()
                        + "',sysdate,'" + signerGrade + "');";
                }
            }
            string sqls = "begin " + sqlApply + sqlHistory + " end;";

            DBHelper.Inserts(sqls,empno);
            //21+11=32
            int start = sqlApply.IndexOf("signer") + 8;
            if (CurrentApprover.Rows[0]["StationName"].ToString() == "最高主管核准" && 
                CurrentApprover.Rows[0]["Approver"].ToString() == sqlApply.Substring(start, sqlApply.IndexOf(",") - start - 1))
            {
                Signer(Signs, apply_no, MEMO, empno, plant, jc_dj);
            }

            return "完成";
        }
        /// <summary>
        /// 纸档签核同意
        /// </summary>
        /// <param name="State">当局状态</param>
        /// <param name="apply_no">单号</param>
        /// <param name="MEMO">签核意见</param>
        /// <param name="empno">签核人</param>
        /// <param name="plant">厂区</param>
        /// <returns></returns>status
        public static string SignerDocument(string State,string apply_no,string MEMO,string empno,string plant)
        {
            DataTable dt = DBHelper.Queues("select te.f_Plantno,te.f_empno,te.f_name,tl.f_allmanager,F_EmpLevel from tb_employe te," +
                "tb_leader_redirect tl where te.f_empno=tl.f_empno and te.f_empno=" +
                "(select emp_No from tb_jc_apply where apply_No='"+ apply_no + "')", plant);
            string sqlApply = "", sqlHistory = "";
            if (State.Contains("待簽核"))
            {
                string Elader = dt.Rows[0][3].ToString().Split(';')[0];
                //课级主管
                sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + empno + "',''," +
                "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'通過','紙檔签核',sysdate,'');";
                sqlApply = "update tb_jc_apply set signer='" + Elader + "',signertype='課級結案'," +
                    "signtime=sysdate,status='" + State.Substring(0, 4) + "(課級結案)',agent='' where apply_no='" + apply_no + "';";
            }
            else if(State.Contains("課級結案"))
            {
                //奖惩窗口
                string Signs = DBHelper.Queues("select TE.F_EmpNo,TE.F_Name,TH.F_WindowType,TH.F_WindowName,TH.F_PlantNo from " +
                    "TB_Employe TE,TB_HRWindow TH where TE.F_EmpNo=TH.F_EmpNo and TH.F_WindowType='HREmpWin_JC'" +
                    " and TH.f_plantno='"+ dt.Rows[0][0].ToString() +"'", plant).Rows[0][0].ToString();

                sqlHistory = "insert into tb_signhistory_jc values('" + apply_no + "','" + empno + "',''," +
                "'" + MEMO + "',CNSBGHR.GET_JCDJ('" + apply_no + "'),'通過','紙檔課級結案',sysdate,'');";
                sqlApply = "update tb_jc_apply set signer='" + Signs + "',signertype=''," +
                    "signtime=sysdate,status='待結案',agent='' where apply_no='" + apply_no + "';";
            }

            
            string sqls = "begin " + sqlApply + sqlHistory + " end;";
            DBHelper.Inserts(sqls, empno);
            return "完成";
        }
        /// <summary>
        /// 开除结案邮件，接口
        /// </summary>
        /// <param name="list"></param>
        /// <param name="MailTo">发送的目标工号</param>
        /// <returns></returns>
        public static string ExpelClosed(List<SmsInfo> list,string MailTo)
        {
            string BasePath = AppDomain.CurrentDomain.BaseDirectory;
            string sourceFilePath = BasePath + "\\File_Manager\\Incentive\\Sms\\SMSModel.xlsx";
            string targetFilePath = BasePath + "\\File_Manager\\Incentive\\Sms\\modle\\target.xlsx";
            // 复制文件
            using (FileStream sourceFileStream = new FileStream(sourceFilePath, FileMode.Open))
            {
                // 创建目标文件流对象并创建目标文件  
                using (FileStream targetFileStream = new FileStream(targetFilePath, FileMode.Create))
                {
                    // 复制文件内容到目标文件  
                    sourceFileStream.CopyTo(targetFileStream);
                }
            }
            //写短信文件
            using (ExcelPackage package = new ExcelPackage(new FileInfo(targetFilePath)))
            {
                // 设置许可证上下文为商业用途  
                ExcelPackage.LicenseContext = LicenseContext.Commercial;
                ExcelWorksheet worksheet = package.Workbook.Worksheets["工作表1"];
                
                // 在这里进行修改操作  
                for (int i = 0; i < list.Count; i++)
                {
                    int rows = i + 2;
                    
                    worksheet.Cells[rows, 1].Value = i + 1;    
                    worksheet.Cells[rows, 2].Value = list[i].EmpNo;
                    worksheet.Cells[rows, 3].Value = list[i].Name;
                    worksheet.Cells[rows, 4].Value = list[i].ExpelType;
                    worksheet.Cells[rows, 5].Value = list[i].CloseDate;
                    worksheet.Cells[rows, 6].Value = list[i].Tel;
                    worksheet.Cells[rows, 7].Value = list[i].Sms;

                    //设置边框
                    worksheet.Cells[rows, 1].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    worksheet.Cells[rows, 2].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    worksheet.Cells[rows, 3].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    worksheet.Cells[rows, 4].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    worksheet.Cells[rows, 5].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    worksheet.Cells[rows, 6].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    worksheet.Cells[rows, 7].Style.Border.BorderAround(ExcelBorderStyle.Thin);

                }
                // 可以用宣告的方式一併操作指定區域內的儲存格
                using (var range = worksheet.Cells[2, 1, list.Count + 1, 7])  // 直接選取 A1 到 A5
                {
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;//水平居中
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;//垂直居中
                }

                package.Save(); // 保存修改后的文件  
            }
            //发送邮件
            SendMail sendMail = new SendMail();
            string flag = sendMail.PhysicalSmsMail(MailTo, targetFilePath).Result;

            return targetFilePath + flag;
        }
    }
}