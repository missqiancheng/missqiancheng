﻿using Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EMPServerAPI.WorkFlow;
using System.Data;
using NPOI.OpenXmlFormats.Dml;
using NPOI.SS.Formula.Functions;
using System.Diagnostics;
using Newtonsoft.Json;

namespace EMPServerAPI.Models.Incentive
{
    public class WorkFlows
    {
        public WorkFlows(string plant) {
            plants = plant;
        }
        //提报人厂区信息
        private static string plants;
        //奖惩窗口人资信息
        private static DataTable _HRDB;
        internal static DataTable HRDB
        {
            get {
                if(_HRDB == null)
                {
                    //查询人资申请
                    string HRsql = "select TE.F_EmpNo,TE.F_Name,TH.F_WindowType,TH.F_WindowName,TH.F_PlantNo from " +
                        "TB_Employe TE,TB_HRWindow TH where TE.F_EmpNo=TH.F_EmpNo and TH.F_WindowType like '%_JC%'";
                    _HRDB = DBHelper.Queues(HRsql, plants);
                    return _HRDB;
                }
                else return _HRDB;
            } 
        }
        //所有员工基本信息
        private static DataTable _EMPDB;
        internal static DataTable EMPDB
        {
            get
            {
                if(_EMPDB == null) {
                    string sql = "select te.f_Plantno,te.f_empno,te.f_name,tl.f_allmanager,F_EmpLevel,tl.f_buheader from tb_employe te," +
                        "tb_leader_redirect tl where te.f_empno=tl.f_empno";
                    _EMPDB = DBHelper.Queues(sql,plants);
                    return _EMPDB;
                }
                else return _EMPDB; 
            }
        }
        /// <summary>
        /// 创建WorkFLow工作流
        /// </summary>
        /// <param name="applyno">单号</param>
        /// <param name="applicent">申请者</param>
        /// <param name="author">申请人</param>
        /// <param name="plant">申请者厂区</param>
        /// <param name="jc_dj">奖惩等级</param>
        /// <param name="f_changetype">是否变更奖惩</param>
        /// <returns></returns>
        public static string CreateIncentive(string applyno,string applicent,string author, string plant,string jc_dj,string f_changetype)
        {
            Workflow workFlow = new Workflow();
            try
            {
                List<Dictionary<string, string>> list = new List<Dictionary<string, string>>();
                //申请者厂区
                plants = plant;
                DataRow EmpInfo = EMPDB.AsEnumerable().Where(s => s.Field<string>("F_EMPNO") == author).CopyToDataTable().Rows[0];
                //申请人厂区
                string AuthorPlant = EmpInfo[0].ToString();
                //申请人主管信息
                string[] Leaders = EmpInfo[3].ToString().Split(';');
                //实例化flow
                workFlow.CookieContainer = new System.Net.CookieContainer();
                //创建workflow
                bool creatbool = workFlow.Createflow("HRM_JC", applyno, applicent, author);
                if (!creatbool) return workFlow.GetError();
                workFlow.FormAdd("isGG", "N");//是否公告
                Dictionary<string, string> isGG = new Dictionary<string, string>
            {
                { "isGG", "N" }
            };
                list.Add(isGG);
                //查询是否人资申请
                if (HRDB.AsEnumerable().Where(s => s.Field<string>("F_EMPNO") == applicent).Count() > 1)
                {
                    workFlow.FormAdd("isHR", "Y");//是否人资申请
                    Dictionary<string, string> isHR = new Dictionary<string, string>
                {
                    { "isHR", "Y" }
                };
                    list.Add(isHR);
                }
                else
                {
                    workFlow.FormAdd("isHR", "N");//是否人资申请
                    string txtHR = HRDB.AsEnumerable().Where(s => s.Field<string>("F_PLANTNO") == plant).
                        Where(a => a.Field<string>("F_WINDOWTYPE") == "HREmpWin_JC")
                        .CopyToDataTable().Rows[0][0].ToString();//获取HR信息
                    workFlow.FormAdd("txtHR", txtHR);//人资初审
                    Dictionary<string, string> isHR = new Dictionary<string, string>();
                    isHR.Add("isHR", "N");
                    list.Add(isHR);
                    Dictionary<string, string> txtHRs = new Dictionary<string, string>();
                    txtHRs.Add("txtHR", txtHR);
                    list.Add(txtHRs);
                }
                //获取申请人职级
                int ApplicantType = int.Parse(EMPDB.AsEnumerable().Where(s => s.Field<string>("F_EMPNO") == applicent)
                    .CopyToDataTable().Rows[0][4].ToString());
                //第一任主管等级
                Dictionary<string, int> LeaderGrade = new Dictionary<string, int>();
                for (int i = 0; i < Leaders.Length; i++)
                {
                    int Grade = int.Parse(EMPDB.AsEnumerable().Where(s => s.Field<string>("F_EMPNO") == Leaders[i]).
                        CopyToDataTable().Rows[0][4].ToString());
                    if (ApplicantType > Grade)
                    {
                        SendMail sends = new SendMail();
                        string res = sends.LowerMail(Leaders[i], author, EmpInfo[2].ToString(), jc_dj).Result;
                    }
                    else
                    {
                        LeaderGrade.Add(Leaders[i], Grade);
                    }
                }
                //初始化Leader
                Dictionary<string, string> txtLeaderType1 = new Dictionary<string, string>
                {
                    { "txtLeaderType1", "" }
                };
                Dictionary<string, string> txtLeaderType2 = new Dictionary<string, string>
                {
                    { "txtLeaderType2", "" }
                };
                Dictionary<string, string> txtLeaderType3 = new Dictionary<string, string>
                {
                    { "txtLeaderType3", "" }
                };
                

                //赋值主管
                foreach (string item in LeaderGrade.Keys)
                {
                    switch (LeaderGrade[item])
                    {
                        case 10:
                            workFlow.FormAdd("txtLeaderType1", item);//课级主管
                            txtLeaderType1["txtLeaderType1"] = item;
                            break;
                        case 20:
                            workFlow.FormAdd("txtLeaderType2", item);//部级主管
                            txtLeaderType2["txtLeaderType2"] = item;
                            break;
                        case 30:
                            workFlow.FormAdd("txtLeaderType3", item);//处级主管
                            txtLeaderType3["txtLeaderType3"] = item;
                            break;
                    }
                }


                list.Add(txtLeaderType1);
                list.Add(txtLeaderType2);
                list.Add(txtLeaderType3);

                //最高主管
                string[] UtmostLeader = new[] { "開除", "大功一次", "大過二次", "大過一次" };
                if (UtmostLeader.Contains(jc_dj) || f_changetype == "是")
                {
                    workFlow.FormAdd("txthave", "Y");//是否有最高主管
                    string MAXLeader = EmpInfo[5].ToString(); ;
                    workFlow.FormAdd("txtLeaderType4", MAXLeader);//最高主管
                    Dictionary<string, string> txthave = new Dictionary<string, string>
                {
                    { "txthave", "Y" }
                };
                    list.Add(txthave);
                    Dictionary<string, string> txtLeaderType4 = new Dictionary<string, string>
                {
                    { "txtLeaderType4", MAXLeader }
                };
                    list.Add(txtLeaderType4);
                }
                else
                {
                    workFlow.FormAdd("txthave", "N");//是否有最高主管
                    Dictionary<string, string> txthave = new Dictionary<string, string>
                {
                    { "txthave", "N" }
                };
                    list.Add(txthave);
                }
                //事业群最高主管
                if (AuthorPlant == "011" && UtmostLeader.Contains(jc_dj))
                {
                    string Superlative = DBHelper.Queues("select f_empno from TB_HRWindow where F_WindowType='BGLeaderWin_JC'"
                        , plant).Rows[0][0].ToString();
                    workFlow.FormAdd("txtBGLeader", Superlative);//事业群最高主管
                    Dictionary<string, string> txtBGLeader = new Dictionary<string, string>
                    {
                        { "txtBGLeader", Superlative }
                    };
                    list.Add(txtBGLeader);
                }
                else
                {
                    workFlow.FormAdd("txtBGLeader", "");//事业群最高主管
                    Dictionary<string, string> txtBGLeader = new Dictionary<string, string>
                    {
                        { "txtBGLeader", "" }
                    };
                    list.Add(txtBGLeader);
                }
                //工会法务
                if (jc_dj == "開除" && f_changetype == "否")
                {
                    string GH = HRDB.AsEnumerable().Where(s => s.Field<string>("F_WINDOWTYPE") == "HREmpWin_JC_GH")
                        .Where(a => a.Field<string>("F_PLANTNO") == AuthorPlant).CopyToDataTable().Rows[0][0].ToString();
                    string Legal = HRDB.AsEnumerable().Where(s => s.Field<string>("F_WINDOWTYPE") == "HRLawWin_JC")
                        .Where(a => a.Field<string>("F_PLANTNO") == AuthorPlant).CopyToDataTable().Rows[0][0].ToString();
                    workFlow.FormAdd("txthave1", "Y");//是否工会签核
                    workFlow.FormAdd("txtGH", GH);//工会
                    workFlow.FormAdd("txtLaw", Legal);//法务
                    Dictionary<string, string> txthave1 = new Dictionary<string, string>
                    {
                        { "txthave1", "Y" }
                    };
                    Dictionary<string, string> txtLaw = new Dictionary<string, string>
                    {
                        { "txtLaw", Legal }
                    };
                    Dictionary<string, string> txtGH = new Dictionary<string, string>
                    {
                        { "txtGH", GH }
                    };

                    list.Add(txthave1);
                    list.Add(txtLaw);
                    list.Add(txtGH);
                }
                else
                {
                    Dictionary<string, string> txthave1 = new Dictionary<string, string>
                {
                    { "txthave1", "N" }
                };
                    list.Add(txthave1);
                    Dictionary<string, string> txtLaw = new Dictionary<string, string>
                {
                    { "txtLaw", "" }
                };
                    list.Add(txtLaw);
                }
                //人资最高主管
                string HRLeader = HRDB.AsEnumerable().Where(s => s.Field<string>("F_WINDOWTYPE") == "HREmpWin_JC_Leader")
                    .Where(s => s.Field<string>("F_PLANTNO") == plant).CopyToDataTable().Rows[0][0].ToString();
                workFlow.FormAdd("txtHRLeader", HRLeader);//人资课级主管
                //人资课级主管
                string HRLeaders = jc_dj == "開除" ? HRDB.AsEnumerable().Where(s => s.Field<string>("F_WINDOWTYPE") == "HRLeaderWin_JC")
                        .Where(s => s.Field<string>("F_PLANTNO") == plant).CopyToDataTable().Rows[0][0].ToString():"";
                workFlow.FormAdd("txtHRLeader1", HRLeaders);//人资课级主管
                Dictionary<string, string> txtHRLeader = new Dictionary<string, string>
                {
                    { "txtHRLeader1", HRLeaders }
                };
                list.Add(txtHRLeader);
                Dictionary<string, string> txtHRLeader1 = new Dictionary<string, string>
                {
                     { "txtHRLeader", HRLeader }
                };
                list.Add(txtHRLeader1);


                if (f_changetype == "是")
                {
                    workFlow.FormAdd("isModify", "Y");//是否修改
                }

                //申请人签核
                bool sign = workFlow.RunWorkflow("HRM_JC", applyno, applicent, "Approved", "");
                if (!sign) return workFlow.GetError();
                //人资申请签核
                string HRApplication = workFlow.GetNextApprover("HRM_JC", applyno).Tables[0].Rows[0]["Approver"].ToString().Trim();
                if (applicent == HRApplication)
                {
                    bool signs = workFlow.RunWorkflow("HRM_JC", applyno, applicent, "Approved", "");
                }

                return JsonConvert.SerializeObject(list);
            }
            catch(Exception ex)
            {
                return workFlow.GetError() + ex.Message;
            }
        }
        
    }
}