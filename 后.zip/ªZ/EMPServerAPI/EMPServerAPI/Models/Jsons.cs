﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;

namespace EMPServerAPI.Models
{
    public class Jsons
    {
        public static HttpResponseMessage JsonData(string data)
        {
            return new HttpResponseMessage
            {
                Content = new StringContent(data, Encoding.GetEncoding("UTF-8"), "application/json")
            };
        }
    }
}