﻿using NPOI.Util;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace EMPServerAPI.Models
{
    public class SaveFile
    {
      
        //奖惩参考文件路径
        //Express //文件路径：D:\WEB\HRM_Test\HRM_ZH\Upload\JC_upload\JC_book\


        /// <summary>
        /// 保存文件
        /// </summary>
        /// <param name="savePath">保存路径</param>
        /// <param name="FileillegalSte">规定文件格式</param>
        /// <param name="FileNames">规定文件名</param>
        /// <returns>null文件非法或没有文件</returns>
        public static Dictionary<string,string> fileUploads(string savePath, string FileillegalSte = null, string FileNames = null)
        {
            var files = HttpContext.Current.Request.Files;
            if (files.Count == 0)
            {
                return null;
            }
            try
            {
                Dictionary<string, string> dic=new Dictionary<string, string>();
                for (int i = 0; i < files.Count; i++)
                {
                    //文件实例
                    //文件名
                    string FileName = Path.GetFileName(files[i].FileName);
                    string[] a = FileName.Split('.');
                    string FileNameS = (FileNames == null) ? DateTime.Now.ToString("yyyyMMddHHmmss") + "." + a[a.Length - 1]
                        :FileNames + "." + a[a.Length - 1];
                    string fileExt = Path.GetExtension(FileName).ToUpper();
                    //規定上傳文件類型
                    if (FileillegalSte != null && FileillegalSte.IndexOf(fileExt) == -1)
                    {
                        return null;
                    }
                    //過濾非法後綴
                    string Fileillegal = ".EXE,.VBS,.VBE,.JS,.JSE,.WSH,.WSF,.CS,.DLL";
                    if (Fileillegal.IndexOf(fileExt) >= 0)
                    {
                        return null;
                    }
                    string FilePath = savePath + "\\" + FileNameS;
                    Stream stream = files[i].InputStream;
                    byte[] srcBuf = new byte[stream.Length];
                    //写内容
                    stream.Read(srcBuf, 0, srcBuf.Length);
                    stream.Seek(0, SeekOrigin.Begin);
                    //保存文件
                    using (FileStream fs = new FileStream(FilePath, FileMode.Create, FileAccess.Write))
                    {
                        fs.Write(srcBuf, 0, srcBuf.Length);
                        fs.Close();
                    }
                    
                    dic.Add(FileName+i, FileNameS);
                }
                return dic;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// 保存为文本文件。
        /// </summary>
        /// <param name="filepath">路径</param>
        /// <param name="Content">内容</param>
        /// <returns></returns>
        public static bool SavaText(string filepath,string Content)
        {
            try
            {
                using (StreamWriter fs = new StreamWriter(filepath))
                {
                    fs.Write(Content);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
        private StreamReader reads;
        /// <summary>
        /// 读取文本文件内容
        /// </summary>
        /// <param name="Path">路径</param>
        /// <returns></returns>
        public void CloseRead()
        {
            reads.Close();
        }
        
    }
}