﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Helpers;
using Newtonsoft.Json;

namespace EMPServerAPI.Models.model
{
    public class ReturnCode
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public dynamic Data { get; set; }
    }
}