﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EMPServerAPI.Models.model
{
    public class SmsInfo
    {
        //工号
        public string EmpNo { get; set; }
        //姓名
        public string Name { get; set; }
        //开除类型
        public string ExpelType { get; set; }
        //结案日期
        public string CloseDate { get; set; }
        //电话
        public string Tel { get; set; }
        //短信
        public string Sms { get; set; }
    }
}