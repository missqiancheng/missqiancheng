﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EMPServerAPI.Models
{
    public class Token
    {
        //工号
        public string Emp { get; set; }
        //登录时间
        public DateTime Times { get; set; }
        //权限
        public string permissions { get; set; }
        //厂区
        public string plant { get; set; }
    }
}